@echo off
REM Creates a local virtual environment and installs dependencies.
setlocal

where py >nul 2>nul
if errorlevel 1 (
    set PY=python
) else (
    set PY=py -3
)

echo [1/4] Creating virtual environment in .venv ...
%PY% -m venv .venv
if errorlevel 1 goto :fail

echo [2/4] Upgrading pip ...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :fail

echo [3/4] Installing requirements ...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :fail

echo [4/4] Installing the whatsapp-web.js bridge (only needed for the
echo       token-free WhatsApp Web transport) ...
where npm >nul 2>nul
if errorlevel 1 (
    echo    npm not found - skipping. Install Node.js 18+ and re-run install.bat
    echo    if you want the QR-login WhatsApp Web transport.
) else (
    pushd whatsapp_sender\bridge
    call npm install
    if errorlevel 1 (
        echo    npm install failed - the WhatsApp Web transport will not work.
        echo    The Cloud API and sandbox transports are unaffected.
    )
    popd
)

echo.
echo Done. Start the application with run.bat
goto :eof

:fail
echo.
echo Installation failed. Check the output above.
exit /b 1
