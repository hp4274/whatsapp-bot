"""PyInstaller / double-click entry point. Delegates to whatsapp_sender.main."""

from whatsapp_sender.main import main

if __name__ == "__main__":
    raise SystemExit(main())
