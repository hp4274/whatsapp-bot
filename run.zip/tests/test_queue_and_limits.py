"""Queue FIFO/pause/resume/stop/dedupe, rate limiter and retry policy."""

from __future__ import annotations

import threading
import time

import pytest

from whatsapp_sender.campaign.queue import MessageQueue, QueueItem, QueueState
from whatsapp_sender.campaign.rate_limiter import RateLimiter
from whatsapp_sender.campaign.retry import RetryPolicy


def item(recipient="919876543210", message="hi") -> QueueItem:
    return QueueItem(recipient=recipient, message=message)


# ----------------------------------------------------------------- queue --
def test_queue_is_fifo():
    q = MessageQueue()
    for i in range(3):
        q.put(item(message=f"m{i}"))
    assert [q.get().message for _ in range(3)] == ["m0", "m1", "m2"]


def test_duplicate_protection():
    q = MessageQueue()
    assert q.put(item()) is True
    assert q.put(item()) is False       # same recipient + same body
    assert q.put(item(message="other")) is True
    assert q.duplicates_rejected == 1
    assert len(q) == 2


def test_duplicate_protection_can_be_disabled():
    q = MessageQueue(dedupe=False)
    assert q.put(item()) is True
    assert q.put(item()) is True


def test_get_times_out_on_empty_queue():
    q = MessageQueue()
    start = time.monotonic()
    assert q.get(timeout=0.1) is None
    assert time.monotonic() - start >= 0.09


def test_pause_blocks_delivery_and_resume_releases_it():
    q = MessageQueue()
    q.put(item())
    q.pause()
    assert q.state is QueueState.PAUSED
    assert q.get(timeout=0.1) is None      # paused: nothing comes out
    q.resume()
    assert q.get(timeout=0.5) is not None


def test_resume_wakes_a_waiting_consumer():
    q = MessageQueue()
    q.pause()
    q.put(item())
    received: list[QueueItem] = []

    worker = threading.Thread(target=lambda: received.append(q.get(timeout=2.0)))
    worker.start()
    time.sleep(0.1)
    assert received == []
    q.resume()
    worker.join(timeout=2)
    assert received and received[0] is not None


def test_stop_drops_pending_items_and_rejects_new_ones():
    q = MessageQueue()
    q.put(item(message="a"))
    q.put(item(message="b"))
    q.stop()
    assert len(q) == 0
    assert q.is_stopped()
    assert q.put(item(message="c")) is False
    assert q.get(timeout=0.1) is None


def test_reset_makes_a_stopped_queue_reusable():
    q = MessageQueue()
    q.put(item())
    q.stop()
    q.reset()
    assert q.state is QueueState.RUNNING
    assert q.put(item()) is True           # dedupe set cleared too


def test_put_front_jumps_the_line():
    q = MessageQueue()
    q.put(item(message="first"))
    q.put_front(item(message="retry"))
    assert q.get().message == "retry"


# ---------------------------------------------------------- rate limiter --
class FakeClock:
    def __init__(self):
        self.now = 0.0

    def time(self):
        return self.now

    def sleep(self, seconds):
        self.now += max(seconds, 0.0)


def test_rate_limiter_allows_burst_then_throttles():
    clock = FakeClock()
    limiter = RateLimiter(1.0, burst=1, time_func=clock.time, sleep_func=clock.sleep)
    assert limiter.try_acquire() is True
    assert limiter.try_acquire() is False


def test_rate_limiter_refills_over_time():
    clock = FakeClock()
    limiter = RateLimiter(2.0, burst=1, time_func=clock.time, sleep_func=clock.sleep)
    assert limiter.try_acquire() is True
    clock.now += 0.5
    assert limiter.try_acquire() is True


def test_rate_limiter_acquire_waits_for_the_configured_rate():
    clock = FakeClock()
    limiter = RateLimiter(1.0, burst=1, time_func=clock.time, sleep_func=clock.sleep)
    limiter.acquire()
    start = clock.now
    limiter.acquire()
    assert clock.now - start == pytest.approx(1.0, abs=0.1)


def test_rate_limiter_rate_is_configurable_at_runtime():
    clock = FakeClock()
    limiter = RateLimiter(1.0, burst=1, time_func=clock.time, sleep_func=clock.sleep)
    limiter.set_rate(10.0)
    limiter.acquire()
    start = clock.now
    limiter.acquire()
    assert clock.now - start < 0.2


def test_rate_limiter_acquire_returns_false_when_stopped():
    clock = FakeClock()
    limiter = RateLimiter(1.0, burst=1, time_func=clock.time, sleep_func=clock.sleep)
    limiter.acquire()
    stop = threading.Event()
    stop.set()
    assert limiter.acquire(stop) is False


def test_rate_limiter_rejects_bad_rate():
    with pytest.raises(ValueError):
        RateLimiter(0)


# ----------------------------------------------------------------- retry --
def test_retry_policy_respects_max_retries():
    policy = RetryPolicy(max_retries=3, base_delay=1.0, jitter=0)
    assert policy.should_retry(1) is True
    assert policy.should_retry(3) is True
    assert policy.should_retry(4) is False


def test_retry_policy_never_retries_permanent_errors():
    policy = RetryPolicy(max_retries=3)
    assert policy.should_retry(1, retryable=False) is False


def test_retry_delay_is_exponential():
    policy = RetryPolicy(base_delay=2.0, backoff=2.0, jitter=0, max_delay=60)
    assert policy.delay_for(1) == 2.0
    assert policy.delay_for(2) == 4.0
    assert policy.delay_for(3) == 8.0


def test_retry_delay_is_capped():
    policy = RetryPolicy(base_delay=2.0, backoff=2.0, jitter=0, max_delay=5.0)
    assert policy.delay_for(10) == 5.0


def test_retry_jitter_stays_within_bounds():
    policy = RetryPolicy(base_delay=2.0, backoff=2.0, jitter=0.25, max_delay=60)
    for _ in range(50):
        assert 2.0 <= policy.delay_for(1) <= 2.5


def test_retry_policy_from_config():
    from whatsapp_sender.config import Config

    policy = RetryPolicy.from_config(Config(max_retries=7, retry_delay=3.0))
    assert policy.max_retries == 7
    assert policy.base_delay == 3.0
