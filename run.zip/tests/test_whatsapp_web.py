"""whatsapp-web.js transport: send mapping, error classification, ACK receipts.

The Node bridge itself is checked by ``node bridge.js --selftest``; here the
bridge is replaced by an httpx.MockTransport, so no browser and no Node process
are involved.
"""

from __future__ import annotations

import httpx
import pytest

from whatsapp_sender.config import TRANSPORT_WEB_JS, Config
from whatsapp_sender.protocol import Status
from whatsapp_sender.transports import create_transport
from whatsapp_sender.transports.base import TransportConnectionError, TransportSendError
from whatsapp_sender.transports.whatsapp_web import WhatsAppWebTransport


def make_transport(handler, **config_kwargs) -> WhatsAppWebTransport:
    kwargs = {"request_timeout": 1.0, "bridge_ready_timeout": 3.0}
    kwargs.update(config_kwargs)
    config = Config(transport=TRANSPORT_WEB_JS, **kwargs)
    client = httpx.Client(transport=httpx.MockTransport(handler))
    return WhatsAppWebTransport(config, client=client, spawn=False)


def ready_handler(request: httpx.Request) -> httpx.Response:
    if request.url.path == "/status":
        return httpx.Response(200, json={"state": "ready", "qr": None, "me": "919876543210",
                                         "detail": "", "seq": 0})
    if request.url.path == "/send":
        return httpx.Response(200, json={"id": "true_919876543210@c.us_ABC"})
    if request.url.path == "/acks":
        return httpx.Response(200, json={"seq": 0, "events": []})
    return httpx.Response(200, json={"ok": True})


def connected(handler=ready_handler, **kwargs) -> WhatsAppWebTransport:
    transport = make_transport(handler, **kwargs)
    transport.connect()
    return transport


def test_factory_builds_web_transport():
    assert isinstance(create_transport(Config(transport=TRANSPORT_WEB_JS)), WhatsAppWebTransport)


def test_connect_needs_no_access_token():
    transport = connected()
    assert transport.config.access_token == ""
    assert transport.is_connected() is True
    transport.disconnect()


def test_connect_reports_account_and_real_delivery():
    transport = make_transport(ready_handler)
    info = transport.connect()
    assert info.connected is True
    assert info.real_delivery is True
    assert info.account == "919876543210"
    assert transport.real_delivery is True
    transport.disconnect()


def test_connect_shows_qr_then_gives_up():
    seen: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"state": "qr", "qr": "1@QRPAYLOAD", "me": "",
                                         "detail": "scan it", "seq": 0})

    transport = make_transport(handler, bridge_ready_timeout=0.1)
    transport.qr_callback = seen.append
    with pytest.raises(TransportConnectionError) as exc:
        transport.connect()
    assert seen == ["1@QRPAYLOAD"]
    assert "QR code to be scanned" in str(exc.value)


def test_connect_rejects_auth_failure_without_retrying():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"state": "auth_failure", "detail": "session expired"})

    with pytest.raises(TransportConnectionError) as exc:
        make_transport(handler).connect()
    assert exc.value.retryable is False


def test_send_returns_sent_with_provider_id():
    transport = connected()
    result = transport.send_message("919876543210", "hello")
    assert result.status is Status.SENT
    assert result.provider_id == "true_919876543210@c.us_ABC"
    assert transport.get_status(result.provider_id) is Status.SENT
    transport.disconnect()


def test_send_requires_connection():
    transport = make_transport(ready_handler)
    with pytest.raises(TransportConnectionError):
        transport.send_message("919876543210", "hello")


def test_unknown_recipient_is_not_retried():
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/status":
            return ready_handler(request)
        return httpx.Response(400, json={"error": "10000000000 is not on WhatsApp",
                                         "retryable": False})

    transport = connected(handler)
    with pytest.raises(TransportSendError) as exc:
        transport.send_message("10000000000", "hello")
    assert exc.value.retryable is False
    transport.disconnect()


def test_bridge_failure_is_retried():
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/status":
            return ready_handler(request)
        return httpx.Response(502, json={"error": "puppeteer hiccup", "retryable": True})

    transport = connected(handler)
    with pytest.raises(TransportSendError) as exc:
        transport.send_message("919876543210", "hello")
    assert exc.value.retryable is True
    transport.disconnect()


def test_lost_session_marks_transport_disconnected():
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/status":
            return ready_handler(request)
        return httpx.Response(409, json={"error": "client not ready (disconnected)",
                                         "retryable": True})

    transport = connected(handler)
    with pytest.raises(TransportConnectionError):
        transport.send_message("919876543210", "hello")
    assert transport.is_connected() is False


def test_acks_upgrade_status_and_fire_callback():
    events = [
        {"id": "wa.1", "status": "DELIVERED"},
        {"id": "wa.2", "status": "READ"},
        {"id": "wa.3", "status": "FAILED"},
        {"id": "wa.4", "status": "WHAT-IS-THIS"},
    ]

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/status":
            return ready_handler(request)
        if request.url.path == "/acks":
            since = int(request.url.params.get("since", 0))
            return httpx.Response(200, json={"seq": 4, "events": events if since == 0 else []})
        return ready_handler(request)

    transport = connected(handler)
    seen: list[tuple[str, Status, str | None]] = []
    transport.set_receipt_callback(lambda pid, status, error: seen.append((pid, status, error)))

    assert transport.poll_once() == 3  # the unknown status is dropped, never guessed
    assert transport.get_status("wa.1") is Status.DELIVERED
    assert transport.get_status("wa.2") is Status.READ
    assert transport.get_status("wa.3") is Status.FAILED
    assert transport.get_status("wa.4") is None
    assert seen[0] == ("wa.1", Status.DELIVERED, None)
    assert seen[2][1] is Status.FAILED and seen[2][2]

    assert transport.poll_once() == 0  # cursor advanced: no receipt is applied twice
    transport.disconnect()


def test_bad_token_is_a_permanent_connection_error():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(403, json={"error": "bad bridge token"})

    with pytest.raises(TransportConnectionError) as exc:
        make_transport(handler).connect()
    assert exc.value.retryable is False


def test_send_without_ack_tracking_is_still_a_send_not_a_retry():
    """A message WhatsApp Web dispatched without returning an id must never be
    reported as a failure: the retry is what delivers it twice."""
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/status":
            return ready_handler(request)
        return httpx.Response(200, json={"id": "local.123.abc", "ackTracking": False})

    transport = connected(handler)
    result = transport.send_message("919876543210", "hello")
    assert result.status is Status.SENT
    assert result.provider_id == "local.123.abc"
    assert "no DELIVERED/READ" in result.detail
    transport.disconnect()
