"""Keep the test run out of the real user profile directory."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

# Must happen before whatsapp_sender.config is imported anywhere.
os.environ.setdefault(
    "WHATSAPP_SENDER_HOME", str(Path(tempfile.gettempdir()) / "whatsapp_sender_tests")
)
