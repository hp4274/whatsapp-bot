"""Campaign engine: queue processing, personalisation, retries, pause/resume/stop."""

from __future__ import annotations

import threading
import time

import pytest

from whatsapp_sender.campaign.manager import CampaignManager
from whatsapp_sender.config import Config
from whatsapp_sender.database import Database
from whatsapp_sender.protocol import Contact, Status
from whatsapp_sender.transports.base import (
    ConnectionInfo,
    SendResult,
    Transport,
    TransportConnectionError,
    TransportSendError,
)


class FakeTransport(Transport):
    """Records every send and can be told to fail a number of times."""

    name = "fake"
    real_delivery = True

    def __init__(self, failures: int = 0, retryable: bool = True, error=None) -> None:
        self.sent: list[tuple[str, str]] = []
        self.failures = failures
        self.retryable = retryable
        self.error = error
        self.attempts = 0
        self._connected = True
        self.lock = threading.Lock()

    def connect(self):
        self._connected = True
        return ConnectionInfo(connected=True, account="fake", real_delivery=True)

    def disconnect(self) -> None:
        self._connected = False

    def is_connected(self) -> bool:
        return self._connected

    def send_message(self, recipient: str, message: str) -> SendResult:
        with self.lock:
            self.attempts += 1
            if self.failures > 0:
                self.failures -= 1
                raise (self.error or TransportSendError("boom", retryable=self.retryable))
            self.sent.append((recipient, message))
            return SendResult(provider_id=f"wamid.{len(self.sent)}", status=Status.SENT)

    def get_status(self, message_id: str):
        return None


@pytest.fixture()
def db(tmp_path):
    database = Database(tmp_path / "campaign.db")
    yield database
    database.close()


def make_manager(db, transport, **config_kwargs) -> CampaignManager:
    config = Config(
        transport="sandbox",
        rate_limit_per_second=config_kwargs.pop("rate_limit_per_second", 1000.0),
        max_retries=config_kwargs.pop("max_retries", 3),
        retry_delay=config_kwargs.pop("retry_delay", 0.01),
        retry_backoff=config_kwargs.pop("retry_backoff", 1.0),
        retry_jitter=0.0,
        **config_kwargs,
    )
    return CampaignManager(db, transport, config)


def wait_until(predicate, timeout=5.0):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        if predicate():
            return True
        time.sleep(0.02)
    return False


CONTACTS = [
    Contact(name="Rahul", phone="919876543210"),
    Contact(name="Priya", phone="919812345678"),
    Contact(name="Amit", phone="919999888777"),
]


# ------------------------------------------------------------- enqueueing --
def test_enqueue_personalises_each_contact(db):
    manager = make_manager(db, FakeTransport())
    queued, duplicates = manager.enqueue_contacts(
        CONTACTS, "Hello {name}, your order has been confirmed.")
    assert (queued, duplicates) == (3, 0)
    bodies = sorted(r.message for r in db.history())
    assert bodies[0] == "Hello Amit, your order has been confirmed."
    assert all(r.status is Status.QUEUED for r in db.history())


def test_enqueue_rejects_duplicates(db):
    manager = make_manager(db, FakeTransport())
    contacts = CONTACTS + [Contact(name="Rahul", phone="919876543210")]
    queued, duplicates = manager.enqueue_contacts(contacts, "Hello {name}")
    assert (queued, duplicates) == (3, 1)


def test_enqueue_single_returns_none_for_duplicate(db):
    manager = make_manager(db, FakeTransport())
    assert manager.enqueue_single("919876543210", "hi") is not None
    assert manager.enqueue_single("919876543210", "hi") is None


# ------------------------------------------------------------- processing --
def test_campaign_sends_every_contact_in_order(db):
    transport = FakeTransport()
    manager = make_manager(db, transport)
    manager.enqueue_contacts(CONTACTS, "Hello {name}")
    manager.start()
    try:
        assert wait_until(lambda: len(transport.sent) == 3)
        assert [r for r, _ in transport.sent] == [c.phone for c in CONTACTS]
        assert wait_until(lambda: manager.stats().successful == 3)
        assert all(r.status is Status.SENT for r in db.history())
        assert all(r.provider_id for r in db.history())
    finally:
        manager.shutdown()


def test_stats_track_success_and_failure(db):
    error = TransportSendError("permanent", retryable=False)
    transport = FakeTransport(failures=1, error=error)
    manager = make_manager(db, transport)
    manager.enqueue_contacts(CONTACTS, "Hello {name}")
    manager.start()
    try:
        assert wait_until(lambda: manager.stats().processed == 3)
        stats = manager.stats()
        assert stats.successful == 2
        assert stats.failed == 1
    finally:
        manager.shutdown()


def test_pause_stops_processing_and_resume_continues(db):
    transport = FakeTransport()
    manager = make_manager(db, transport)
    manager.enqueue_contacts(CONTACTS, "Hello {name}")
    manager.pause()   # start() never un-pauses; Resume is its own control
    manager.start()
    try:
        time.sleep(0.3)
        assert transport.sent == []
        manager.resume()
        assert wait_until(lambda: len(transport.sent) == 3)
    finally:
        manager.shutdown()


def test_stop_cancels_queued_messages(db):
    transport = FakeTransport()
    manager = make_manager(db, transport, rate_limit_per_second=1.0)
    manager.enqueue_contacts(CONTACTS, "Hello {name}")
    manager.start()
    try:
        assert wait_until(lambda: len(transport.sent) >= 1)
        manager.stop()
        assert wait_until(lambda: manager.queue.pending() == 0)
        failed = [r for r in db.history() if r.status is Status.FAILED]
        assert failed and all("Stopped by operator" in (r.error or "") for r in failed)
    finally:
        manager.shutdown()


# ------------------------------------------------------------------ retry --
def test_retryable_failure_is_retried_until_success(db):
    transport = FakeTransport(failures=2, retryable=True)
    manager = make_manager(db, transport, max_retries=3)
    manager.enqueue_single("919876543210", "hi")
    manager.start()
    try:
        assert wait_until(lambda: len(transport.sent) == 1)
        record = db.history()[0]
        assert record.status is Status.SENT
        assert record.attempt == 3        # two failures + the successful attempt
        assert record.error is None
    finally:
        manager.shutdown()


def test_retries_give_up_after_max_retries(db):
    transport = FakeTransport(failures=99, retryable=True)
    manager = make_manager(db, transport, max_retries=2)
    manager.enqueue_single("919876543210", "hi")
    manager.start()
    try:
        assert wait_until(lambda: manager.stats().failed == 1)
        record = db.history()[0]
        assert record.status is Status.FAILED
        assert record.attempt == 3        # initial attempt + 2 retries
        assert transport.attempts == 3
    finally:
        manager.shutdown()


def test_permanent_failure_is_not_retried(db):
    transport = FakeTransport(failures=99, error=TransportSendError("nope", retryable=False))
    manager = make_manager(db, transport, max_retries=5)
    manager.enqueue_single("919876543210", "hi")
    manager.start()
    try:
        assert wait_until(lambda: manager.stats().failed == 1)
        assert transport.attempts == 1
        assert db.history()[0].attempt == 1
    finally:
        manager.shutdown()


def test_connection_failure_is_reported_and_not_retried(db):
    events: list[dict] = []
    transport = FakeTransport(
        failures=99, error=TransportConnectionError("socket closed", retryable=False))
    manager = make_manager(db, transport, max_retries=3)
    manager.on_event = events.append
    manager.enqueue_single("919876543210", "hi")
    manager.start()
    try:
        assert wait_until(lambda: manager.stats().failed == 1)
        assert any(e["type"] == "connection_lost" for e in events)
        assert "socket closed" in (db.history()[0].error or "")
    finally:
        manager.shutdown()


# ---------------------------------------------------------- rate limiting --
def test_rate_limit_paces_sending(db):
    transport = FakeTransport()
    manager = make_manager(db, transport, rate_limit_per_second=5.0)
    manager.enqueue_contacts(CONTACTS, "Hello {name}")
    start = time.monotonic()
    manager.start()
    try:
        assert wait_until(lambda: len(transport.sent) == 3, timeout=5)
        # 3 messages at 5/s with a burst of 1 costs at least ~0.4s.
        assert time.monotonic() - start >= 0.3
    finally:
        manager.shutdown()


# -------------------------------------------------------------- receipts --
def test_receipt_updates_history_only_when_reported(db):
    transport = FakeTransport()
    manager = make_manager(db, transport)
    manager.enqueue_single("919876543210", "hi")
    manager.start()
    try:
        assert wait_until(lambda: len(transport.sent) == 1)
        record = db.history()[0]
        assert record.status is Status.SENT       # not DELIVERED
        manager.handle_receipt(record.provider_id, Status.DELIVERED)
        assert db.get(record.message_id).status is Status.DELIVERED
    finally:
        manager.shutdown()


def test_apply_config_updates_rate_and_retries(db):
    manager = make_manager(db, FakeTransport())
    manager.apply_config(Config(rate_limit_per_second=7.0, max_retries=9, retry_delay=1.5))
    assert manager.rate_limiter.rate == 7.0
    assert manager.retry_policy.max_retries == 9


# --------------------------------------------------- one message per number --
def test_one_per_number_collapses_repeats_whatever_the_name(db):
    manager = make_manager(db, FakeTransport())
    contacts = CONTACTS + [
        Contact(name="Rahul Sharma", phone="919876543210"),  # same number, other name
        Contact(name="Priya", phone="919812345678"),         # exact repeat
    ]
    queued, skipped = manager.enqueue_contacts(contacts, "Hello {name}", one_per_number=True)
    assert (queued, skipped) == (3, 2)
    recipients = [r.recipient for r in db.history()]
    assert sorted(recipients) == sorted(c.phone for c in CONTACTS)
    # the first row for a number wins, so the personalisation is that contact's
    assert {r.recipient: r.message for r in db.history()}["919876543210"] == "Hello Rahul"


def test_one_per_number_skips_numbers_messaged_in_an_earlier_run(db):
    transport = FakeTransport()
    manager = make_manager(db, transport)
    manager.enqueue_contacts(CONTACTS[:1], "Hello {name}")
    manager.start()
    try:
        assert wait_until(lambda: len(transport.sent) == 1)
        assert wait_until(lambda: db.sent_recipients() == {CONTACTS[0].phone})
    finally:
        manager.shutdown()

    manager.queue.reset()
    queued, skipped = manager.enqueue_contacts(CONTACTS, "Hello again {name}",
                                               one_per_number=True)
    assert (queued, skipped) == (2, 1)
    assert CONTACTS[0].phone not in [
        r.recipient for r in db.history() if r.message.startswith("Hello again")
    ]


def test_without_the_option_a_number_can_be_messaged_again(db):
    manager = make_manager(db, FakeTransport())
    contacts = CONTACTS[:1] + [Contact(name="Rahul Sharma", phone="919876543210")]
    queued, skipped = manager.enqueue_contacts(contacts, "Hello {name}")
    assert (queued, skipped) == (2, 0)  # different body, so not a duplicate


def test_option_does_not_leak_into_later_single_sends(db):
    manager = make_manager(db, FakeTransport())
    manager.enqueue_contacts(CONTACTS, "Hello {name}", one_per_number=True)
    assert manager.enqueue_single(CONTACTS[0].phone, "a different message") is not None
