"""SQLite schema, indexes, updates and receipt ordering."""

from __future__ import annotations

import pytest

from whatsapp_sender.database import Database
from whatsapp_sender.protocol import MessageRecord, Status, new_message_id


@pytest.fixture()
def db(tmp_path):
    database = Database(tmp_path / "test.db")
    yield database
    database.close()


def make_record(recipient="919876543210", message="hi", **kwargs) -> MessageRecord:
    return MessageRecord(
        message_id=kwargs.pop("message_id", new_message_id()),
        recipient=recipient,
        message=message,
        status=kwargs.pop("status", Status.QUEUED),
        **kwargs,
    )


def test_schema_and_indexes_are_created(db):
    rows = db._conn.execute(
        "SELECT name FROM sqlite_master WHERE type='index'"
    ).fetchall()
    names = {r["name"] for r in rows}
    for expected in (
        "idx_messages_recipient",
        "idx_messages_status",
        "idx_messages_created_at",
        "idx_messages_provider_id",
    ):
        assert expected in names


def test_insert_and_get(db):
    record = db.insert(make_record())
    assert record.created_at and record.updated_at
    fetched = db.get(record.message_id)
    assert fetched is not None
    assert fetched.recipient == "919876543210"
    assert fetched.status is Status.QUEUED


def test_update_status_tracks_attempt_and_error(db):
    record = db.insert(make_record())
    db.update_status(record.message_id, Status.FAILED, attempt=3, error="boom")
    fetched = db.get(record.message_id)
    assert fetched.status is Status.FAILED
    assert fetched.attempt == 3
    assert fetched.error == "boom"


def test_successful_retry_clears_previous_error(db):
    record = db.insert(make_record())
    db.update_status(record.message_id, Status.QUEUED, attempt=1, error="temporary")
    db.update_status(record.message_id, Status.SENT, attempt=2, provider_id="wamid.X")
    fetched = db.get(record.message_id)
    assert fetched.error is None
    assert fetched.provider_id == "wamid.X"


def test_receipt_advances_status(db):
    record = db.insert(make_record())
    db.update_status(record.message_id, Status.SENT, provider_id="wamid.A")
    assert db.apply_receipt("wamid.A", Status.DELIVERED) is True
    assert db.get(record.message_id).status is Status.DELIVERED


def test_late_receipt_cannot_downgrade(db):
    record = db.insert(make_record())
    db.update_status(record.message_id, Status.SENT, provider_id="wamid.B")
    db.apply_receipt("wamid.B", Status.READ)
    assert db.apply_receipt("wamid.B", Status.DELIVERED) is False
    assert db.get(record.message_id).status is Status.READ


def test_receipt_for_unknown_provider_id_is_ignored(db):
    assert db.apply_receipt("wamid.unknown", Status.DELIVERED) is False


def test_failed_receipt_always_applies(db):
    record = db.insert(make_record())
    db.update_status(record.message_id, Status.SENT, provider_id="wamid.C")
    assert db.apply_receipt("wamid.C", Status.FAILED, "131047: outside window") is True
    fetched = db.get(record.message_id)
    assert fetched.status is Status.FAILED
    assert "131047" in fetched.error


def test_history_filters_and_counts(db):
    db.insert(make_record(recipient="911111111111", status=Status.SENT))
    db.insert(make_record(recipient="922222222222", status=Status.FAILED))
    db.insert(make_record(recipient="922222222222", status=Status.SENT))

    assert len(db.history()) == 3
    assert len(db.history(status=Status.SENT)) == 2
    assert len(db.history(recipient="9222")) == 2
    assert db.counts_by_status() == {"SENT": 2, "FAILED": 1}


def test_history_respects_limit(db):
    for _ in range(5):
        db.insert(make_record())
    assert len(db.history(limit=2)) == 2


def test_database_file_is_created_automatically(tmp_path):
    path = tmp_path / "nested" / "auto.db"
    path.parent.mkdir()
    database = Database(path)
    try:
        assert path.exists()
    finally:
        database.close()
