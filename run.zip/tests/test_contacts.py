"""CSV/XLSX import, phone validation, duplicate detection, personalisation."""

from __future__ import annotations

import pytest

from whatsapp_sender.contacts import import_any, import_csv, import_xlsx
from whatsapp_sender.protocol import (
    Contact,
    PhoneError,
    is_valid_phone,
    normalize_phone,
    personalize,
)

CSV_BODY = """name,phone,order_id
Rahul,+919876543210,ORD-1
Priya,+91 98123-45678,ORD-2
Amit,+919999888777,ORD-3
"""


def write_csv(tmp_path, body=CSV_BODY, name="contacts.csv"):
    path = tmp_path / name
    path.write_text(body, encoding="utf-8")
    return path


# ------------------------------------------------------------------- csv --
def test_import_csv_reads_all_contacts(tmp_path):
    result = import_csv(write_csv(tmp_path))
    assert result.count == 3
    assert [c.name for c in result.contacts] == ["Rahul", "Priya", "Amit"]
    assert result.contacts[0].phone == "919876543210"
    assert result.contacts[1].phone == "919812345678"  # separators stripped
    assert result.errors == []


def test_import_csv_keeps_extra_columns_as_variables(tmp_path):
    result = import_csv(write_csv(tmp_path))
    assert result.contacts[0].extra["order_id"] == "ORD-1"


def test_import_csv_rejects_bad_rows_without_killing_the_batch(tmp_path):
    body = "name,phone\nGood,+919876543210\nBad,not-a-number\nMissing,\n"
    result = import_csv(write_csv(tmp_path, body))
    assert result.count == 1
    assert len(result.errors) == 2
    assert "Row 3" in result.errors[0]


def test_import_csv_detects_duplicates(tmp_path):
    body = "name,phone\nA,+919876543210\nB,+91 98765 43210\nC,+919812345678\n"
    result = import_csv(write_csv(tmp_path, body))
    assert result.count == 2
    assert result.duplicates == 1


def test_import_csv_handles_empty_file(tmp_path):
    result = import_csv(write_csv(tmp_path, "", "empty.csv"))
    assert result.count == 0
    assert result.errors


def test_import_csv_missing_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        import_csv(tmp_path / "nope.csv")


def test_import_csv_accepts_alternative_headers(tmp_path):
    body = "Full Name,Mobile\nRahul,919876543210\n"
    result = import_csv(write_csv(tmp_path, body))
    assert result.count == 1
    assert result.contacts[0].phone == "919876543210"


def test_default_country_code_applied(tmp_path):
    body = "name,phone\nRahul,09876543210\n"
    result = import_csv(write_csv(tmp_path, body), default_country_code="91")
    assert result.contacts[0].phone == "919876543210"


# ------------------------------------------------------------------ xlsx --
def test_import_xlsx(tmp_path):
    openpyxl = pytest.importorskip("openpyxl")
    path = tmp_path / "contacts.xlsx"
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.append(["name", "phone", "order_id"])
    sheet.append(["Rahul", "+919876543210", "ORD-1"])
    sheet.append(["Priya", "+919812345678", "ORD-2"])
    sheet.append(["Dup", "+919876543210", "ORD-3"])
    sheet.append(["Bad", "12", "ORD-4"])
    workbook.save(path)

    result = import_xlsx(path)
    assert result.count == 2
    assert result.duplicates == 1
    assert len(result.errors) == 1
    assert result.contacts[0].extra["order_id"] == "ORD-1"


def test_import_any_dispatches_on_extension(tmp_path):
    assert import_any(write_csv(tmp_path)).count == 3


# ----------------------------------------------------------------- phone --
@pytest.mark.parametrize(
    "raw,expected",
    [
        ("+919876543210", "919876543210"),
        ("919876543210", "919876543210"),
        ("00919876543210", "919876543210"),
        ("+91 98765-43210", "919876543210"),
        ("(919) 876-543210", "919876543210"),
    ],
)
def test_normalize_phone_accepts_common_formats(raw, expected):
    assert normalize_phone(raw) == expected


@pytest.mark.parametrize("raw", ["", "   ", "abc", "12345", None, "+"])
def test_normalize_phone_rejects_junk(raw):
    with pytest.raises(PhoneError):
        normalize_phone(raw)


def test_is_valid_phone():
    assert is_valid_phone("+919876543210")
    assert not is_valid_phone("123")


# -------------------------------------------------------- personalisation --
def test_personalize_substitutes_name():
    contact = Contact(name="Rahul", phone="919876543210")
    out = personalize("Hello {name}, your order has been confirmed.", contact.as_context())
    assert out == "Hello Rahul, your order has been confirmed."


def test_personalize_uses_extra_columns():
    contact = Contact(name="Priya", phone="919812345678", extra={"order_id": "ORD-2"})
    assert personalize("{name}: {order_id}", contact.as_context()) == "Priya: ORD-2"


def test_personalize_keeps_unknown_placeholders():
    assert personalize("Hi {name}, {missing}", {"name": "A"}) == "Hi A, {missing}"


def test_personalize_survives_broken_template():
    assert personalize("100% sure {", {"name": "A"}) == "100% sure {"


def test_personalize_empty_template():
    assert personalize("", {"name": "A"}) == ""
