"""Cloud API transport: connection failures, error classification, receipts."""

from __future__ import annotations

import httpx
import pytest

from whatsapp_sender.config import Config
from whatsapp_sender.protocol import Status
from whatsapp_sender.transports import create_transport
from whatsapp_sender.transports.base import (
    TransportConnectionError,
    TransportSendError,
)
from whatsapp_sender.transports.sandbox import SandboxTransport
from whatsapp_sender.transports.whatsapp_transport import (
    CloudAPITransport,
    parse_status_payload,
)


def make_config(**kwargs) -> Config:
    base = dict(phone_number_id="123456", access_token="TOKEN", request_timeout=1.0)
    base.update(kwargs)
    return Config(**base)


def client_for(handler) -> httpx.Client:
    return httpx.Client(transport=httpx.MockTransport(handler))


def ok_send_handler(request: httpx.Request) -> httpx.Response:
    if request.method == "GET":
        return httpx.Response(200, json={"display_phone_number": "15550783881",
                                         "verified_name": "Acme", "quality_rating": "GREEN"})
    return httpx.Response(200, json={
        "messaging_product": "whatsapp",
        "contacts": [{"input": "919876543210", "wa_id": "919876543210"}],
        "messages": [{"id": "wamid.TEST", "message_status": "accepted"}],
    })


def connected_transport(handler=ok_send_handler, **config_kwargs) -> CloudAPITransport:
    transport = CloudAPITransport(make_config(**config_kwargs), client=client_for(handler))
    transport.connect()
    return transport


# ------------------------------------------------------------- connection --
def test_connect_requires_credentials():
    transport = CloudAPITransport(Config(phone_number_id="", access_token=""))
    with pytest.raises(TransportConnectionError) as exc:
        transport.connect()
    assert "Phone Number ID" in str(exc.value)
    assert transport.is_connected() is False


def test_connect_reports_account():
    transport = connected_transport()
    assert transport.is_connected() is True
    assert transport.real_delivery is True


def test_connect_fails_on_bad_token():
    def handler(request):
        return httpx.Response(401, json={"error": {"message": "Invalid OAuth token", "code": 190}})

    transport = CloudAPITransport(make_config(), client=client_for(handler))
    with pytest.raises(TransportConnectionError) as exc:
        transport.connect()
    assert exc.value.retryable is False
    assert transport.is_connected() is False


def test_connect_fails_on_network_error():
    def handler(request):
        raise httpx.ConnectError("no route to host")

    transport = CloudAPITransport(make_config(), client=client_for(handler))
    with pytest.raises(TransportConnectionError):
        transport.connect()


def test_send_without_connect_is_rejected():
    transport = CloudAPITransport(make_config(), client=client_for(ok_send_handler))
    with pytest.raises(TransportConnectionError):
        transport.send_message("919876543210", "hi")


# ------------------------------------------------------------------ send --
def test_send_returns_sent_not_delivered():
    transport = connected_transport()
    result = transport.send_message("919876543210", "hello")
    assert result.provider_id == "wamid.TEST"
    # The API only confirms acceptance: never DELIVERED/READ from a send call.
    assert result.status is Status.SENT


def test_send_builds_a_text_payload():
    captured = {}

    def handler(request):
        if request.method == "GET":
            return ok_send_handler(request)
        captured.update(__import__("json").loads(request.content))
        return ok_send_handler(request)

    connected_transport(handler).send_message("919876543210", "hello")
    assert captured["type"] == "text"
    assert captured["text"]["body"] == "hello"
    assert captured["to"] == "919876543210"


def test_send_builds_a_template_payload():
    captured = {}

    def handler(request):
        if request.method == "GET":
            return ok_send_handler(request)
        captured.update(__import__("json").loads(request.content))
        return ok_send_handler(request)

    transport = connected_transport(handler, use_template=True, template_name="order_update")
    transport.send_message("919876543210", "Rahul")
    assert captured["type"] == "template"
    assert captured["template"]["name"] == "order_update"
    assert captured["template"]["components"][0]["parameters"][0]["text"] == "Rahul"


def test_rate_limit_error_is_retryable():
    def handler(request):
        if request.method == "GET":
            return ok_send_handler(request)
        return httpx.Response(400, json={"error": {"message": "rate limit", "code": 130429}})

    with pytest.raises(TransportSendError) as exc:
        connected_transport(handler).send_message("919876543210", "hi")
    assert exc.value.retryable is True
    assert exc.value.code == 130429


def test_outside_24h_window_is_not_retryable():
    def handler(request):
        if request.method == "GET":
            return ok_send_handler(request)
        return httpx.Response(400, json={"error": {
            "message": "Re-engagement message", "code": 131047,
            "error_data": {"details": "Message failed to send because more than 24 hours "
                                      "have passed since the customer last replied"}}})

    with pytest.raises(TransportSendError) as exc:
        connected_transport(handler).send_message("919876543210", "hi")
    assert exc.value.retryable is False
    assert "24 hours" in str(exc.value)


def test_server_error_is_retryable():
    def handler(request):
        if request.method == "GET":
            return ok_send_handler(request)
        return httpx.Response(500, json={"error": {"message": "internal", "code": 1}})

    with pytest.raises(TransportSendError) as exc:
        connected_transport(handler).send_message("919876543210", "hi")
    assert exc.value.retryable is True


def test_expired_token_during_send_drops_the_connection():
    def handler(request):
        if request.method == "GET":
            return ok_send_handler(request)
        return httpx.Response(401, json={"error": {"message": "expired", "code": 190}})

    transport = connected_transport(handler)
    with pytest.raises(TransportConnectionError):
        transport.send_message("919876543210", "hi")
    assert transport.is_connected() is False


def test_timeout_is_retryable():
    def handler(request):
        if request.method == "GET":
            return ok_send_handler(request)
        raise httpx.ReadTimeout("timed out", request=request)

    with pytest.raises(TransportSendError) as exc:
        connected_transport(handler).send_message("919876543210", "hi")
    assert exc.value.retryable is True


def test_unexpected_response_shape_is_permanent():
    def handler(request):
        if request.method == "GET":
            return ok_send_handler(request)
        return httpx.Response(200, json={"unexpected": True})

    with pytest.raises(TransportSendError) as exc:
        connected_transport(handler).send_message("919876543210", "hi")
    assert exc.value.retryable is False


# ---------------------------------------------------------------- status --
def test_get_status_returns_none_without_a_receipt():
    transport = connected_transport()
    transport.send_message("919876543210", "hi")
    assert transport.get_status("wamid.TEST") is None   # no invented DELIVERED


def test_get_status_returns_recorded_receipt():
    transport = connected_transport()
    transport.record_receipt("wamid.TEST", Status.DELIVERED)
    assert transport.get_status("wamid.TEST") is Status.DELIVERED


def test_parse_status_payload_extracts_receipts():
    payload = {"entry": [{"changes": [{"field": "messages", "value": {"statuses": [
        {"id": "wamid.A", "status": "delivered", "recipient_id": "9199"},
        {"id": "wamid.B", "status": "read", "recipient_id": "9199"},
    ]}}]}]}
    assert parse_status_payload(payload) == [
        ("wamid.A", Status.DELIVERED, None),
        ("wamid.B", Status.READ, None),
    ]


def test_parse_status_payload_extracts_errors():
    payload = {"entry": [{"changes": [{"value": {"statuses": [{
        "id": "wamid.C", "status": "failed",
        "errors": [{"code": 131049, "title": "not delivered",
                    "error_data": {"details": "healthy ecosystem"}}],
    }]}}]}]}
    provider_id, status, error = parse_status_payload(payload)[0]
    assert (provider_id, status) == ("wamid.C", Status.FAILED)
    assert "131049" in error


def test_parse_status_payload_ignores_incoming_messages():
    payload = {"entry": [{"changes": [{"value": {"messages": [{"id": "wamid.X"}]}}]}]}
    assert parse_status_payload(payload) == []


# --------------------------------------------------------------- sandbox --
def test_sandbox_never_reports_sent(tmp_path):
    transport = SandboxTransport(Config(), outbox_path=tmp_path / "outbox.log")
    transport.connect()
    result = transport.send_message("919876543210", "hello")
    assert result.status is Status.SANDBOX      # never Status.SENT
    assert transport.real_delivery is False
    assert "hello" in (tmp_path / "outbox.log").read_text(encoding="utf-8")


def test_sandbox_requires_connect(tmp_path):
    transport = SandboxTransport(Config(), outbox_path=tmp_path / "outbox.log")
    with pytest.raises(TransportConnectionError):
        transport.send_message("919876543210", "hi")


def test_sandbox_can_simulate_failures(tmp_path):
    transport = SandboxTransport(Config(), outbox_path=tmp_path / "outbox.log")
    transport.connect()
    transport.fail_prefix = "9199"
    with pytest.raises(TransportSendError):
        transport.send_message("919912345678", "hi")


# --------------------------------------------------------------- factory --
def test_create_transport_selects_implementation():
    assert isinstance(create_transport(Config(transport="sandbox")), SandboxTransport)
    assert isinstance(create_transport(make_config(transport="cloud_api")), CloudAPITransport)
    with pytest.raises(ValueError):
        create_transport(Config(transport="carrier-pigeon"))
