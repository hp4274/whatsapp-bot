"""WhatsApp Sender - Python desktop application for WhatsApp Cloud API delivery."""

__version__ = "1.0.0"
