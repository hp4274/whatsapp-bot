"""FIFO message queue with pause / resume / stop and duplicate protection."""

from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum

from ..protocol import dedupe_key, new_message_id


class QueueState(str, Enum):
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    STOPPED = "STOPPED"


@dataclass
class QueueItem:
    recipient: str
    message: str
    name: str = ""
    campaign_id: str = ""
    message_id: str = field(default_factory=new_message_id)
    attempt: int = 0

    @property
    def key(self) -> str:
        return dedupe_key(self.recipient, self.message)


class MessageQueue:
    """Thread-safe FIFO queue.

    ``get`` blocks while the queue is paused and returns None when the queue is
    stopped or the timeout expires, so a worker thread never needs its own
    polling loop.
    """

    def __init__(self, dedupe: bool = True, one_per_recipient: bool = False) -> None:
        self._items: deque[QueueItem] = deque()
        self._seen: set[str] = set()
        self._dedupe = dedupe
        #: when True the dedupe key is the number alone, so one number gets one
        #: message however many rows (or names) it appears under.
        self.one_per_recipient = one_per_recipient
        self._state = QueueState.RUNNING
        self._cond = threading.Condition(threading.RLock())
        self.duplicates_rejected = 0

    # ---------------------------------------------------------------- state --
    @property
    def state(self) -> QueueState:
        with self._cond:
            return self._state

    def is_stopped(self) -> bool:
        return self.state is QueueState.STOPPED

    def is_paused(self) -> bool:
        return self.state is QueueState.PAUSED

    def pause(self) -> None:
        with self._cond:
            if self._state is QueueState.RUNNING:
                self._state = QueueState.PAUSED
                self._cond.notify_all()

    def resume(self) -> None:
        with self._cond:
            if self._state is QueueState.PAUSED:
                self._state = QueueState.RUNNING
                self._cond.notify_all()

    def stop(self) -> None:
        """Stop for good and drop everything still waiting."""
        with self._cond:
            self._state = QueueState.STOPPED
            self._items.clear()
            self._cond.notify_all()

    def reset(self) -> None:
        """Make a stopped queue usable again (new campaign, clean dedupe set)."""
        with self._cond:
            self._items.clear()
            self._seen.clear()
            self.duplicates_rejected = 0
            self._state = QueueState.RUNNING
            self._cond.notify_all()

    # ------------------------------------------------------------------ io --
    def put(self, item: QueueItem) -> bool:
        """Append an item. Returns False when it was rejected as a duplicate."""
        with self._cond:
            if self._state is QueueState.STOPPED:
                return False
            if self._dedupe:
                key = item.recipient if self.one_per_recipient else item.key
                if key in self._seen:
                    self.duplicates_rejected += 1
                    return False
                self._seen.add(key)
            self._items.append(item)
            self._cond.notify()
            return True

    def put_front(self, item: QueueItem) -> None:
        """Put an item back at the head (used when a retry is deferred)."""
        with self._cond:
            if self._state is QueueState.STOPPED:
                return
            self._items.appendleft(item)
            self._cond.notify()

    def get(self, timeout: float | None = 0.5) -> QueueItem | None:
        deadline = None if timeout is None else time.monotonic() + timeout
        with self._cond:
            while True:
                if self._state is QueueState.STOPPED:
                    return None
                if self._state is QueueState.RUNNING and self._items:
                    return self._items.popleft()
                remaining = None if deadline is None else deadline - time.monotonic()
                if remaining is not None and remaining <= 0:
                    return None
                self._cond.wait(remaining if remaining is not None else 0.5)

    # -------------------------------------------------------------- counts --
    def __len__(self) -> int:
        with self._cond:
            return len(self._items)

    def pending(self) -> int:
        return len(self)

    def snapshot(self) -> list[QueueItem]:
        with self._cond:
            return list(self._items)
