"""Retry policy: configurable attempt count with exponential backoff."""

from __future__ import annotations

import random
from dataclasses import dataclass

MAX_RETRIES = 3          # default, overridden by Config
RETRY_DELAY = 2.0        # seconds, base delay -- doubled on every attempt


@dataclass
class RetryPolicy:
    max_retries: int = MAX_RETRIES
    base_delay: float = RETRY_DELAY
    backoff: float = 2.0
    max_delay: float = 60.0
    jitter: float = 0.25  # fraction of the delay added at random

    @classmethod
    def from_config(cls, config) -> "RetryPolicy":
        return cls(
            max_retries=config.max_retries,
            base_delay=config.retry_delay,
            backoff=config.retry_backoff,
            max_delay=config.retry_max_delay,
            jitter=config.retry_jitter,
        )

    def should_retry(self, attempt: int, retryable: bool = True) -> bool:
        """``attempt`` is the number of attempts already made (1-based)."""
        return bool(retryable) and attempt <= self.max_retries

    def delay_for(self, attempt: int, rng: random.Random | None = None) -> float:
        """Backoff before attempt number ``attempt + 1``."""
        if attempt < 1:
            attempt = 1
        raw = self.base_delay * (self.backoff ** (attempt - 1))
        raw = min(raw, self.max_delay)
        if self.jitter:
            rand = (rng or random).random()
            raw += raw * self.jitter * rand
        return min(raw, self.max_delay * (1 + self.jitter))
