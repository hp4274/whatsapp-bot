"""Campaign engine: contact -> personalise -> queue -> rate limit -> transport
-> status update.

A single background worker drains the queue so ordering stays FIFO and the
rate limiter has one place to enforce the configured send rate.  Every state
change is written to SQLite and pushed to the UI through ``on_event``.
"""

from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass
from typing import Callable, Iterable

from ..config import Config
from ..database import Database
from ..logger import get_logger
from ..protocol import (
    SUCCESS_STATUSES,
    Contact,
    MessageRecord,
    Status,
    personalize,
)
from ..transports.base import (
    Transport,
    TransportConnectionError,
    TransportError,
    TransportSendError,
)
from .queue import MessageQueue, QueueItem, QueueState
from .rate_limiter import RateLimiter
from .retry import RetryPolicy

log = get_logger("campaign")

EventCallback = Callable[[dict], None]


@dataclass
class CampaignStats:
    total: int = 0
    successful: int = 0
    failed: int = 0
    duplicates: int = 0
    processed: int = 0
    pending: int = 0
    state: str = QueueState.RUNNING.value

    def as_dict(self) -> dict:
        return dict(
            total=self.total,
            successful=self.successful,
            failed=self.failed,
            duplicates=self.duplicates,
            processed=self.processed,
            pending=self.pending,
            state=self.state,
        )


class CampaignManager:
    def __init__(
        self,
        db: Database,
        transport: Transport,
        config: Config,
        on_event: EventCallback | None = None,
        *,
        sleep_func=time.sleep,
    ) -> None:
        self.db = db
        self.transport = transport
        self.config = config
        self.on_event = on_event
        self._sleep = sleep_func

        self.queue = MessageQueue(dedupe=True)
        self.rate_limiter = RateLimiter(config.rate_limit_per_second, config.rate_limit_burst)
        self.retry_policy = RetryPolicy.from_config(config)

        self._stats = CampaignStats()
        self._stats_lock = threading.RLock()
        self._worker: threading.Thread | None = None
        self._shutdown = threading.Event()
        self.campaign_id = ""

    # ------------------------------------------------------------- config --
    def apply_config(self, config: Config) -> None:
        self.config = config
        self.rate_limiter.set_rate(config.rate_limit_per_second)
        self.retry_policy = RetryPolicy.from_config(config)

    def set_transport(self, transport: Transport) -> None:
        self.transport = transport

    # ------------------------------------------------------------- events --
    def _emit(self, kind: str, **payload) -> None:
        if self.on_event is None:
            return
        event = {"type": kind, **payload}
        try:
            self.on_event(event)
        except Exception:  # noqa: BLE001 - the UI must never kill the worker
            log.exception("Event callback failed for %s", kind)

    def _emit_stats(self) -> None:
        self._emit("stats", stats=self.stats().as_dict())

    def stats(self) -> CampaignStats:
        with self._stats_lock:
            snapshot = CampaignStats(**self._stats.as_dict())
        snapshot.pending = self.queue.pending()
        snapshot.duplicates = self.queue.duplicates_rejected
        snapshot.state = self.queue.state.value
        return snapshot

    # ------------------------------------------------------------ queueing --
    def enqueue_contacts(
        self,
        contacts: Iterable[Contact],
        template: str,
        campaign_id: str | None = None,
        one_per_number: bool = False,
    ) -> tuple[int, int]:
        """Personalise and queue a batch. Returns ``(queued, skipped)``.

        With ``one_per_number`` each number is messaged exactly once: repeats
        inside this batch are dropped whatever name they carry, and numbers
        that already received a real message in an earlier run are skipped
        too (the database, not the queue, is what remembers those).
        """
        self.campaign_id = campaign_id or uuid.uuid4().hex[:12]
        already_sent = self.db.sent_recipients() if one_per_number else set()
        queued = duplicates = 0
        # The flag only governs this batch: a later single send to one of these
        # numbers is a deliberate act, not a duplicate.
        previous_mode = self.queue.one_per_recipient
        self.queue.one_per_recipient = one_per_number
        try:
            for contact in contacts:
                if contact.phone in already_sent:
                    duplicates += 1
                    log.info("Skipping %s: already messaged in an earlier run", contact.phone)
                    continue
                body = personalize(template, contact.as_context())
                item = QueueItem(
                    recipient=contact.phone,
                    message=body,
                    name=contact.name,
                    campaign_id=self.campaign_id,
                )
                if self._enqueue_item(item):
                    queued += 1
                else:
                    duplicates += 1
        finally:
            self.queue.one_per_recipient = previous_mode
        with self._stats_lock:
            self._stats.total += queued
        log.info(
            "Queued %s message(s) for campaign %s (%s skipped)",
            queued, self.campaign_id, duplicates,
        )
        self._emit_stats()
        return queued, duplicates

    def enqueue_single(self, recipient: str, message: str, name: str = "") -> str | None:
        item = QueueItem(
            recipient=recipient,
            message=message,
            name=name,
            campaign_id=self.campaign_id or "single",
        )
        if not self._enqueue_item(item):
            return None
        with self._stats_lock:
            self._stats.total += 1
        self._emit_stats()
        return item.message_id

    def _enqueue_item(self, item: QueueItem) -> bool:
        if not self.queue.put(item):
            return False
        record = MessageRecord(
            message_id=item.message_id,
            recipient=item.recipient,
            message=item.message,
            status=Status.QUEUED,
            name=item.name,
            campaign_id=item.campaign_id,
        )
        self.db.insert(record)
        self._emit("message", record=record)
        return True

    # ------------------------------------------------------------ controls --
    def start(self) -> None:
        # A paused queue stays paused: Start only (re)opens a stopped queue and
        # makes sure the worker thread is alive. Resume is its own button.
        if self.queue.is_stopped():
            self.queue.reset()
        self._shutdown.clear()
        if self._worker is None or not self._worker.is_alive():
            self._worker = threading.Thread(target=self._run, name="campaign", daemon=True)
            self._worker.start()
            log.info("Campaign worker started")
        self._emit_stats()

    def pause(self) -> None:
        self.queue.pause()
        log.info("Campaign paused")
        self._emit_stats()

    def resume(self) -> None:
        self.queue.resume()
        log.info("Campaign resumed")
        self._emit_stats()

    def stop(self) -> None:
        """Stop the campaign and drop everything still queued."""
        dropped = self.queue.snapshot()
        self.queue.stop()
        for item in dropped:
            self.db.update_status(
                item.message_id, Status.FAILED, attempt=item.attempt, error="Stopped by operator"
            )
        with self._stats_lock:
            self._stats.failed += len(dropped)
            self._stats.processed += len(dropped)
        log.info("Campaign stopped (%s queued message(s) cancelled)", len(dropped))
        self._emit("history_dirty")
        self._emit_stats()

    def reset_stats(self) -> None:
        with self._stats_lock:
            self._stats = CampaignStats()
        self._emit_stats()

    def shutdown(self, timeout: float = 5.0) -> None:
        self._shutdown.set()
        self.queue.stop()
        if self._worker is not None and self._worker.is_alive():
            self._worker.join(timeout=timeout)
        self._worker = None

    # -------------------------------------------------------------- worker --
    def _run(self) -> None:
        while not self._shutdown.is_set():
            item = self.queue.get(timeout=0.5)
            if item is None:
                if self.queue.is_stopped() and not self._shutdown.is_set():
                    # Stopped, but keep the thread alive for the next campaign.
                    self._sleep(0.1)
                continue
            self._process(item)
        log.info("Campaign worker exiting")

    def _interruptible_sleep(self, seconds: float) -> bool:
        """Sleep in slices. Returns False if the campaign was stopped meanwhile."""
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            if self._shutdown.is_set() or self.queue.is_stopped():
                return False
            self._sleep(min(0.1, max(0.0, end - time.monotonic())))
        return True

    def _process(self, item: QueueItem) -> None:
        while True:
            if self._shutdown.is_set() or self.queue.is_stopped():
                self._finish(item, Status.FAILED, error="Stopped by operator")
                return

            # Rate limit sits between the queue and the transport.
            if not self.rate_limiter.acquire(self._shutdown):
                self._finish(item, Status.FAILED, error="Stopped by operator")
                return

            item.attempt += 1
            self.db.update_status(item.message_id, Status.SENDING, attempt=item.attempt)
            self._emit("status", message_id=item.message_id, status=Status.SENDING,
                       attempt=item.attempt)

            try:
                result = self.transport.send_message(item.recipient, item.message)
            except TransportConnectionError as exc:
                log.error("Connection error on %s: %s", item.recipient, exc)
                self._emit("connection_lost", error=str(exc))
                retryable = exc.retryable
                error_text = f"Connection error: {exc}"
            except TransportSendError as exc:
                log.warning("Send error on %s: %s", item.recipient, exc)
                retryable = exc.retryable
                error_text = str(exc)
            except TransportError as exc:  # any other transport failure
                retryable = exc.retryable
                error_text = str(exc)
            except Exception as exc:  # noqa: BLE001 - unexpected, treat as permanent
                log.exception("Unexpected transport failure")
                retryable = False
                error_text = f"Unexpected error: {exc}"
            else:
                self.db.update_status(
                    item.message_id,
                    result.status,
                    attempt=item.attempt,
                    provider_id=result.provider_id,
                    error=None if result.status in SUCCESS_STATUSES else result.detail,
                )
                self._finish(item, result.status, provider_id=result.provider_id, counted=True)
                return

            if self.retry_policy.should_retry(item.attempt, retryable):
                delay = self.retry_policy.delay_for(item.attempt)
                self.db.update_status(
                    item.message_id,
                    Status.QUEUED,
                    attempt=item.attempt,
                    error=f"{error_text} (retry in {delay:.1f}s)",
                )
                self._emit("status", message_id=item.message_id, status=Status.QUEUED,
                           attempt=item.attempt, error=error_text)
                log.info(
                    "Retry %s/%s for %s in %.1fs",
                    item.attempt, self.retry_policy.max_retries, item.recipient, delay,
                )
                if not self._interruptible_sleep(delay):
                    self._finish(item, Status.FAILED, error="Stopped by operator")
                    return
                continue

            self.db.update_status(
                item.message_id, Status.FAILED, attempt=item.attempt, error=error_text
            )
            self._finish(item, Status.FAILED, error=error_text, counted=True)
            return

    def _finish(
        self,
        item: QueueItem,
        status: Status,
        *,
        provider_id: str | None = None,
        error: str | None = None,
        counted: bool = False,
    ) -> None:
        if not counted:
            self.db.update_status(item.message_id, status, attempt=item.attempt, error=error)
        with self._stats_lock:
            self._stats.processed += 1
            if status in SUCCESS_STATUSES or status is Status.SANDBOX:
                self._stats.successful += 1
            else:
                self._stats.failed += 1
        self._emit(
            "status",
            message_id=item.message_id,
            status=status,
            attempt=item.attempt,
            provider_id=provider_id,
            error=error,
        )
        self._emit_stats()

    # ------------------------------------------------------------ receipts --
    def handle_receipt(self, provider_id: str, status: Status, error: str | None = None) -> None:
        """Called by the webhook receiver. Only real receipts get here."""
        if self.db.apply_receipt(provider_id, status, error):
            self._emit("receipt", provider_id=provider_id, status=status, error=error)
            self._emit("history_dirty")
