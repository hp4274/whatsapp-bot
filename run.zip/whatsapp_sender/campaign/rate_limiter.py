"""Token-bucket rate limiter.

The rate comes from configuration; no sleep interval is hard-coded in the
sending path.  ``acquire`` waits in small slices so a Stop press is honoured
immediately instead of after a full token interval.
"""

from __future__ import annotations

import threading
import time


class RateLimiter:
    def __init__(
        self,
        rate_per_second: float,
        burst: int = 1,
        *,
        time_func=time.monotonic,
        sleep_func=time.sleep,
    ) -> None:
        if rate_per_second <= 0:
            raise ValueError("rate_per_second must be > 0")
        self.rate = float(rate_per_second)
        self.capacity = max(1, int(burst))
        self._time = time_func
        self._sleep = sleep_func
        self._tokens = float(self.capacity)
        self._updated = self._time()
        self._lock = threading.Lock()

    def set_rate(self, rate_per_second: float) -> None:
        if rate_per_second <= 0:
            raise ValueError("rate_per_second must be > 0")
        with self._lock:
            self._refill()
            self.rate = float(rate_per_second)

    def _refill(self) -> None:
        now = self._time()
        elapsed = max(0.0, now - self._updated)
        self._updated = now
        self._tokens = min(self.capacity, self._tokens + elapsed * self.rate)

    def try_acquire(self) -> bool:
        """Take a token if one is available right now."""
        with self._lock:
            self._refill()
            if self._tokens >= 1.0:
                self._tokens -= 1.0
                return True
            return False

    def time_until_token(self) -> float:
        with self._lock:
            self._refill()
            if self._tokens >= 1.0:
                return 0.0
            return (1.0 - self._tokens) / self.rate

    def acquire(self, stop_event: threading.Event | None = None, slice_seconds: float = 0.05) -> bool:
        """Block until a token is free.

        Returns False when ``stop_event`` was set while waiting.
        """
        while True:
            if stop_event is not None and stop_event.is_set():
                return False
            if self.try_acquire():
                return True
            wait = self.time_until_token()
            self._sleep(min(wait, slice_seconds) if wait > 0 else slice_seconds)
