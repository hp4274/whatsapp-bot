"""Application configuration.

Values are stored as JSON in the user profile directory so the access token
never has to live inside the source tree.  Every operational number (rate
limit, retries, timeouts) is configurable -- nothing is hard-coded in the
sending path.
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, fields
from pathlib import Path

APP_DIR = Path(
    os.environ.get("WHATSAPP_SENDER_HOME") or (Path.home() / ".whatsapp_sender")
)
CONFIG_PATH = APP_DIR / "config.json"
DB_PATH = APP_DIR / "messages.db"
LOG_PATH = APP_DIR / "app.log"

TRANSPORT_CLOUD_API = "cloud_api"
TRANSPORT_SANDBOX = "sandbox"
#: whatsapp-web.js sidecar: QR login, no access token, not an official API.
TRANSPORT_WEB_JS = "whatsapp_web"


@dataclass
class Config:
    # --- transport selection -------------------------------------------------
    transport: str = TRANSPORT_CLOUD_API

    # --- WhatsApp Cloud API credentials -------------------------------------
    graph_version: str = "v23.0"
    phone_number_id: str = ""
    access_token: str = ""

    # --- whatsapp-web.js bridge (no access token) ----------------------------
    bridge_port: int = 8765
    bridge_token: str = ""  # empty: a random one is generated per launch
    bridge_node: str = "node"
    bridge_data_dir: str = ""  # empty: <app dir>/wwebjs_auth
    bridge_chrome_path: str = ""  # empty: the Chromium puppeteer installed
    bridge_ready_timeout: float = 180.0  # time allowed for the QR scan
    bridge_poll_interval: float = 2.0

    # --- message shape -------------------------------------------------------
    use_template: bool = False
    template_name: str = "hello_world"
    template_language: str = "en_US"
    preview_url: bool = True

    # --- delivery control ----------------------------------------------------
    rate_limit_per_second: float = 1.0
    rate_limit_burst: int = 1
    max_retries: int = 3
    retry_delay: float = 2.0
    retry_backoff: float = 2.0
    retry_max_delay: float = 60.0
    retry_jitter: float = 0.25
    request_timeout: float = 30.0

    # --- delivery receipts (webhook) ----------------------------------------
    webhook_enabled: bool = False
    webhook_host: str = "0.0.0.0"
    webhook_port: int = 8080
    webhook_path: str = "/webhook"
    webhook_verify_token: str = "change-me"

    # --- misc ----------------------------------------------------------------
    default_country_code: str = ""
    log_level: str = "INFO"
    appearance_mode: str = "system"  # system | light | dark
    animations: bool = True  # off = this app's "reduced motion"

    # ------------------------------------------------------------------ io --
    @classmethod
    def load(cls, path: Path | None = None) -> "Config":
        path = path or CONFIG_PATH
        cfg = cls()
        if path.exists():
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                raw = {}
            known = {f.name for f in fields(cls)}
            for key, value in raw.items():
                if key in known:
                    setattr(cfg, key, value)
        cfg.apply_env_overrides()
        return cfg

    def apply_env_overrides(self) -> None:
        """Env vars win over the JSON file -- handy for CI and for people who
        refuse to write a token to disk."""
        token = os.environ.get("WHATSAPP_ACCESS_TOKEN")
        if token:
            self.access_token = token
        pnid = os.environ.get("WHATSAPP_PHONE_NUMBER_ID")
        if pnid:
            self.phone_number_id = pnid

    def save(self, path: Path | None = None) -> None:
        path = path or CONFIG_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")

    # ---------------------------------------------------------- validation --
    def validate(self) -> list[str]:
        problems: list[str] = []
        if self.transport == TRANSPORT_CLOUD_API:
            if not self.phone_number_id.strip():
                problems.append("Phone Number ID is required for the Cloud API transport.")
            if not self.access_token.strip():
                problems.append("Access Token is required for the Cloud API transport.")
        if self.transport == TRANSPORT_WEB_JS and not (1 <= self.bridge_port <= 65535):
            problems.append("Bridge port must be between 1 and 65535.")
        if self.rate_limit_per_second <= 0:
            problems.append("Rate limit must be greater than 0.")
        if self.max_retries < 0:
            problems.append("Max retries cannot be negative.")
        if self.request_timeout <= 0:
            problems.append("Request timeout must be greater than 0.")
        return problems

    @property
    def graph_base_url(self) -> str:
        return f"https://graph.facebook.com/{self.graph_version}"


def ensure_app_dir() -> Path:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    return APP_DIR
