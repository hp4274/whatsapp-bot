"""Shared domain types: message status, contacts, personalisation, phone rules.

This module is deliberately dependency-free so the transports, the campaign
engine, the importers and the tests can all agree on the same vocabulary.
"""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum


class Status(str, Enum):
    """Transport states.

    SENT/DELIVERED/READ are only ever written when the transport actually
    reports them.  SANDBOX is a separate state used by the local test
    transport so a fake send can never be mistaken for a real one.
    """

    QUEUED = "QUEUED"
    SENDING = "SENDING"
    SENT = "SENT"
    DELIVERED = "DELIVERED"
    READ = "READ"
    FAILED = "FAILED"
    SANDBOX = "SANDBOX"

    def __str__(self) -> str:  # nicer Treeview / log output
        return self.value


#: Status ranking used to stop a late webhook from downgrading a message
#: (a "delivered" receipt arriving after a "read" receipt must not win).
STATUS_RANK: dict[Status, int] = {
    Status.QUEUED: 0,
    Status.SENDING: 1,
    Status.SANDBOX: 2,
    Status.SENT: 2,
    Status.DELIVERED: 3,
    Status.READ: 4,
    Status.FAILED: 5,
}

TERMINAL_STATUSES = frozenset({Status.DELIVERED, Status.READ, Status.FAILED})
SUCCESS_STATUSES = frozenset({Status.SENT, Status.DELIVERED, Status.READ})


def utc_now() -> str:
    """ISO-8601 UTC timestamp, second resolution, sortable as text."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def new_message_id() -> str:
    return uuid.uuid4().hex


# --------------------------------------------------------------------------
# Phone numbers
# --------------------------------------------------------------------------

class PhoneError(ValueError):
    """Raised when a phone number cannot be turned into an E.164 number."""


_NON_DIGITS = re.compile(r"[^\d+]")
# E.164: leading digit 1-9, 7..15 digits total.  WhatsApp accepts the number
# without the leading '+', which is what the Cloud API wants in `to`.
_E164 = re.compile(r"^[1-9]\d{6,14}$")


def normalize_phone(raw: str, default_country_code: str = "") -> str:
    """Return a bare E.164 number (digits only, no '+', no separators).

    Accepts '+91 98765-43210', '0091 9876543210', '(987) 654-3210' etc.
    Raises PhoneError when the result is not a plausible E.164 number.
    """
    if raw is None:
        raise PhoneError("empty phone number")
    text = _NON_DIGITS.sub("", str(raw).strip())
    if not text:
        raise PhoneError("empty phone number")

    if text.startswith("+"):
        text = text[1:]
    elif text.startswith("00"):
        text = text[2:]
    else:
        cc = _NON_DIGITS.sub("", default_country_code or "").lstrip("+")
        if cc:
            # National number: strip a single national trunk '0' then prefix.
            national = text[1:] if text.startswith("0") else text
            text = cc + national

    text = text.lstrip("0")
    if not text.isdigit():
        raise PhoneError(f"not a number: {raw!r}")
    if not _E164.match(text):
        raise PhoneError(f"not a valid E.164 number: {raw!r} -> {text!r}")
    return text


def is_valid_phone(raw: str, default_country_code: str = "") -> bool:
    try:
        normalize_phone(raw, default_country_code)
    except PhoneError:
        return False
    return True


# --------------------------------------------------------------------------
# Contacts + personalisation
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class Contact:
    name: str
    phone: str  # normalised E.164, digits only
    extra: dict[str, str] = field(default_factory=dict)

    def as_context(self) -> dict[str, str]:
        ctx = {"name": self.name, "phone": self.phone}
        ctx.update(self.extra)
        return ctx


class _SafeDict(dict):
    """Leaves unknown ``{placeholders}`` untouched instead of raising."""

    def __missing__(self, key: str) -> str:
        return "{" + key + "}"


def personalize(template: str, context: dict[str, str]) -> str:
    """Substitute ``{name}``-style variables.

    Unknown placeholders are preserved verbatim rather than blowing up a whole
    campaign, and a malformed template is returned unchanged.
    """
    if not template:
        return ""
    safe = _SafeDict({k: ("" if v is None else str(v)) for k, v in context.items()})
    try:
        return template.format_map(safe)
    except (ValueError, IndexError):
        # e.g. a stray '{' or positional '{0}' in the template.
        return template


def dedupe_key(recipient: str, message: str) -> str:
    """Key used for duplicate protection inside one campaign run."""
    return f"{recipient}|{message}"


@dataclass
class MessageRecord:
    message_id: str
    recipient: str
    message: str
    status: Status
    attempt: int = 0
    provider_id: str | None = None
    error: str | None = None
    name: str = ""
    campaign_id: str = ""
    created_at: str = ""
    updated_at: str = ""
