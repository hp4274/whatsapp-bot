"""SQLite persistence for message history.

The database file and schema are created automatically on first use.  A single
connection guarded by a lock is used because the workload is a handful of
writes per second at most.
"""

from __future__ import annotations

import sqlite3
import threading
from pathlib import Path

from .config import DB_PATH, ensure_app_dir
from .logger import get_logger
from .protocol import STATUS_RANK, SUCCESS_STATUSES, MessageRecord, Status, utc_now

log = get_logger("database")

SCHEMA = """
CREATE TABLE IF NOT EXISTS messages (
    message_id  TEXT PRIMARY KEY,
    recipient   TEXT NOT NULL,
    name        TEXT NOT NULL DEFAULT '',
    message     TEXT NOT NULL,
    status      TEXT NOT NULL,
    attempt     INTEGER NOT NULL DEFAULT 0,
    provider_id TEXT,
    error       TEXT,
    campaign_id TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL,
    updated_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_recipient   ON messages(recipient);
CREATE INDEX IF NOT EXISTS idx_messages_status      ON messages(status);
CREATE INDEX IF NOT EXISTS idx_messages_created_at  ON messages(created_at);
CREATE INDEX IF NOT EXISTS idx_messages_provider_id ON messages(provider_id);
CREATE INDEX IF NOT EXISTS idx_messages_campaign_id ON messages(campaign_id);
"""


class Database:
    # ponytail: one connection + RLock. Fine for ~1 msg/s; switch to a
    # per-thread connection pool only if write contention ever shows up.
    def __init__(self, path: Path | str | None = None) -> None:
        if path is None:
            ensure_app_dir()
            path = DB_PATH
        self.path = str(path)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(self.path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.executescript(SCHEMA)
            self._conn.commit()
        log.info("Database ready at %s", self.path)

    # ------------------------------------------------------------------ io --
    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def insert(self, record: MessageRecord) -> MessageRecord:
        now = utc_now()
        record.created_at = record.created_at or now
        record.updated_at = record.updated_at or now
        with self._lock:
            self._conn.execute(
                """INSERT INTO messages (message_id, recipient, name, message, status,
                                         attempt, provider_id, error, campaign_id,
                                         created_at, updated_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    record.message_id,
                    record.recipient,
                    record.name,
                    record.message,
                    str(record.status),
                    record.attempt,
                    record.provider_id,
                    record.error,
                    record.campaign_id,
                    record.created_at,
                    record.updated_at,
                ),
            )
            self._conn.commit()
        return record

    def update_status(
        self,
        message_id: str,
        status: Status,
        *,
        attempt: int | None = None,
        provider_id: str | None = None,
        error: str | None = None,
    ) -> None:
        sets = ["status = ?", "updated_at = ?"]
        args: list[object] = [str(status), utc_now()]
        if attempt is not None:
            sets.append("attempt = ?")
            args.append(attempt)
        if provider_id is not None:
            sets.append("provider_id = ?")
            args.append(provider_id)
        # error is always written so a successful retry clears the old message.
        sets.append("error = ?")
        args.append(error)
        args.append(message_id)
        with self._lock:
            self._conn.execute(
                f"UPDATE messages SET {', '.join(sets)} WHERE message_id = ?", args
            )
            self._conn.commit()

    def apply_receipt(self, provider_id: str, status: Status, error: str | None = None) -> bool:
        """Apply a transport receipt (webhook) to the row with that provider id.

        Returns True when a row was actually advanced.  A receipt that is not
        ahead of the stored status is ignored, so a late DELIVERED cannot
        overwrite READ.
        """
        with self._lock:
            row = self._conn.execute(
                "SELECT message_id, status FROM messages WHERE provider_id = ?",
                (provider_id,),
            ).fetchone()
            if row is None:
                log.warning("Receipt for unknown provider_id=%s (%s)", provider_id, status)
                return False
            try:
                current = Status(row["status"])
            except ValueError:
                current = Status.QUEUED
            if STATUS_RANK[status] <= STATUS_RANK[current] and status is not Status.FAILED:
                return False
            self._conn.execute(
                "UPDATE messages SET status = ?, error = ?, updated_at = ? WHERE message_id = ?",
                (str(status), error, utc_now(), row["message_id"]),
            )
            self._conn.commit()
        log.info("Receipt %s -> %s applied to %s", provider_id, status, row["message_id"])
        return True

    # --------------------------------------------------------------- reads --
    def get(self, message_id: str) -> MessageRecord | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM messages WHERE message_id = ?", (message_id,)
            ).fetchone()
        return _to_record(row) if row else None

    def get_by_provider_id(self, provider_id: str) -> MessageRecord | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM messages WHERE provider_id = ?", (provider_id,)
            ).fetchone()
        return _to_record(row) if row else None

    def history(
        self,
        limit: int = 500,
        status: Status | None = None,
        recipient: str | None = None,
    ) -> list[MessageRecord]:
        sql = "SELECT * FROM messages"
        where, args = [], []
        if status is not None:
            where.append("status = ?")
            args.append(str(status))
        if recipient:
            where.append("recipient LIKE ?")
            args.append(f"%{recipient}%")
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY created_at DESC, rowid DESC LIMIT ?"
        args.append(limit)
        with self._lock:
            rows = self._conn.execute(sql, args).fetchall()
        return [_to_record(r) for r in rows]

    def counts_by_status(self, campaign_id: str | None = None) -> dict[str, int]:
        sql = "SELECT status, COUNT(*) AS n FROM messages"
        args: list[object] = []
        if campaign_id:
            sql += " WHERE campaign_id = ?"
            args.append(campaign_id)
        sql += " GROUP BY status"
        with self._lock:
            rows = self._conn.execute(sql, args).fetchall()
        return {r["status"]: r["n"] for r in rows}

    def recipient_history(self, recipient: str, limit: int = 20) -> list[MessageRecord]:
        return self.history(limit=limit, recipient=recipient)

    def history_signature(self, status: Status | None = None,
                          recipient: str | None = None) -> tuple[int, str]:
        """(row count, latest update) for a filter - the cheap "did anything
        change?" question, so the UI never fetches rows it will not repaint."""
        sql = "SELECT COUNT(*) AS n, COALESCE(MAX(updated_at), '') AS last FROM messages"
        clauses: list[str] = []
        args: list[object] = []
        if status is not None:
            clauses.append("status = ?")
            args.append(status.value)
        if recipient:
            clauses.append("recipient LIKE ?")
            args.append(f"%{recipient}%")
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        with self._lock:
            row = self._conn.execute(sql, args).fetchone()
        return (row["n"], row["last"])

    def sent_recipients(self) -> set[str]:
        """Numbers that already received a real message (SENT/DELIVERED/READ).

        SANDBOX is deliberately excluded: a local test send must not stop the
        number from getting the real one.
        """
        values = [s.value for s in SUCCESS_STATUSES]
        placeholders = ",".join("?" * len(values))
        sql = f"SELECT DISTINCT recipient FROM messages WHERE status IN ({placeholders})"
        with self._lock:
            rows = self._conn.execute(sql, values).fetchall()
        return {r["recipient"] for r in rows}


def _to_record(row: sqlite3.Row) -> MessageRecord:
    try:
        status = Status(row["status"])
    except ValueError:
        status = Status.QUEUED
    return MessageRecord(
        message_id=row["message_id"],
        recipient=row["recipient"],
        message=row["message"],
        status=status,
        attempt=row["attempt"],
        provider_id=row["provider_id"],
        error=row["error"],
        name=row["name"],
        campaign_id=row["campaign_id"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )
