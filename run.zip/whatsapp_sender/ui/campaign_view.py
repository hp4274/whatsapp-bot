"""Messaging + bulk campaign tab."""

from __future__ import annotations

import tkinter as tk
from tkinter import filedialog

import customtkinter as ctk

from ..contacts import import_csv, import_xlsx
from ..logger import get_logger
from ..protocol import Contact, PhoneError, normalize_phone, personalize
from . import anim, theme

log = get_logger("ui.campaign")


class CampaignView(ctk.CTkFrame):
    def __init__(self, master, app) -> None:
        super().__init__(master)
        self.app = app
        self.contacts: list[Contact] = []
        self._progress = 0.0
        self._progress_anim = None
        self._build()

    # --------------------------------------------------------------- build --
    def _build(self) -> None:
        pad = theme.SPACE
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        self.configure(fg_color="transparent")

        # ---- single message -------------------------------------------------
        single = theme.card(self)
        single.grid(row=0, column=0, sticky="ew", padx=pad["md"], pady=(pad["md"], pad["sm"]))
        single.grid_columnconfigure(1, weight=1)
        theme.card_header(single, "send", "Send a Single Message",
                          "One number, one message - same queue, limits and retries",
                          tone="primary").grid(
            row=0, column=0, columnspan=3, sticky="ew",
            padx=pad["lg"], pady=(pad["lg"], pad["md"]))

        ctk.CTkLabel(single, text=f"{theme.icon('phone')}   Recipient number").grid(
            row=1, column=0, sticky="w", padx=pad["md"], pady=pad["sm"])
        self.recipient_var = tk.StringVar()
        ctk.CTkEntry(single, textvariable=self.recipient_var,
                     placeholder_text="+919876543210").grid(
            row=1, column=1, sticky="ew", padx=pad["md"], pady=pad["sm"])
        self.send_button = ctk.CTkButton(single, text=f"{theme.icon('send')}  Send message",
                                         width=160, height=38,
                                         font=theme.font(weight="bold"), command=self.send_test)
        self.send_button.grid(row=1, column=2, padx=pad["md"], pady=pad["sm"])

        ctk.CTkLabel(single, text=f"{theme.icon('message')}   Recipient name").grid(
            row=2, column=0, sticky="w", padx=pad["md"], pady=pad["sm"])
        self.single_name_var = tk.StringVar()
        ctk.CTkEntry(single, textvariable=self.single_name_var,
                     placeholder_text="fills {name} in the message").grid(
            row=2, column=1, columnspan=2, sticky="ew", padx=pad["md"], pady=pad["sm"])

        ctk.CTkLabel(single, text=f"{theme.icon('send')}   Message").grid(
            row=3, column=0, sticky="nw", padx=pad["md"], pady=pad["sm"])
        self.message_box = ctk.CTkTextbox(single, height=90)
        self.message_box.grid(row=3, column=1, columnspan=2, sticky="ew", padx=pad["md"], pady=pad["sm"])
        self.message_box.insert("1.0", "Hello {name}, your order has been confirmed.")

        # ---- bulk campaign --------------------------------------------------
        bulk = theme.card(self)
        bulk.grid(row=1, column=0, sticky="nsew", padx=pad["md"], pady=pad["sm"])
        bulk.grid_columnconfigure(3, weight=1)
        theme.card_header(bulk, "message", "Bulk Campaign",
                          "Import contacts, personalise, then send at a controlled rate").grid(
            row=0, column=0, columnspan=4, sticky="ew",
            padx=pad["lg"], pady=(pad["lg"], pad["md"]))

        ctk.CTkButton(bulk, text=f"{theme.icon('import')}  Import CSV", width=140, height=38,
                      command=self.import_csv,
                      **theme.secondary_button()).grid(
            row=1, column=0, padx=(pad["md"], pad["sm"]), pady=pad["sm"])
        ctk.CTkButton(bulk, text=f"{theme.icon('import')}  Import XLSX", width=140, height=38,
                      command=self.import_xlsx,
                      **theme.secondary_button()).grid(
            row=1, column=1, padx=pad["sm"], pady=pad["sm"])
        self.count_label = ctk.CTkLabel(bulk, text="Contacts: 0")
        self.count_label.grid(row=1, column=2, padx=pad["md"], pady=pad["sm"], sticky="w")
        self.file_label = ctk.CTkLabel(bulk, text="No file loaded",
                                       text_color=theme.color("text_muted"),
                                       font=theme.font(theme.TEXT_SM))
        self.file_label.grid(row=1, column=3, padx=pad["md"], pady=pad["sm"], sticky="w")

        self.one_per_number_var = tk.BooleanVar(value=True)
        ctk.CTkCheckBox(
            bulk,
            text="One message per number (skip repeats and numbers already messaged)",
            variable=self.one_per_number_var,
        ).grid(row=2, column=0, columnspan=4, sticky="w", padx=pad["md"], pady=(pad["xs"], 2))

        controls = ctk.CTkFrame(bulk, fg_color="transparent")
        controls.grid(row=3, column=0, columnspan=4, sticky="ew", padx=pad["sm"], pady=pad["sm"])
        self.start_button = ctk.CTkButton(controls, text=f"{theme.icon('play')}  Start campaign",
                                          width=170, height=38,
                                          font=theme.font(weight="bold"),
                                          command=self.start_campaign)
        self.start_button.pack(side="left", padx=(0, pad["sm"]))
        self.pause_button = ctk.CTkButton(controls, text=f"{theme.icon('pause')}  Pause",
                                          width=110, height=38,
                                          command=self.app.pause_campaign,
                                          **theme.secondary_button())
        self.pause_button.pack(side="left", padx=pad["xs"])
        self.resume_button = ctk.CTkButton(controls, text=f"{theme.icon('play')}  Resume",
                                           width=110, height=38,
                                           command=self.app.resume_campaign,
                                           **theme.secondary_button())
        self.resume_button.pack(side="left", padx=pad["xs"])
        self.stop_button = ctk.CTkButton(controls, text=f"{theme.icon('stop')}  Stop",
                                         width=110, height=38,
                                         command=self.app.stop_campaign,
                                         **theme.danger_button())
        self.stop_button.pack(side="left", padx=(pad["lg"], 0))

        self.progress = ctk.CTkProgressBar(bulk)
        self.progress.set(0)
        self.progress.grid(row=4, column=0, columnspan=4, sticky="ew", padx=pad["md"], pady=(pad["md"], pad["xs"]))

        stats = ctk.CTkFrame(bulk, fg_color="transparent")
        stats.grid(row=5, column=0, columnspan=4, sticky="ew", padx=pad["md"], pady=(0, pad["md"]))
        self.success_label = ctk.CTkLabel(stats, text="Successful: 0",
                                          text_color=theme.color("success"),
                                          font=theme.font(weight="bold"))
        self.success_label.pack(side="left", padx=(0, pad["lg"]))
        self.failed_label = ctk.CTkLabel(stats, text="Failed: 0",
                                         text_color=theme.color("danger"),
                                         font=theme.font(weight="bold"))
        self.failed_label.pack(side="left", padx=(0, pad["lg"]))
        self.pending_label = ctk.CTkLabel(stats, text="Pending: 0",
                                          text_color=theme.color("text_muted"))
        self.pending_label.pack(side="left", padx=(0, pad["lg"]))
        self.state_label = ctk.CTkLabel(stats, text="State: idle",
                                        text_color=theme.color("text_muted"))
        self.state_label.pack(side="left")

        self.preview_label = ctk.CTkLabel(bulk, text="", wraplength=720, justify="left",
                                          text_color=theme.color("text_muted"),
                                          font=theme.font(theme.TEXT_SM))
        self.preview_label.grid(row=6, column=0, columnspan=4, sticky="w", padx=pad["md"], pady=(0, pad["md"]))

    # ------------------------------------------------------------- helpers --
    def message_text(self) -> str:
        return self.message_box.get("1.0", "end").strip()

    def _update_preview(self) -> None:
        if not self.contacts:
            self.preview_label.configure(text="")
            return
        first = self.contacts[0]
        preview = personalize(self.message_text(), first.as_context())
        self.preview_label.configure(text=f"Preview for {first.name or first.phone}: {preview}")

    # -------------------------------------------------------------- import --
    def _load(self, path: str, importer) -> None:
        try:
            result = importer(path, self.app.app_config.default_country_code)
        except Exception as exc:  # noqa: BLE001 - surface any importer failure
            log.exception("Import failed")
            self.app.show_message("Import failed", str(exc), error=True)
            return
        self.contacts = result.contacts
        self.count_label.configure(text=f"Contacts: {result.count}")
        self.file_label.configure(text=path)
        summary = f"Loaded {result.count} contact(s); {result.duplicates} duplicate(s) skipped"
        if result.errors:
            summary += f"; {len(result.errors)} row(s) rejected"
            self.app.show_message(
                "Import finished with problems",
                summary + "\n\n" + "\n".join(result.errors[:25]),
            )
        self.app.set_status_line(summary)
        self._update_preview()

    def import_csv(self) -> None:
        path = filedialog.askopenfilename(
            title="Import contacts (CSV)",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if path:
            self._load(path, import_csv)

    def import_xlsx(self) -> None:
        path = filedialog.askopenfilename(
            title="Import contacts (XLSX)",
            filetypes=[("Excel files", "*.xlsx *.xlsm"), ("All files", "*.*")])
        if path:
            self._load(path, import_xlsx)

    # ------------------------------------------------------------- actions --
    def send_test(self) -> None:
        if not self.app.require_connection():
            return
        raw = self.recipient_var.get().strip()
        try:
            recipient = normalize_phone(raw, self.app.app_config.default_country_code)
        except PhoneError as exc:
            self.app.show_message("Invalid number", str(exc), error=True)
            return
        body = self.message_text()
        if not body:
            self.app.show_message("Empty message", "Type a message first.", error=True)
            return
        # A single send goes through the same queue, rate limiter and retry path.
        name = self.single_name_var.get().strip()
        body = personalize(body, {"name": name, "phone": recipient})
        message_id = self.app.send_single(recipient, body, name)
        if message_id is None:
            self.app.show_message(
                "Duplicate", "That exact message is already queued for this number.")
        else:
            self.app.set_status_line(f"Queued {message_id[:8]} -> +{recipient}")

    def start_campaign(self) -> None:
        if not self.app.require_connection():
            return
        if not self.contacts:
            self.app.show_message("No contacts", "Import a CSV or XLSX file first.", error=True)
            return
        body = self.message_text()
        if not body:
            self.app.show_message("Empty message", "Type a message first.", error=True)
            return
        one_per_number = bool(self.one_per_number_var.get())
        queued, skipped = self.app.start_campaign(self.contacts, body, one_per_number)
        reason = ("repeat or already-messaged number" if one_per_number
                  else "duplicate message")
        self.app.set_status_line(
            f"Campaign started: {queued} queued, {skipped} skipped ({reason})")

    # -------------------------------------------------------------- events --
    def update_stats(self, stats: dict) -> None:
        total = max(1, stats.get("total", 0))
        processed = stats.get("processed", 0)
        # Ease the bar to its new value: a campaign at one message a second
        # otherwise jumps, and the jump reads as a glitch rather than progress.
        target = min(1.0, processed / total)
        anim.stop(self._progress_anim)
        self._progress_anim = anim.animate(
            self, self._progress, target, 320, self._set_progress)
        self._progress = target
        self.success_label.configure(text=f"Successful: {stats.get('successful', 0)}")
        self.failed_label.configure(text=f"Failed: {stats.get('failed', 0)}")
        self.pending_label.configure(text=f"Pending: {stats.get('pending', 0)}")
        self.state_label.configure(text=f"State: {stats.get('state', 'idle')}")

    def _set_progress(self, value: float) -> None:
        try:
            self.progress.set(value)
        except Exception:  # noqa: BLE001 - window closing mid-animation
            pass
