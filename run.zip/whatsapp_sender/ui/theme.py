"""Design tokens for the whole GUI: colour, type, spacing, icons.

Deep navy surfaces, WhatsApp green for action, blue for configuration, amber
for advisories and red for destructive work.  Every value is a token: views
never hard-code a hex, so light and dark stay in step and one edit here
re-skins the app.

Colours are ``(light, dark)`` pairs, exactly what CustomTkinter widgets take.
The matching widget defaults live in ``assets/azure.json``, generated from
these tokens by ``python -m whatsapp_sender.ui.build_theme``.
"""

from __future__ import annotations

import tkinter as tk
from tkinter import font as tkfont
from pathlib import Path

import customtkinter as ctk

THEME_PATH = Path(__file__).resolve().parent / "assets" / "azure.json"

COLORS: dict[str, tuple[str, str]] = {
    "canvas": ("#F1F5F9", "#0C161F"),        # app background
    "rail": ("#FFFFFF", "#0A1119"),          # navigation rail
    "surface": ("#FFFFFF", "#111E2A"),       # cards
    "surface_alt": ("#EEF3F8", "#18293A"),   # inputs, nested panels
    "border": ("#DCE5EC", "#22384A"),
    "text": ("#0D1B24", "#E7F0F7"),
    "text_muted": ("#5C7285", "#8CA3B7"),

    # WhatsApp green: connection, sending, anything that means "live"
    "primary": ("#12A150", "#25D366"),
    "primary_hover": ("#0E8B44", "#1FBF5C"),
    "primary_soft": ("#DCFCE7", "#10331F"),
    "on_primary": ("#FFFFFF", "#04150B"),
    "success": ("#12A150", "#25D366"),
    "success_soft": ("#DCFCE7", "#10331F"),

    # Blue: configuration and neutral information
    "accent": ("#2563EB", "#3B82F6"),
    "accent_soft": ("#DBEAFE", "#132A46"),

    "warning": ("#B45309", "#FBBF24"),
    "warning_soft": ("#FEF3C7", "#2E2410"),
    "danger": ("#DC2626", "#F05252"),
    "danger_hover": ("#B91C1C", "#DC2626"),
    "danger_soft": ("#FEE2E2", "#33171A"),
}

#: 4/8 spacing rhythm - no ad-hoc paddings in the views.
SPACE = {"xs": 4, "sm": 8, "md": 12, "lg": 16, "xl": 24}

FONT_FAMILY = "Segoe UI"
FONT_MONO = "Consolas"
TEXT_XS, TEXT_SM, TEXT_BASE, TEXT_LG, TEXT_XL, TEXT_2XL = 11, 12, 13, 15, 19, 23

RADIUS = 12
RADIUS_SM = 8

#: Windows ships a monochrome icon font, so the UI gets real icons with no
#: dependency, no bitmaps and no emoji.  Glyphs tint with text_color.
ICON_FAMILIES = ("Segoe Fluent Icons", "Segoe MDL2 Assets")
ICONS = {
    "connection": "",   # wifi
    "message": "",
    "history": "",
    "settings": "",
    "light": "",        # brightness
    "dark": "",         # moon
    "check": "",        # completed, solid
    "globe": "",
    "bolt": "",
    "refresh": "",
    "timer": "",
    "clock": "",
    "link": "",
    "save": "",
    "block": "",
    "info": "",
    "send": "",
    "chart": "",
    "import": "",
    "play": "",
    "pause": "",
    "stop": "",
    "filter": "",
    "key": "",
    "phone": "",
    "warning": "",
    "swap": "",
}

_icon_family: str | None = None
#: CTkFont objects are Tk resources: building one per label costs real
#: milliseconds at startup, and they are immutable here, so they are shared.
_font_cache: dict[tuple, ctk.CTkFont] = {}
_logo_cache: dict[int, tk.PhotoImage] = {}


def icon_family() -> str:
    """The icon font actually installed, or the text font as a last resort."""
    global _icon_family
    if _icon_family is None:
        try:
            available = set(tkfont.families())
        except Exception:  # noqa: BLE001 - no Tk root yet
            available = set()
        _icon_family = next((f for f in ICON_FAMILIES if f in available), FONT_FAMILY)
    return _icon_family


def icon(name: str) -> str:
    """The glyph for a semantic icon name (empty when no icon font is present)."""
    if icon_family() == FONT_FAMILY:
        return ""
    return ICONS.get(name, "")


def icon_font(size: int = 16) -> ctk.CTkFont:
    key = ("icon", size)
    if key not in _font_cache:
        _font_cache[key] = ctk.CTkFont(family=icon_family(), size=size)
    return _font_cache[key]


def logo(size: int = 48):
    """The app mark at one of the exported sizes, loaded once.

    Tk reads PNG natively, so the logo needs no imaging library.
    """
    if size not in _logo_cache:
        path = THEME_PATH.parent / f"logo_{size}.png"
        _logo_cache[size] = tk.PhotoImage(file=str(path))
    return _logo_cache[size]


def color(token: str) -> tuple[str, str]:
    """The (light, dark) pair for a token - pass it straight to a widget."""
    return COLORS[token]


def resolve(token: str) -> str:
    """The single hex value for the appearance mode in effect right now.

    Needed for the plain Tk / ttk widgets (the history table), which know
    nothing about CustomTkinter's light/dark pairs.
    """
    light, dark = COLORS[token]
    return dark if ctk.get_appearance_mode().lower() == "dark" else light


def font(size: int = TEXT_BASE, weight: str = "normal") -> ctk.CTkFont:
    key = (FONT_FAMILY, size, weight)
    if key not in _font_cache:
        _font_cache[key] = ctk.CTkFont(family=FONT_FAMILY, size=size, weight=weight)
    return _font_cache[key]


def apply(appearance_mode: str = "system") -> None:
    """Install the palette. Call once before building any widget."""
    ctk.set_appearance_mode(appearance_mode if appearance_mode in
                            {"system", "light", "dark"} else "system")
    ctk.set_default_color_theme(str(THEME_PATH))


# --------------------------------------------------------------- recipes --
def card(master, **overrides):
    """A panel on the app canvas - the unit of layout."""
    kwargs = dict(fg_color=color("surface"), border_color=color("border"),
                  border_width=1, corner_radius=RADIUS)
    kwargs.update(overrides)
    return ctk.CTkFrame(master, **kwargs)


def icon_badge(master, name: str, tone: str = "accent", size: int = 38):
    """The rounded, tinted icon square that heads a card."""
    return ctk.CTkLabel(
        master, text=icon(name), width=size, height=size, corner_radius=RADIUS_SM,
        fg_color=color(f"{tone}_soft"), text_color=color(tone),
        font=icon_font(int(size * 0.45)),
    )


def card_header(master, name: str, title: str, subtitle: str = "", tone: str = "accent"):
    """Badge + title + subtitle, the header every card in this app wears."""
    header = ctk.CTkFrame(master, fg_color="transparent")
    header.grid_columnconfigure(1, weight=1)
    icon_badge(header, name, tone).grid(row=0, column=0, rowspan=2,
                                        padx=(0, SPACE["md"]), sticky="w")
    ctk.CTkLabel(header, text=title, font=font(TEXT_LG, "bold"),
                 text_color=color("text")).grid(row=0, column=1, sticky="sw")
    if subtitle:
        ctk.CTkLabel(header, text=subtitle, font=font(TEXT_SM),
                     text_color=color("text_muted")).grid(row=1, column=1, sticky="nw")
    return header


def secondary_button(**overrides) -> dict:
    """Subordinate action: same shape as the primary, quieter surface."""
    kwargs = dict(
        fg_color=color("surface_alt"),
        hover_color=color("accent_soft"),
        border_width=1,
        border_color=color("border"),
        text_color=color("text"),
    )
    kwargs.update(overrides)
    return kwargs


def danger_button(**overrides) -> dict:
    """Destructive action: semantic colour, kept away from the primary."""
    kwargs = dict(
        fg_color=color("danger"),
        hover_color=color("danger_hover"),
        text_color=("#FFFFFF", "#FFFFFF"),
    )
    kwargs.update(overrides)
    return kwargs


def neutral_option_menu(**overrides) -> dict:
    """An option menu that reads as a control, not as a primary action."""
    kwargs = dict(
        fg_color=color("surface_alt"),
        button_color=color("border"),
        button_hover_color=color("accent"),
        text_color=color("text"),
    )
    kwargs.update(overrides)
    return kwargs


def style_treeview(style, widget: tk.Widget | None = None) -> None:
    """Paint the ttk history table with the same palette.

    ttk sits outside CustomTkinter's theming, so its colours are resolved for
    the current mode and re-applied whenever the mode changes.
    """
    try:
        style.theme_use("clam")
    except tk.TclError:  # pragma: no cover - platform dependent
        pass
    surface, alt = resolve("surface"), resolve("surface_alt")
    text, muted = resolve("text"), resolve("text_muted")
    style.configure(
        "History.Treeview",
        background=surface,
        fieldbackground=surface,
        foreground=text,
        bordercolor=resolve("border"),
        borderwidth=0,
        rowheight=30,
        font=(FONT_FAMILY, 9),
    )
    style.configure(
        "History.Treeview.Heading",
        background=alt,
        foreground=muted,
        relief="flat",
        padding=(8, 8),
        font=(FONT_FAMILY, 9, "bold"),
    )
    style.map(
        "History.Treeview.Heading",
        background=[("active", resolve("accent_soft"))],
        foreground=[("active", text)],
    )
    style.map(
        "History.Treeview",
        background=[("selected", resolve("primary_soft"))],
        foreground=[("selected", text)],
    )
    for orient in ("Vertical", "Horizontal"):
        style.configure(
            f"History.{orient}.TScrollbar",
            background=alt, troughcolor=surface, bordercolor=surface,
            arrowcolor=muted, relief="flat",
        )
