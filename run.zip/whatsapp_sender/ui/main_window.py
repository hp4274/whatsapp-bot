"""Main window: owns the config, the database, the transport and the engine."""

from __future__ import annotations

import queue
import tkinter as tk
from tkinter import messagebox

import customtkinter as ctk

from ..campaign.manager import CampaignManager
from ..config import TRANSPORT_CLOUD_API, Config
from ..database import Database
from ..logger import get_logger
from ..protocol import Contact, Status
from ..transports import create_transport
from ..transports.base import Transport
from ..transports.whatsapp_transport import CloudAPITransport, WebhookReceiver
from . import anim, theme
from .campaign_view import CampaignView
from .connection_view import ConnectionView
from .history_view import HistoryView

log = get_logger("ui.main")


class MainWindow(ctk.CTk):
    def __init__(self, config: Config, db: Database) -> None:
        super().__init__()
        self.app_config = config
        self.db = db
        self.transport: Transport | None = None
        self.webhook: WebhookReceiver | None = None
        self.events: queue.Queue[dict] = queue.Queue()
        self._history_dirty = False
        self._current_view = "connection"
        self._live_pulse = None

        self.manager = CampaignManager(db, _NullTransport(), config, on_event=self.post_event)

        theme.apply(config.appearance_mode)
        anim.ENABLED = bool(config.animations)
        self.title("WhatsApp Sender")
        try:
            self.iconphoto(True, theme.logo(256))
        except Exception:  # noqa: BLE001 - a missing icon must not stop the app
            log.warning("Could not set the window icon")
        self.geometry("1400x900")
        self.minsize(1120, 720)
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self._build()
        self.after(200, self._drain_events)
        self.after(3000, self._periodic_history_refresh)

    # NOTE: the application settings live in ``app_config``; ``config`` is
    # Tk's own widget method and must not be shadowed.

    # --------------------------------------------------------------- build --
    def _build(self) -> None:
        pad = theme.SPACE
        self.configure(fg_color=theme.color("canvas"))
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self._build_header(pad)
        self._build_rail(pad)

        self.content = ctk.CTkFrame(self, fg_color="transparent")
        self.content.grid(row=1, column=1, sticky="nsew",
                          padx=(pad["sm"], pad["lg"]), pady=(pad["sm"], pad["lg"]))
        self.content.grid_columnconfigure(0, weight=1)
        self.content.grid_rowconfigure(0, weight=1)

        self.connection_view = ConnectionView(self.content, self)
        self.campaign_view = CampaignView(self.content, self)
        self.history_view = HistoryView(self.content, self)
        self.views = {
            "connection": self.connection_view,
            "campaign": self.campaign_view,
            "history": self.history_view,
        }
        for view in self.views.values():
            view.grid(row=0, column=0, sticky="nsew")
            view.grid_remove()
        self.show_view("connection")

    def _build_header(self, pad: dict) -> None:
        header = ctk.CTkFrame(self, fg_color=theme.color("rail"), corner_radius=0, height=88)
        header.grid(row=0, column=0, columnspan=2, sticky="ew")
        header.grid_columnconfigure(1, weight=1)
        header.grid_propagate(False)

        # tk.Label, not CTkLabel: CTkImage needs Pillow, and a plain PhotoImage
        # in a CTkLabel only earns a HighDPI warning.
        self.brand = tk.Label(header, image=theme.logo(48), borderwidth=0,
                              highlightthickness=0, background=theme.resolve("rail"))
        self.brand.grid(row=0, column=0, rowspan=2, padx=(pad["lg"], pad["md"]), pady=pad["lg"])

        titles = ctk.CTkFrame(header, fg_color="transparent")
        titles.grid(row=0, column=1, rowspan=2, sticky="w")
        ctk.CTkLabel(titles, text="WhatsApp Sender", anchor="w",
                     font=theme.font(theme.TEXT_2XL, "bold")).pack(anchor="w")
        self.header_subtitle = ctk.CTkLabel(
            titles, text="Not connected", anchor="w",
            text_color=theme.color("text_muted"), font=theme.font(theme.TEXT_SM))
        self.header_subtitle.pack(anchor="w")

        modes = ctk.CTkFrame(header, fg_color=theme.color("surface_alt"),
                             corner_radius=theme.RADIUS, border_width=1,
                             border_color=theme.color("border"))
        modes.grid(row=0, column=2, rowspan=2, padx=pad["md"], pady=pad["lg"])
        self.mode_buttons: dict[str, ctk.CTkButton] = {}
        self.MODES = (("system", "Auto", "settings"),
                      ("light", "Light", "light"),
                      ("dark", "Dark", "dark"))
        for column, (mode, label, glyph) in enumerate(self.MODES):
            button = ctk.CTkButton(
                modes, text=f"{theme.icon(glyph)}  {label}", width=92, height=36,
                corner_radius=theme.RADIUS_SM, font=theme.font(theme.TEXT_SM, "bold"),
                command=lambda m=mode: self._set_appearance(m),
                fg_color="transparent", hover_color=theme.color("accent_soft"),
                text_color=theme.color("text_muted"),
            )
            button.grid(row=0, column=column, padx=4, pady=4)
            self.mode_buttons[mode] = button
        self._paint_mode_buttons()

    def _build_rail(self, pad: dict) -> None:
        rail = ctk.CTkFrame(self, fg_color=theme.color("rail"), corner_radius=0, width=236)
        rail.grid(row=1, column=0, sticky="nsw")
        rail.grid_propagate(False)
        rail.grid_rowconfigure(9, weight=1)

        self.nav_buttons: dict[str, ctk.CTkButton] = {}
        for index, (key, label, glyph) in enumerate((
            ("connection", "Connection", "connection"),
            ("campaign", "Messaging & Campaign", "message"),
            ("history", "History", "history"),
        )):
            button = ctk.CTkButton(
                rail, text=f"  {theme.icon(glyph)}   {label}", anchor="w",
                height=48, corner_radius=theme.RADIUS_SM,
                font=theme.font(theme.TEXT_BASE, "bold"),
                fg_color="transparent", hover_color=theme.color("surface_alt"),
                text_color=theme.color("text_muted"),
                command=lambda k=key: self.show_view(k),
            )
            button.grid(row=index, column=0, sticky="ew", padx=pad["md"], pady=(pad["sm"], 0))
            self.nav_buttons[key] = button

        # Bottom-left status chip: the one place that always says what the app
        # is doing, colour plus dot so it never depends on colour alone.
        chip = theme.card(rail, fg_color=theme.color("surface"))
        chip.grid(row=10, column=0, sticky="ew", padx=pad["md"], pady=pad["md"])
        chip.grid_columnconfigure(1, weight=1)
        self.status_dot = ctk.CTkLabel(chip, text="\u25cf", width=16,
                                       text_color=theme.color("text_muted"),
                                       font=theme.font(theme.TEXT_LG))
        self.status_dot.grid(row=0, column=0, rowspan=2, padx=(pad["md"], pad["sm"]),
                             pady=pad["md"])
        self.status_line = ctk.CTkLabel(chip, text="Ready.", anchor="w", justify="left",
                                        wraplength=150, text_color=theme.color("text"),
                                        font=theme.font(theme.TEXT_SM, "bold"))
        self.status_line.grid(row=0, column=1, sticky="ew", pady=(pad["md"], 0))
        ctk.CTkLabel(chip, text="WhatsApp Sender v1.0", anchor="w",
                     text_color=theme.color("text_muted"),
                     font=theme.font(theme.TEXT_XS)).grid(
            row=1, column=1, sticky="ew", pady=(0, pad["md"]))

    def set_live(self, live: bool) -> None:
        """Breathe the status dot while a session is live, stop when it is not."""
        anim.stop(self._live_pulse)
        self._live_pulse = None
        if live:
            self._live_pulse = anim.pulse(
                self, lambda c: self.status_dot.configure(text_color=c),
                theme.resolve("primary"), theme.resolve("primary_soft"))
            if self._live_pulse is None:  # animations off
                self.status_dot.configure(text_color=theme.color("primary"))
        else:
            self.status_dot.configure(text_color=theme.color("text_muted"))

    def show_view(self, key: str) -> None:
        """Swap the content area. The rail shows which view is current."""
        for name, view in self.views.items():
            if name == key:
                view.grid()
            else:
                view.grid_remove()
        for name, button in self.nav_buttons.items():
            active = name == key
            button.configure(
                fg_color=theme.color("primary_soft") if active else "transparent",
                text_color=theme.color("primary") if active else theme.color("text_muted"),
            )
        self._current_view = key
        if key == "history":
            # The table only repaints when it is the view on screen.
            self.after_idle(lambda: self.history_view.refresh(force=True))

    def _paint_mode_buttons(self) -> None:
        current = self.app_config.appearance_mode
        for mode, _label, _glyph in self.MODES:
            active = mode == current
            self.mode_buttons[mode].configure(
                fg_color=theme.color("accent") if active else "transparent",
                text_color=("#FFFFFF", "#FFFFFF") if active else theme.color("text_muted"),
            )

    def _set_appearance(self, mode: str) -> None:
        ctk.set_appearance_mode(mode)
        self.app_config.appearance_mode = mode
        try:
            self.app_config.save()
        except OSError:  # pragma: no cover - a read-only profile must not crash the UI
            log.warning("Could not persist the appearance mode")
        self._paint_mode_buttons()
        self.brand.configure(background=theme.resolve("rail"))  # plain Tk widget
        self.history_view.restyle()
        self.set_live(self._live_pulse is not None)

    # ------------------------------------------------------------ plumbing --
    def set_status_line(self, text: str, tone: str = "text_muted") -> None:
        self.status_line.configure(text=text, text_color=theme.color(tone))
        self.status_dot.configure(text_color=theme.color(tone))
        log.info("%s", text)

    def show_message(self, title: str, message: str, error: bool = False) -> None:
        (messagebox.showerror if error else messagebox.showinfo)(title, message, parent=self)

    def post_event(self, event: dict) -> None:
        """Thread-safe: worker threads drop events here, Tk drains them."""
        self.events.put(event)

    def _drain_events(self) -> None:
        try:
            while True:
                event = self.events.get_nowait()
                try:
                    self._handle_event(event)
                except Exception:  # noqa: BLE001 - never break the Tk loop
                    log.exception("Event handling failed: %s", event.get("type"))
        except queue.Empty:
            pass
        self.after(200, self._drain_events)

    def _handle_event(self, event: dict) -> None:
        kind = event.get("type")
        if kind == "stats":
            self.campaign_view.update_stats(event["stats"])
        elif kind in {"status", "message", "receipt", "history_dirty"}:
            self._history_dirty = True
            if kind == "status" and event.get("status") is Status.FAILED and event.get("error"):
                self.set_status_line(f"FAILED {event['message_id'][:8]}: {event['error']}",
                                     tone="danger")
        elif kind == "qr":
            self.connection_view.show_qr(event["qr"], event.get("image"))
            self.set_status_line("Scan the QR code to link WhatsApp.", tone="primary")
        elif kind == "connection":
            self._handle_connection_event(event)
        elif kind == "connection_lost":
            self.connection_view.show_connection(False, f"Disconnected: {event.get('error', '')}")
            self.set_live(False)
            self.header_subtitle.configure(text="Connection lost",
                                           text_color=theme.color("danger"))
            self.set_status_line(f"Connection lost: {event.get('error', '')}", tone="danger")

    def _periodic_history_refresh(self) -> None:
        # Nothing to repaint unless something changed AND the table is on
        # screen: a running campaign used to rebuild 1000 rows every 3s behind
        # the other tabs.
        if self._history_dirty and self._current_view == "history":
            self._history_dirty = False
            try:
                self.history_view.refresh()
            except tk.TclError:  # pragma: no cover - window closing
                return
        self.after(3000, self._periodic_history_refresh)

    # ----------------------------------------------------------- transport --
    def build_transport(self) -> Transport:
        return create_transport(self.app_config)

    def apply_config(self, config: Config) -> None:
        self.app_config = config
        self.manager.apply_config(config)

    def _handle_connection_event(self, event: dict) -> None:
        if not event.get("connected"):
            self.connection_view.show_connection(False, "Connection failed")
            self.header_subtitle.configure(text="Connection failed",
                                           text_color=theme.color("danger"))
            self.show_message("Connection failed", event.get("error", "unknown error"), error=True)
            return

        transport = event["transport"]
        info = event["info"]
        self.transport = transport
        self.manager.set_transport(transport)
        self.manager.start()
        label = f"Connected - {transport.name}"
        if info.account:
            label += f" [{info.account}]"
        self.connection_view.show_connection(True, label, real_delivery=transport.real_delivery)
        self.connection_view.show_session(info.account)
        self.set_live(True)
        self.header_subtitle.configure(
            text=f"Connected - {transport.name}", text_color=theme.color("success"))
        self.set_status_line(label, tone="success")
        if hasattr(transport, "set_receipt_callback"):
            # whatsapp-web.js reports ACKs through the bridge, not a webhook.
            transport.set_receipt_callback(self._on_receipt)
        self._start_webhook_if_needed(transport)

    def _start_webhook_if_needed(self, transport: Transport) -> None:
        self._stop_webhook()
        if not (self.app_config.webhook_enabled and isinstance(transport, CloudAPITransport)):
            return
        try:
            self.webhook = WebhookReceiver(self.app_config, self._on_receipt)
            port = self.webhook.start()
            self.set_status_line(f"Webhook receiver listening on port {port}")
        except OSError as exc:
            self.webhook = None
            self.show_message("Webhook error", f"Could not start the receiver: {exc}", error=True)

    def _on_receipt(self, provider_id: str, status: Status, error: str | None) -> None:
        if isinstance(self.transport, CloudAPITransport):
            self.transport.record_receipt(provider_id, status)
        self.manager.handle_receipt(provider_id, status, error)

    def _stop_webhook(self) -> None:
        if self.webhook is not None:
            self.webhook.stop()
            self.webhook = None

    def disconnect_transport(self) -> None:
        self.manager.stop()
        self._stop_webhook()
        if self.transport is not None:
            try:
                self.transport.disconnect()
            except Exception:  # noqa: BLE001
                log.exception("Disconnect failed")
        self.transport = None
        self.manager.set_transport(_NullTransport())
        self.connection_view.show_connection(False, "Disconnected")
        self.set_live(False)
        self.header_subtitle.configure(text="Not connected",
                                       text_color=theme.color("text_muted"))
        self.set_status_line("Disconnected.")

    def require_connection(self) -> bool:
        if self.transport is not None and self.transport.is_connected():
            return True
        self.show_message("Not connected", "Connect a transport on the Connection tab first.",
                          error=True)
        return False

    # ------------------------------------------------------------ campaign --
    def send_single(self, recipient: str, message: str, name: str = "") -> str | None:
        self.manager.start()
        return self.manager.enqueue_single(recipient, message, name)

    def start_campaign(self, contacts: list[Contact], template: str,
                       one_per_number: bool = False) -> tuple[int, int]:
        self.manager.reset_stats()
        self.manager.queue.reset()
        queued, skipped = self.manager.enqueue_contacts(
            contacts, template, one_per_number=one_per_number)
        self.manager.start()
        return queued, skipped

    def pause_campaign(self) -> None:
        self.manager.pause()
        self.set_status_line("Campaign paused.")

    def resume_campaign(self) -> None:
        self.manager.resume()
        self.set_status_line("Campaign resumed.")

    def stop_campaign(self) -> None:
        self.manager.stop()
        self.set_status_line("Campaign stopped.")

    # --------------------------------------------------------------- close --
    def on_close(self) -> None:
        log.info("Shutting down")
        try:
            self.manager.shutdown()
            self._stop_webhook()
            if self.transport is not None:
                self.transport.disconnect()
            self.db.close()
        finally:
            self.destroy()


class _NullTransport(Transport):
    """Placeholder used before Connect is pressed. It never pretends to send."""

    name = "not connected"
    real_delivery = False

    def connect(self):  # pragma: no cover - never called
        raise NotImplementedError

    def disconnect(self) -> None:
        return None

    def send_message(self, recipient: str, message: str):
        from ..transports.base import TransportConnectionError

        raise TransportConnectionError("No transport connected", retryable=False)

    def get_status(self, message_id: str):
        return None

    def is_connected(self) -> bool:
        return False
