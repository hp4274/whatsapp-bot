"""Connection / account configuration tab."""

from __future__ import annotations

import threading
import tkinter as tk

import customtkinter as ctk

from ..config import TRANSPORT_CLOUD_API, TRANSPORT_SANDBOX, TRANSPORT_WEB_JS, Config
from ..logger import get_logger
from ..transports.base import TransportError
from . import anim, theme

log = get_logger("ui.connection")

TRANSPORT_LABELS = {
    "WhatsApp Business Cloud API (real delivery, needs access token)": TRANSPORT_CLOUD_API,
    "WhatsApp Web / whatsapp-web.js (real delivery, QR login, no token)": TRANSPORT_WEB_JS,
    "Local sandbox (testing only - NOT delivered)": TRANSPORT_SANDBOX,
}

WEB_JS_WARNING = (
    "WhatsApp Web transport: scan the QR code shown in the console window. No access token "
    "is used. This is NOT an official API - it violates the WhatsApp Terms of Service and "
    "bulk sending can get your number banned."
)
LABEL_BY_VALUE = {v: k for k, v in TRANSPORT_LABELS.items()}

#: icon + one line saying what each setting actually does
FIELD_HELP = {
    'phone_number_id': ('phone', 'The WhatsApp Business number id from your Meta app'),
    'access_token': ('key', 'Bearer token with whatsapp_business_messaging'),
    'graph_version': ('globe', 'Graph API version to call'),
    'template_name': ('message', 'Approved template used outside the 24h window'),
    'template_language': ('globe', 'Template language code, e.g. en_US'),
    'rate_limit_per_second': ('bolt', 'Maximum number of messages to send per second'),
    'max_retries': ('refresh', 'Number of retry attempts on failure'),
    'retry_delay': ('clock', 'Initial delay before retrying (seconds)'),
    'retry_backoff': ('swap', 'Multiplier for each retry delay'),
    'request_timeout': ('timer', 'Maximum time to wait for a response'),
    'default_country_code': ('globe', 'Country code for numbers without +'),
    'webhook_port': ('link', 'Local port the receiver listens on'),
    'webhook_verify_token': ('key', 'Shared secret Meta echoes back on verification'),
}


class ConnectionView(ctk.CTkFrame):
    def __init__(self, master, app) -> None:
        super().__init__(master)
        self.app = app
        self.vars: dict[str, tk.Variable] = {}
        self._qr_window: ctk.CTkToplevel | None = None
        self._spinner = None
        self._pill_pulse = None
        self._build()
        self.load_from_config(app.app_config)

    # --------------------------------------------------------------- build --
    def _build(self) -> None:
        pad = theme.SPACE
        self.configure(fg_color="transparent")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self._build_hero(pad)

        columns = ctk.CTkFrame(self, fg_color="transparent")
        columns.grid(row=1, column=0, sticky="nsew", pady=pad["md"])
        columns.grid_columnconfigure(0, weight=3)
        columns.grid_columnconfigure(1, weight=2, minsize=340)
        columns.grid_rowconfigure(0, weight=1)

        self._build_config(columns, pad)
        self._build_status_panel(columns, pad)
        self._build_actions(pad)
        self._set_action_states(False)  # nothing to disconnect yet

    # ------------------------------------------------------------- hero --
    def _build_hero(self, pad: dict) -> None:
        hero = theme.card(self, fg_color=theme.color("primary_soft"),
                          border_color=theme.color("primary"))
        hero.grid(row=0, column=0, sticky="ew")
        hero.grid_columnconfigure(1, weight=1)

        self.hero_badge = ctk.CTkLabel(
            hero, text=theme.icon("connection"), width=56, height=56, corner_radius=28,
            fg_color=theme.color("surface"), text_color=theme.color("primary"),
            font=theme.icon_font(24))
        self.hero_badge.grid(row=0, column=0, rowspan=2, padx=(pad["xl"], pad["lg"]),
                             pady=(pad["lg"], pad["sm"]))

        self.status_label = ctk.CTkLabel(hero, text="Disconnected", anchor="w",
                                         font=theme.font(theme.TEXT_XL, "bold"),
                                         text_color=theme.color("text"))
        self.status_label.grid(row=0, column=1, sticky="sw", pady=(pad["lg"], 0))
        self.hero_detail = ctk.CTkLabel(hero, text="No transport connected", anchor="w",
                                        font=theme.font(theme.TEXT_BASE),
                                        text_color=theme.color("text_muted"))
        self.hero_detail.grid(row=1, column=1, sticky="nw")

        self.status_pill = ctk.CTkLabel(
            hero, text="Offline", corner_radius=999, height=30, width=120,
            fg_color=theme.color("surface"), text_color=theme.color("text_muted"),
            font=theme.font(theme.TEXT_SM, "bold"))
        self.status_pill.grid(row=0, column=2, padx=pad["xl"], pady=(pad["lg"], 0), sticky="e")

        self.mode_label = ctk.CTkLabel(hero, text="", font=theme.font(theme.TEXT_SM),
                                       text_color=theme.color("text_muted"),
                                       wraplength=760, justify="left", anchor="w")
        self.mode_label.grid(row=2, column=0, columnspan=3, sticky="ew",
                             padx=pad["xl"], pady=(pad["sm"], pad["lg"]))

    # ----------------------------------------------------------- config --
    def _build_config(self, master, pad: dict) -> None:
        card = theme.card(master)
        card.grid(row=0, column=0, sticky="nsew", padx=(0, pad["md"]))
        card.grid_columnconfigure(0, weight=1)

        theme.card_header(card, "settings", "Account Configuration",
                          "Configure your WhatsApp connection and delivery settings").grid(
            row=0, column=0, sticky="ew", padx=pad["lg"], pady=(pad["lg"], pad["md"]))

        ctk.CTkLabel(card, text="Transport", anchor="w",
                     font=theme.font(theme.TEXT_SM, "bold"),
                     text_color=theme.color("text_muted")).grid(
            row=1, column=0, sticky="w", padx=pad["lg"])
        self.transport_var = tk.StringVar(value=LABEL_BY_VALUE[TRANSPORT_CLOUD_API])
        ctk.CTkOptionMenu(
            card, values=list(TRANSPORT_LABELS), variable=self.transport_var,
            height=44, dynamic_resizing=False, font=theme.font(),
            command=lambda _=None: self._toggle_fields(), **theme.neutral_option_menu(),
        ).grid(row=2, column=0, sticky="new", padx=pad["lg"], pady=(pad["xs"], pad["md"]))

        body = ctk.CTkScrollableFrame(card, fg_color="transparent")
        body.grid(row=3, column=0, sticky="nsew", padx=pad["md"], pady=(0, pad["lg"]))
        body.grid_columnconfigure(0, weight=0)
        body.grid_columnconfigure(1, weight=1, minsize=120)   # the input never collapses
        body.grid_columnconfigure(2, weight=0, minsize=180)
        card.grid_rowconfigure(3, weight=1)

        self.cloud_widgets: list[tk.Widget] = []
        row = 0

        row = self._section(body, row, "settings", "Cloud API credentials",
                            "Only the Meta Cloud API needs these", cloud_only=True)
        for key, label, secret in (
            ("phone_number_id", "Phone Number ID", False),
            ("access_token", "Access Token", True),
            ("graph_version", "Graph API version", False),
            ("template_name", "Template name", False),
            ("template_language", "Template language", False),
        ):
            row = self._field(body, row, key, label, secret=secret, cloud_only=True)

        self.vars["use_template"] = tk.BooleanVar()
        chk = ctk.CTkCheckBox(
            body, text="Send as approved template (required outside the 24-hour window)",
            variable=self.vars["use_template"], font=theme.font())
        chk.grid(row=row, column=0, columnspan=3, sticky="w",
                 padx=pad["sm"], pady=pad["sm"])
        self.cloud_widgets.append(chk)
        row += 1

        row = self._section(body, row, "send", "Delivery Control",
                            "Configure message sending behavior and limits")
        for key, label in (
            ("rate_limit_per_second", "Rate limit (messages/second)"),
            ("max_retries", "Max retries"),
            ("retry_delay", "Retry base delay (s)"),
            ("retry_backoff", "Retry backoff factor"),
            ("request_timeout", "Request timeout (s)"),
            ("default_country_code", "Default country code"),
        ):
            row = self._field(body, row, key, label)

        row = self._section(body, row, "check", "Delivery receipts (DELIVERED / READ)",
                            "Meta reports these only through webhooks", cloud_only=True)
        self.vars["webhook_enabled"] = tk.BooleanVar()
        webhook_check = ctk.CTkCheckBox(body, text="Run local webhook receiver",
                                        variable=self.vars["webhook_enabled"],
                                        font=theme.font())
        webhook_check.grid(row=row, column=0, columnspan=3, sticky="w",
                           padx=pad["sm"], pady=pad["sm"])
        self.cloud_widgets.append(webhook_check)
        row += 1
        for key, label in (("webhook_port", "Webhook port"),
                           ("webhook_verify_token", "Webhook verify token")):
            row = self._field(body, row, key, label, cloud_only=True)

    def _section(self, body, row: int, glyph: str, title: str, subtitle: str,
                 cloud_only: bool = False) -> int:
        """A titled divider inside the configuration list."""
        header = theme.card_header(body, glyph, title, subtitle,
                                   tone="primary" if not cloud_only else "accent")
        header.grid(row=row, column=0, columnspan=3, sticky="ew",
                    padx=theme.SPACE["sm"], pady=(theme.SPACE["lg"], theme.SPACE["sm"]))
        if cloud_only:
            self.cloud_widgets.append(header)
        return row + 1

    def _field(self, body, row: int, key: str, label: str, secret: bool = False,
               cloud_only: bool = False) -> int:
        """One setting: icon + label, the input, and what it actually does."""
        pad = theme.SPACE
        glyph, helper = FIELD_HELP.get(key, ("settings", ""))
        name = ctk.CTkLabel(body, text=f"{theme.icon(glyph)}   {label}", anchor="w",
                            font=theme.font(), text_color=theme.color("text"))
        name.grid(row=row, column=0, sticky="w", padx=pad["sm"], pady=pad["xs"])
        var = tk.StringVar()
        self.vars[key] = var
        entry = ctk.CTkEntry(body, textvariable=var, height=38, width=120,
                             show="*" if secret else "", font=theme.font())
        entry.grid(row=row, column=1, sticky="ew", padx=pad["sm"], pady=pad["xs"])
        hint = ctk.CTkLabel(body, text=helper, anchor="w", justify="left", wraplength=160,
                            font=theme.font(theme.TEXT_XS),
                            text_color=theme.color("text_muted"),
                            fg_color=theme.color("canvas"),
                            corner_radius=theme.RADIUS_SM, height=44)
        hint.grid(row=row, column=2, sticky="ew", padx=(pad["sm"], pad["lg"]),
                  pady=pad["xs"])
        if cloud_only:
            self.cloud_widgets += [name, entry, hint]
        return row + 1

    # ----------------------------------------------------- status panel --
    def _build_status_panel(self, master, pad: dict) -> None:
        card = theme.card(master)
        card.grid(row=0, column=1, sticky="nsew")
        card.grid_columnconfigure(0, weight=1)

        theme.card_header(card, "chart", "Connection Status",
                          "Live status and session information", tone="primary").grid(
            row=0, column=0, sticky="ew", padx=pad["lg"], pady=(pad["lg"], pad["md"]))

        self.state_banner = ctk.CTkFrame(card, fg_color=theme.color("surface_alt"),
                                         corner_radius=theme.RADIUS_SM,
                                         border_width=1, border_color=theme.color("border"))
        self.state_banner.grid(row=1, column=0, sticky="ew", padx=pad["lg"])
        self.state_banner.grid_columnconfigure(1, weight=1)
        self.state_dot = ctk.CTkLabel(self.state_banner, text="\u25cf", width=18,
                                      text_color=theme.color("text_muted"),
                                      font=theme.font(theme.TEXT_LG))
        self.state_dot.grid(row=0, column=0, rowspan=2, padx=(pad["md"], pad["sm"]),
                            pady=pad["md"])
        self.state_title = ctk.CTkLabel(self.state_banner, text="Disconnected", anchor="w",
                                        font=theme.font(theme.TEXT_BASE, "bold"),
                                        text_color=theme.color("text"))
        self.state_title.grid(row=0, column=1, sticky="ew", pady=(pad["md"], 0))
        self.state_detail = ctk.CTkLabel(self.state_banner, text="No session", anchor="w",
                                         font=theme.font(theme.TEXT_XS),
                                         text_color=theme.color("text_muted"))
        self.state_detail.grid(row=1, column=1, sticky="ew", pady=(0, pad["md"]))

        rows = ctk.CTkFrame(card, fg_color="transparent")
        rows.grid(row=2, column=0, sticky="new", padx=pad["lg"], pady=pad["sm"])
        card.grid_rowconfigure(2, weight=1)
        rows.grid_columnconfigure(1, weight=1)
        self.status_values: dict[str, ctk.CTkLabel] = {}
        for index, (key, glyph, label) in enumerate((
            ("transport", "globe", "Transport"),
            ("session", "clock", "Session ID"),
            ("state", "check", "Status"),
            ("messages", "message", "Messages"),
            ("token", "key", "Access Token"),
        )):
            ctk.CTkLabel(rows, text=f"{theme.icon(glyph)}   {label}", anchor="w",
                         font=theme.font(theme.TEXT_SM),
                         text_color=theme.color("text_muted")).grid(
                row=index, column=0, sticky="w", pady=pad["xs"])
            value = ctk.CTkLabel(rows, text="-", anchor="e", font=theme.font(theme.TEXT_SM, "bold"),
                                 text_color=theme.color("text"))
            value.grid(row=index, column=1, sticky="e", pady=pad["xs"])
            self.status_values[key] = value
        self.status_values["state"].configure(text="Offline",
                                              text_color=theme.color("text_muted"))

        info = ctk.CTkFrame(card, fg_color=theme.color("warning_soft"),
                            corner_radius=theme.RADIUS_SM, border_width=1,
                            border_color=theme.color("warning"))
        info.grid(row=3, column=0, sticky="ew", padx=pad["lg"], pady=(0, pad["lg"]))
        info.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(info, text=theme.icon("info"), width=26,
                     text_color=theme.color("warning"), font=theme.icon_font(15)).grid(
            row=0, column=0, padx=(pad["md"], pad["sm"]), pady=(pad["md"], 0), sticky="nw")
        ctk.CTkLabel(info, text="Information", anchor="w",
                     font=theme.font(theme.TEXT_SM, "bold"),
                     text_color=theme.color("warning")).grid(
            row=0, column=1, sticky="w", pady=(pad["md"], 0))
        self.info_label = ctk.CTkLabel(
            info, text="", anchor="w", justify="left", wraplength=250,
            font=theme.font(theme.TEXT_XS), text_color=theme.color("text_muted"))
        self.info_label.grid(row=1, column=1, sticky="ew", padx=(0, pad["md"]),
                             pady=(pad["xs"], pad["md"]))

    # ---------------------------------------------------------- actions --
    def _build_actions(self, pad: dict) -> None:
        bar = ctk.CTkFrame(self, fg_color="transparent")
        bar.grid(row=2, column=0, sticky="ew")
        for column in range(4):
            bar.grid_columnconfigure(column, weight=1)

        self.connect_button = self._action(
            bar, 0, "link", "Connect", "Start or re-establish connection", self.connect,
            primary=True)
        self.save_button = self._action(
            bar, 1, "save", "Save Settings", "Save current configuration", self.save)
        self.reconnect_button = self._action(
            bar, 2, "refresh", "Reconnect", "Close and reconnect the session", self.reconnect)
        self.disconnect_button = self._action(
            bar, 3, "block", "Disconnect", "End current session", self.disconnect,
            danger=True)

    def _action(self, bar, column: int, glyph: str, title: str, subtitle: str,
                command, primary: bool = False, danger: bool = False) -> ctk.CTkButton:
        pad = theme.SPACE
        if primary:
            style = dict(fg_color=theme.color("primary"),
                         hover_color=theme.color("primary_hover"),
                         text_color=theme.color("on_primary"))
        elif danger:
            style = theme.danger_button()
        else:
            style = theme.secondary_button()
        button = ctk.CTkButton(
            bar, text=f"{theme.icon(glyph)}   {title}\n{subtitle}", height=64,
            corner_radius=theme.RADIUS, font=theme.font(theme.TEXT_BASE, "bold"),
            command=command, **style)
        button.grid(row=0, column=column, sticky="ew",
                    padx=(0 if column == 0 else pad["sm"], 0), pady=(pad["md"], 0))
        return button

    def _toggle_fields(self) -> None:
        transport = TRANSPORT_LABELS[self.transport_var.get()]
        is_cloud = transport == TRANSPORT_CLOUD_API
        # Progressive disclosure: the Cloud API fields only exist for the Cloud
        # API. Showing them greyed out for the other transports is just noise.
        for widget in self.cloud_widgets:
            if is_cloud:
                widget.grid()
            else:
                widget.grid_remove()
        if transport == TRANSPORT_SANDBOX:
            self.mode_label.configure(
                text="SANDBOX selected: messages are written to a local file, not delivered.",
                text_color=theme.color("warning"))
            info = ("Sandbox writes every message to a local file. Nothing reaches "
                    "WhatsApp, and the status stays SANDBOX.")
        elif transport == TRANSPORT_WEB_JS:
            self.mode_label.configure(text=WEB_JS_WARNING,
                                      text_color=theme.color("warning"))
            info = ("This is NOT an official WhatsApp API. It drives WhatsApp Web and may "
                    "violate the WhatsApp Terms of Service. Avoid bulk sending to prevent "
                    "your number from being banned.")
        else:
            self.mode_label.configure(
                text="Cloud API selected: messages are delivered by Meta.",
                text_color=theme.color("text_muted"))
            info = ("The official Cloud API. Free-form text only reaches users who "
                    "messaged you in the last 24 hours; outside that window send an "
                    "approved template.")
        self.info_label.configure(text=info)
        self.status_values["transport"].configure(
            text={TRANSPORT_CLOUD_API: "Cloud API", TRANSPORT_WEB_JS: "WhatsApp Web",
                  TRANSPORT_SANDBOX: "Sandbox"}[transport])
        self.status_values["token"].configure(
            text="Required" if is_cloud else "Not required")
        self.status_values["messages"].configure(
            text="Real delivery" if transport != TRANSPORT_SANDBOX else "Not delivered")

    # ---------------------------------------------------------------- data --
    def load_from_config(self, config: Config) -> None:
        self.transport_var.set(LABEL_BY_VALUE.get(config.transport,
                                                  LABEL_BY_VALUE[TRANSPORT_CLOUD_API]))
        for key, var in self.vars.items():
            value = getattr(config, key)
            if isinstance(var, tk.BooleanVar):
                var.set(bool(value))
            else:
                var.set("" if value is None else str(value))
        self._toggle_fields()

    def collect(self) -> tuple[Config | None, list[str]]:
        config = self.app.app_config
        config.transport = TRANSPORT_LABELS[self.transport_var.get()]
        errors: list[str] = []
        numeric = {
            "rate_limit_per_second": float,
            "max_retries": int,
            "retry_delay": float,
            "retry_backoff": float,
            "request_timeout": float,
            "webhook_port": int,
        }
        for key, var in self.vars.items():
            raw = var.get()
            if isinstance(var, tk.BooleanVar):
                setattr(config, key, bool(raw))
                continue
            caster = numeric.get(key)
            if caster is None:
                setattr(config, key, str(raw).strip())
                continue
            try:
                setattr(config, key, caster(str(raw).strip()))
            except ValueError:
                errors.append(f"{key}: '{raw}' is not a valid number")
        errors.extend(config.validate())
        return (None, errors) if errors else (config, [])

    # -------------------------------------------------------------- actions --
    def save(self) -> bool:
        config, errors = self.collect()
        if errors:
            self.app.show_message("Invalid settings", "\n".join(errors), error=True)
            return False
        config.save()
        self.app.apply_config(config)
        self.app.set_status_line("Settings saved.")
        return True

    def connect(self) -> None:
        if not self.save():
            return
        self._set_busy(True)
        threading.Thread(target=self._connect_worker, daemon=True).start()

    def _connect_worker(self) -> None:
        try:
            transport = self.app.build_transport()
            if hasattr(transport, "qr_callback"):
                transport.qr_callback = lambda qr: self.app.post_event(
                    {"type": "qr", "qr": qr, "image": transport.qr_image_path}
                )
            info = transport.connect()
        except TransportError as exc:
            self.app.post_event({"type": "connection", "connected": False, "error": str(exc)})
            return
        except Exception as exc:  # noqa: BLE001
            log.exception("Unexpected connect failure")
            self.app.post_event({"type": "connection", "connected": False,
                                 "error": f"Unexpected error: {exc}"})
            return
        self.app.post_event({"type": "connection", "connected": True, "info": info,
                             "transport": transport})

    def disconnect(self) -> None:
        self.app.disconnect_transport()

    def reconnect(self) -> None:
        self.app.disconnect_transport()
        self.connect()

    def _set_action_states(self, connected: bool) -> None:
        """Disconnect/Reconnect only make sense once something is connected.

        The disabled Disconnect also drops its danger colour, so it never reads
        as an armed destructive action.
        """
        self.reconnect_button.configure(state="normal" if connected else "disabled")
        if connected:
            self.disconnect_button.configure(state="normal", **theme.danger_button())
        else:
            self.disconnect_button.configure(
                state="disabled", fg_color=theme.color("surface_alt"),
                text_color=theme.color("text_muted"))

    def _set_busy(self, busy: bool) -> None:
        """Connecting can take a minute (QR scan), so say so while it runs."""
        state = "disabled" if busy else "normal"
        for button in (self.connect_button, self.reconnect_button):
            button.configure(state=state)
        anim.stop(self._spinner)
        self._spinner = None
        if busy:
            self._spinner = anim.spin(
                self, lambda frame: self.connect_button.configure(
                    text=f"{frame}   Connecting\nWaiting for the transport"))
            if self._spinner is None:  # animations off
                self.connect_button.configure(
                    text=f"{theme.icon('link')}   Connecting\nWaiting for the transport")
        else:
            self.connect_button.configure(
                text=f"{theme.icon('link')}   Connect\nStart or re-establish connection")

    def show_qr(self, qr: str, image_path: str | None) -> None:
        """Show the WhatsApp Web QR code. The GUI has no console to print it to."""
        if self._qr_window is not None and self._qr_window.winfo_exists():
            self._qr_window.destroy()
        window = ctk.CTkToplevel(self)
        window.title("Scan to link WhatsApp")
        window.attributes("-topmost", True)
        window.configure(fg_color=theme.color("canvas"))
        ctk.CTkLabel(window, text="Link this device",
                     font=theme.font(theme.TEXT_LG, "bold")).pack(
            padx=theme.SPACE["xl"], pady=(theme.SPACE["xl"], theme.SPACE["xs"]))
        ctk.CTkLabel(
            window,
            text=("WhatsApp > Settings > Linked devices > Link a device,\n"
                  "then scan this code."),
            justify="center", text_color=theme.color("text_muted"),
            font=theme.font(theme.TEXT_SM),
        ).pack(padx=theme.SPACE["xl"], pady=(0, theme.SPACE["md"]))

        shown = False
        if image_path:
            try:
                # tk.PhotoImage reads PNG natively in Tk 8.6, so this needs no
                # Pillow -- customtkinter 6 no longer ships it, and CTkImage
                # silently fails without it.
                photo = tk.PhotoImage(file=image_path)
                # The QR itself stays on white whatever the theme: scanners
                # need the quiet zone, not our dark canvas.
                label = tk.Label(window, image=photo, borderwidth=0, background="#FFFFFF")
                label.pack(padx=theme.SPACE["xl"], pady=theme.SPACE["sm"])
                window._qr_photo = photo  # keep a reference alive
                shown = True
            except (tk.TclError, OSError):
                log.exception("Could not display the QR image %s", image_path)
        if not shown:
            box = ctk.CTkTextbox(window, width=420, height=90, font=(theme.FONT_MONO, 10))
            box.insert("1.0", qr)
            box.configure(state="disabled")
            box.pack(padx=theme.SPACE["xl"], pady=theme.SPACE["sm"])
            ctk.CTkLabel(
                window,
                text="QR image unavailable - paste this payload into any QR generator.",
                text_color=theme.color("text_muted"), font=theme.font(theme.TEXT_SM),
            ).pack(padx=theme.SPACE["xl"], pady=(0, theme.SPACE["sm"]))

        ctk.CTkButton(window, text="Close", width=120, height=34, command=window.destroy,
                      **theme.secondary_button()).pack(
            padx=theme.SPACE["xl"], pady=(0, theme.SPACE["xl"]))
        self._qr_window = window

    def close_qr(self) -> None:
        if self._qr_window is not None:
            try:
                self._qr_window.destroy()
            except tk.TclError:
                pass
            self._qr_window = None

    def show_connection(self, connected: bool, text: str, real_delivery: bool = False) -> None:
        self._set_busy(False)
        if connected:
            self.close_qr()
        tone = "success" if connected else "danger"
        self.status_pill.configure(text="Live Session" if connected else "Offline",
                                   text_color=theme.color(tone))
        self.hero_badge.configure(text=theme.icon("check" if connected else "connection"),
                                  text_color=theme.color(tone))
        self.status_label.configure(text="Connected" if connected else "Disconnected")
        self.hero_detail.configure(text=text)
        self.state_dot.configure(text_color=theme.color(tone))
        self.state_title.configure(text="Connected" if connected else "Disconnected")
        self.state_detail.configure(
            text="Session active and ready to send messages" if connected else "No session")
        self.state_banner.configure(
            fg_color=theme.color(f"{tone}_soft"), border_color=theme.color(tone))
        self.status_values["state"].configure(
            text="Live Session" if connected else "Offline",
            text_color=theme.color(tone))
        anim.stop(self._pill_pulse)
        self._pill_pulse = None
        if connected:
            self._pill_pulse = anim.pulse(
                self, lambda c: self.status_pill.configure(text_color=c),
                theme.resolve("primary"), theme.resolve("text_muted"), period_ms=2200)
        if connected and not real_delivery:
            self.mode_label.configure(
                text="SANDBOX: nothing is delivered to WhatsApp.",
                text_color=theme.color("warning"))
        elif connected and self.app.app_config.transport == TRANSPORT_WEB_JS:
            self.mode_label.configure(
                text="Live WhatsApp Web session - messages are really delivered. " + WEB_JS_WARNING,
                text_color=theme.color("warning"))
        elif connected:
            self.mode_label.configure(
                text="Live Cloud API connection - messages are really delivered.",
                text_color=theme.color("success"))
        self._set_action_states(connected)

    def show_session(self, account: str) -> None:
        """The account the transport reported, shown in the status panel."""
        self.status_values["session"].configure(text=account or "-")
