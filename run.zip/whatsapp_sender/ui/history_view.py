"""Message history tab (ttk.Treeview inside the CustomTkinter window)."""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

import customtkinter as ctk

from ..protocol import Status
from . import theme

COLUMNS = (
    ("message_id", "Message ID", 150),
    ("recipient", "Recipient", 130),
    ("message", "Message", 320),
    ("status", "Status", 90),
    ("attempt", "Attempt", 70),
    ("created_at", "Created", 160),
    ("updated_at", "Updated", 160),
    ("error", "Error", 320),
)

#: Status -> palette token. The table also prints the status as text, so the
#: colour reinforces the state instead of carrying it alone.
STATUS_TOKENS = {
    Status.QUEUED.value: "text_muted",
    Status.SENDING.value: "primary",
    Status.SENT.value: "success",
    Status.DELIVERED.value: "success",
    Status.READ.value: "success",
    Status.FAILED.value: "danger",
    Status.SANDBOX.value: "warning",
}


class HistoryView(ctk.CTkFrame):
    def __init__(self, master, app) -> None:
        super().__init__(master)
        self.app = app
        self._signature: tuple | None = None
        self._build()
        self.refresh()

    def _build(self) -> None:
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        pad = theme.SPACE
        self.configure(fg_color="transparent")
        bar = theme.card(self)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, pad["md"]))
        theme.card_header(bar, "history", "Message History",
                          "Every message this app sent, with the status it really reported",
                          tone="primary").pack(
            side="left", padx=(pad["lg"], pad["xl"]), pady=pad["md"])
        ctk.CTkButton(bar, text=f"{theme.icon('refresh')}  Refresh", width=120, height=38,
                      command=self.refresh, **theme.secondary_button()).pack(
            side="left", padx=pad["sm"], pady=pad["sm"])

        self.status_filter = tk.StringVar(value="ALL")
        ctk.CTkOptionMenu(
            bar,
            values=["ALL"] + [s.value for s in Status],
            variable=self.status_filter,
            command=lambda _=None: self.refresh(),
            width=150, height=38, **theme.neutral_option_menu(),
        ).pack(side="left", padx=pad["sm"], pady=pad["sm"])

        self.search_var = tk.StringVar()
        entry = ctk.CTkEntry(bar, textvariable=self.search_var,
                             placeholder_text="Filter by recipient", width=240, height=38)
        entry.pack(side="left", padx=pad["sm"], pady=pad["sm"])
        entry.bind("<Return>", lambda _e: self.refresh())

        # Counts live on the right so a long filter never pushes them off-screen.
        self.summary_label = ctk.CTkLabel(bar, text="", text_color=theme.color("text_muted"),
                                          font=theme.font(theme.TEXT_SM), justify="right",
                                          wraplength=260, anchor="e")
        self.summary_label.pack(side="right", padx=pad["lg"], pady=pad["sm"])

        container = theme.card(self)
        container.grid(row=1, column=0, sticky="nsew")
        container.grid_columnconfigure(0, weight=1)
        container.grid_rowconfigure(0, weight=1)

        self._style = ttk.Style()
        theme.style_treeview(self._style)

        self.tree = ttk.Treeview(
            container,
            columns=[c[0] for c in COLUMNS],
            show="headings",
            style="History.Treeview",
        )
        for key, title, width in COLUMNS:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, anchor="w", stretch=key in {"message", "error"})
        self.tree.grid(row=0, column=0, sticky="nsew")

        y_scroll = ttk.Scrollbar(container, orient="vertical", command=self.tree.yview,
                                 style="History.Vertical.TScrollbar")
        y_scroll.grid(row=0, column=1, sticky="ns")
        x_scroll = ttk.Scrollbar(container, orient="horizontal", command=self.tree.xview,
                                 style="History.Horizontal.TScrollbar")
        x_scroll.grid(row=1, column=0, sticky="ew")
        self.tree.configure(yscrollcommand=y_scroll.set, xscrollcommand=x_scroll.set)

        self._paint_tags()

    def _paint_tags(self) -> None:
        for value, token in STATUS_TOKENS.items():
            self.tree.tag_configure(value, foreground=theme.resolve(token))

    def restyle(self) -> None:
        """Re-resolve the palette after a light/dark switch (ttk is not themed)."""
        theme.style_treeview(self._style)
        self._paint_tags()

    def refresh(self, force: bool = False) -> None:
        """Repaint the table.

        Rebuilding a thousand Treeview rows is the most expensive thing this
        UI does, so it is skipped when the tab is not on screen and when the
        data has not actually changed since the last repaint.
        """
        if not force and not self.winfo_viewable():
            return
        status = self.status_filter.get()
        status_enum = None if status == "ALL" else Status(status)
        recipient = self.search_var.get().strip() or None
        # Ask the cheap question first: nothing new means no query and no
        # repaint, which is what a running campaign hits every few seconds.
        signature = (status, recipient) + self.app.db.history_signature(status_enum, recipient)
        if not force and signature == self._signature:
            return
        self._signature = signature

        records = self.app.db.history(limit=1000, status=status_enum, recipient=recipient)
        self.tree.delete(*self.tree.get_children())
        for record in records:
            self.tree.insert(
                "", "end",
                iid=record.message_id,
                values=(
                    record.message_id,
                    "+" + record.recipient,
                    record.message.replace("\n", " ")[:200],
                    record.status.value,
                    record.attempt,
                    record.created_at,
                    record.updated_at,
                    (record.error or "")[:200],
                ),
                tags=(record.status.value,),
            )
        counts = self.app.db.counts_by_status()
        self.summary_label.configure(
            text="  ".join(f"{k}: {v}" for k, v in sorted(counts.items())) or "no messages yet"
        )
