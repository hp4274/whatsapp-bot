"""Small animation helpers for a Tk UI.

Tk has no transitions, so motion here is an ``after`` loop that writes a value
every frame.  Three rules keep it cheap and honest:

* every animation is cancellable and stops the moment its widget is gone,
* nothing animates layout (no re-gridding per frame), only colours and values,
* :data:`ENABLED` turns the whole thing off - the app sets it from the
  ``animations`` setting, which is this app's "reduced motion".
"""

from __future__ import annotations

import math
from typing import Callable

#: Set from Config.animations at startup. False = jump straight to the end.
ENABLED = True

FRAME_MS = 20  # 50fps: smooth enough for colour and progress, cheap for Tk

#: Text spinner frames. Plain glyphs, not emoji, so they take the label colour.
SPINNER_FRAMES = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"


def ease_out_cubic(t: float) -> float:
    return 1 - (1 - t) ** 3


def mix(color_a: str, color_b: str, t: float) -> str:
    """Blend two #rrggbb colours. t=0 gives a, t=1 gives b."""
    a = tuple(int(color_a[i:i + 2], 16) for i in (1, 3, 5))
    b = tuple(int(color_b[i:i + 2], 16) for i in (1, 3, 5))
    return "#%02x%02x%02x" % tuple(round(x + (y - x) * t) for x, y in zip(a, b))


class Handle:
    """A running animation. Call :meth:`stop` to cancel it."""

    def __init__(self, widget) -> None:
        self.widget = widget
        self._job: str | None = None
        self._stopped = False

    def _schedule(self, callback, delay: int = FRAME_MS) -> None:
        if self._stopped:
            return
        try:
            self._job = self.widget.after(delay, callback)
        except Exception:  # noqa: BLE001 - widget went away mid-animation
            self._stopped = True

    def stop(self) -> None:
        self._stopped = True
        if self._job is not None:
            try:
                self.widget.after_cancel(self._job)
            except Exception:  # noqa: BLE001 - already gone
                pass
            self._job = None

    @property
    def alive(self) -> bool:
        if self._stopped:
            return False
        try:
            return bool(self.widget.winfo_exists())
        except Exception:  # noqa: BLE001
            return False


def animate(widget, start: float, end: float, duration_ms: int,
            setter: Callable[[float], None], ease=ease_out_cubic) -> Handle | None:
    """Drive ``setter`` from start to end. Returns a Handle, or None if disabled."""
    if not ENABLED or duration_ms <= 0 or abs(end - start) < 1e-6:
        setter(end)
        return None

    handle = Handle(widget)
    steps = max(1, duration_ms // FRAME_MS)
    state = {"step": 0}

    def tick() -> None:
        if not handle.alive:
            return
        state["step"] += 1
        progress = min(1.0, state["step"] / steps)
        setter(start + (end - start) * ease(progress))
        if progress < 1.0:
            handle._schedule(tick)

    handle._schedule(tick)
    return handle


def pulse(widget, setter: Callable[[str], None], color_a: str, color_b: str,
          period_ms: int = 1800) -> Handle | None:
    """Breathe between two colours - used to say "this session is live"."""
    if not ENABLED:
        setter(color_a)
        return None

    handle = Handle(widget)
    state = {"t": 0.0}
    step = FRAME_MS / period_ms

    def tick() -> None:
        if not handle.alive:
            return
        state["t"] = (state["t"] + step) % 1.0
        # sine keeps the turn at each end soft instead of snapping
        setter(mix(color_a, color_b, (1 - math.cos(state["t"] * 2 * math.pi)) / 2))
        handle._schedule(tick)

    handle._schedule(tick)
    return handle


def spin(widget, setter: Callable[[str], None], interval_ms: int = 90) -> Handle | None:
    """Cycle spinner frames while something slow is running."""
    if not ENABLED:
        setter(SPINNER_FRAMES[0])
        return None

    handle = Handle(widget)
    state = {"i": 0}

    def tick() -> None:
        if not handle.alive:
            return
        setter(SPINNER_FRAMES[state["i"] % len(SPINNER_FRAMES)])
        state["i"] += 1
        handle._schedule(tick, interval_ms)

    handle._schedule(tick, 0)
    return handle


def stop(handle: Handle | None) -> None:
    """Stop an animation that may or may not be running."""
    if handle is not None:
        handle.stop()
