"""Generate ``assets/azure.json`` - the CustomTkinter widget theme.

Run it after changing a token in ``theme.py``::

    python -m whatsapp_sender.ui.build_theme

It starts from CustomTkinter's own ``blue.json`` so every key the library
expects is present, then overwrites the colours and geometry with our tokens.
"""

from __future__ import annotations

import json
from pathlib import Path

import customtkinter as ctk

from .theme import COLORS, FONT_FAMILY, RADIUS, RADIUS_SM, TEXT_BASE, THEME_PATH


def _c(token: str) -> list[str]:
    return list(COLORS[token])


def build() -> dict:
    base_path = Path(ctk.__file__).parent / "assets" / "themes" / "blue.json"
    theme = json.loads(base_path.read_text(encoding="utf-8"))

    theme["CTk"]["fg_color"] = _c("canvas")
    theme["CTkToplevel"]["fg_color"] = _c("canvas")

    theme["CTkFrame"].update(
        corner_radius=RADIUS,
        border_width=0,  # cards add their own border via theme.card()
        fg_color=_c("surface"),
        top_fg_color=_c("surface_alt"),
        border_color=_c("border"),
    )
    theme["CTkButton"].update(
        corner_radius=RADIUS_SM,
        border_width=0,
        fg_color=_c("primary"),
        hover_color=_c("primary_hover"),
        border_color=_c("border"),
        text_color=_c("on_primary"),
        text_color_disabled=_c("text_muted"),
    )
    theme["CTkLabel"].update(
        corner_radius=0,
        fg_color="transparent",
        text_color=_c("text"),
    )
    theme["CTkEntry"].update(
        corner_radius=RADIUS_SM,
        border_width=1,
        fg_color=_c("surface_alt"),
        border_color=_c("border"),
        text_color=_c("text"),
        placeholder_text_color=_c("text_muted"),
    )
    theme["CTkCheckBox"].update(
        corner_radius=6,
        border_width=2,
        fg_color=_c("primary"),
        border_color=_c("border"),
        hover_color=_c("primary_hover"),
        checkmark_color=_c("on_primary"),
        text_color=_c("text"),
        text_color_disabled=_c("text_muted"),
    )
    theme["CTkSwitch"].update(
        button_color=_c("surface"),
        button_hover_color=_c("surface_alt"),
        progress_color=_c("primary"),
        fg_color=_c("border"),
        text_color=_c("text"),
        text_color_disabled=_c("text_muted"),
    )
    theme["CTkRadioButton"].update(
        fg_color=_c("primary"),
        hover_color=_c("primary_hover"),
        border_color=_c("border"),
        text_color=_c("text"),
        text_color_disabled=_c("text_muted"),
    )
    theme["CTkProgressBar"].update(
        corner_radius=1000,
        fg_color=_c("border"),
        progress_color=_c("primary"),
    )
    theme["CTkSlider"].update(
        fg_color=_c("border"),
        progress_color=_c("primary"),
        button_color=_c("primary"),
        button_hover_color=_c("primary_hover"),
    )
    theme["CTkOptionMenu"].update(
        corner_radius=RADIUS_SM,
        fg_color=_c("primary"),
        button_color=_c("primary_hover"),
        button_hover_color=_c("primary_hover"),
        text_color=_c("on_primary"),
        text_color_disabled=_c("text_muted"),
    )
    theme["CTkComboBox"].update(
        corner_radius=RADIUS_SM,
        border_width=1,
        fg_color=_c("surface"),
        border_color=_c("border"),
        button_color=_c("border"),
        button_hover_color=_c("primary"),
        text_color=_c("text"),
        text_color_disabled=_c("text_muted"),
    )
    theme["CTkScrollbar"].update(
        corner_radius=1000,
        fg_color="transparent",
        button_color=_c("border"),
        button_hover_color=_c("text_muted"),
    )
    theme["CTkSegmentedButton"].update(
        corner_radius=RADIUS_SM,
        border_width=2,
        fg_color=_c("surface_alt"),
        selected_color=_c("primary"),
        selected_hover_color=_c("primary_hover"),
        unselected_color=_c("surface_alt"),
        unselected_hover_color=_c("primary_soft"),
        text_color=_c("text"),
        text_color_disabled=_c("text_muted"),
    )
    theme["CTkTextbox"].update(
        corner_radius=RADIUS_SM,
        border_width=1,
        fg_color=_c("surface_alt"),
        border_color=_c("border"),
        text_color=_c("text"),
        scrollbar_button_color=_c("border"),
        scrollbar_button_hover_color=_c("text_muted"),
    )
    theme["CTkScrollableFrame"]["label_fg_color"] = _c("surface_alt")
    theme["DropdownMenu"].update(
        fg_color=_c("surface"),
        hover_color=_c("primary_soft"),
        text_color=_c("text"),
    )
    for platform in ("Windows", "Linux"):
        theme["CTkFont"][platform] = {
            "family": FONT_FAMILY, "size": TEXT_BASE, "weight": "normal",
        }
    theme["CTkFont"]["macOS"] = {"family": "SF Display", "size": TEXT_BASE, "weight": "normal"}
    return theme


def main() -> None:
    THEME_PATH.parent.mkdir(parents=True, exist_ok=True)
    THEME_PATH.write_text(json.dumps(build(), indent=2) + "\n", encoding="utf-8")
    print(f"wrote {THEME_PATH}")


if __name__ == "__main__":
    main()
