"""Entry point.

    python -m whatsapp_sender.main            # GUI
    python -m whatsapp_sender.main --send ... # headless single send
"""

from __future__ import annotations

import argparse
import sys

from .config import (
    TRANSPORT_CLOUD_API,
    TRANSPORT_SANDBOX,
    TRANSPORT_WEB_JS,
    Config,
    ensure_app_dir,
)
from .database import Database
from .logger import setup_logging
from .protocol import PhoneError, normalize_phone
from .transports import create_transport
from .transports.base import TransportError


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="whatsapp-sender", description=__doc__)
    parser.add_argument(
        "--transport",
        choices=[TRANSPORT_CLOUD_API, TRANSPORT_WEB_JS, TRANSPORT_SANDBOX],
        help="Override the configured transport for this run.",
    )
    parser.add_argument("--send", metavar="PHONE", help="Send one message and exit.")
    parser.add_argument("--message", metavar="TEXT", help="Message body used with --send.")
    parser.add_argument("--log-level", default=None)
    return parser


def run_cli(config: Config, phone: str, message: str) -> int:
    """Headless send. Prints the status the transport actually reported."""
    try:
        recipient = normalize_phone(phone, config.default_country_code)
    except PhoneError as exc:
        print(f"Invalid number: {exc}", file=sys.stderr)
        return 2

    transport = create_transport(config)
    try:
        info = transport.connect()
        print(f"Connected: {transport.name} [{info.account}] real_delivery={info.real_delivery}")
        result = transport.send_message(recipient, message)
    except TransportError as exc:
        print(f"FAILED: {exc}", file=sys.stderr)
        return 1
    finally:
        transport.disconnect()

    print(f"{result.status} provider_id={result.provider_id} ({result.detail})")
    if not transport.real_delivery:
        print("NOTE: sandbox transport - nothing was delivered to WhatsApp.")
    return 0


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    ensure_app_dir()
    config = Config.load()
    if args.transport:
        config.transport = args.transport
    setup_logging(args.log_level or config.log_level)

    if args.send:
        if not args.message:
            print("--send requires --message", file=sys.stderr)
            return 2
        return run_cli(config, args.send, args.message)

    # GUI: imported lazily so headless use needs no display / customtkinter.
    from .ui.main_window import MainWindow

    db = Database()
    app = MainWindow(config, db)
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
