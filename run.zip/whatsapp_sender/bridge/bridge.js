/*
 * Local whatsapp-web.js sidecar.
 *
 * Why this exists
 * ---------------
 * The Cloud API transport needs a Meta access token plus a WhatsApp Business
 * account.  This bridge drives a *personal* WhatsApp account through
 * whatsapp-web.js instead: you scan a QR code once, the session is cached on
 * disk (LocalAuth) and no token is ever involved.
 *
 * Trade-off, stated plainly: whatsapp-web.js automates WhatsApp Web, which is
 * not an official API and is against WhatsApp's Terms of Service.  Numbers do
 * get banned for bulk sending this way.  The Python side repeats this warning.
 *
 * Protocol (loopback HTTP, JSON, shared-secret header x-bridge-token):
 *   GET  /status            -> {state, qr, qrImage, me, detail, seq}
 *   POST /send {to,message} -> {id} | 4xx/5xx {error, retryable}
 *   GET  /acks?since=N      -> {seq, events:[{id,status}]}
 *   POST /logout            -> {ok}   (wipes the cached session)
 *   POST /shutdown          -> {ok}
 */

'use strict';

const assert = require('node:assert');
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');

const PORT = Number(process.env.BRIDGE_PORT || 8765);
const HOST = '127.0.0.1';
const TOKEN = process.env.BRIDGE_TOKEN || '';
const DATA_PATH = process.env.BRIDGE_DATA || './.wwebjs_auth';
// Set BRIDGE_CHROME to reuse an installed Chrome/Edge instead of the
// Chromium puppeteer downloads.
const CHROME_PATH = process.env.BRIDGE_CHROME || '';
const MAX_BODY = 1 << 20; // 1 MiB is plenty for one text message

// whatsapp-web.js MessageAck -> the app's Status vocabulary.
// ACK_ERROR(-1) ACK_PENDING(0) ACK_SERVER(1) ACK_DEVICE(2) ACK_READ(3) ACK_PLAYED(4)
const ACK_STATUS = {
    '-1': 'FAILED',
    '1': 'SENT',
    '2': 'DELIVERED',
    '3': 'READ',
    '4': 'READ',
};

function ackStatus(ack) {
    return ACK_STATUS[String(ack)] || null; // 0 (pending) reports nothing
}

// --------------------------------------------------------------------- state
let qrCount = 0; // each QR gets its own file, so a reported path is never stale

// client.sendMessage() returns undefined whenever WhatsApp Web changes shape
// under whatsapp-web.js (getMessageModel comes back empty) even though the
// message WAS dispatched.  Reporting that as a failure makes the caller retry
// and the recipient gets the message twice, so outgoing messages are also
// tracked through message_create and used to confirm the send.
const recentOutgoing = new Map(); // `${chatId}|${body}` -> {id, at}
const OUTGOING_TTL_MS = 5 * 60 * 1000;
const CONFIRM_TIMEOUT_MS = 5000;

function outgoingKey(chatId, body) {
    return `${chatId}|${body}`;
}

function recordOutgoing(chatId, body, id) {
    if (!chatId || !id) return;
    recentOutgoing.set(outgoingKey(chatId, body), { id, at: Date.now() });
    for (const [key, entry] of recentOutgoing) {
        if (Date.now() - entry.at > OUTGOING_TTL_MS) recentOutgoing.delete(key);
    }
}

function serializedId(msg) {
    const id = msg && msg.id;
    if (!id) return null;
    if (typeof id === 'string') return id;
    return id._serialized || null;
}

/** Wait for a message_create that matches this send, so a missing return value
 *  never turns a delivered message into a retry. */
async function confirmOutgoing(chatId, body, notBefore) {
    const key = outgoingKey(chatId, body);
    const deadline = Date.now() + CONFIRM_TIMEOUT_MS;
    while (Date.now() < deadline) {
        const entry = recentOutgoing.get(key);
        if (entry && entry.at >= notBefore) {
            recentOutgoing.delete(key); // never match the same message twice
            return entry.id;
        }
        await new Promise((resolve) => setTimeout(resolve, 100));
    }
    return null;
}
let lastQrFile = null;
fs.mkdirSync(DATA_PATH, { recursive: true }); // qrcode.toFile will not create it

const state = {
    state: 'starting', // starting | qr | ready | auth_failure | disconnected
    qr: null,
    qrImage: null, // PNG of the current QR, for the GUI (no console there)
    me: '',
    detail: '',
    seq: 0,
    events: [], // append-only [{seq, id, status}]
};

function pushAck(id, ack) {
    const status = ackStatus(ack);
    if (!id || !status) return;
    state.seq += 1;
    state.events.push({ seq: state.seq, id, status });
    // ponytail: ring-buffer the last 5000 acks; the Python side polls every
    // couple of seconds, so anything older has already been consumed.
    if (state.events.length > 5000) state.events.splice(0, state.events.length - 5000);
}

// -------------------------------------------------------------------- server
function readBody(req) {
    return new Promise((resolve, reject) => {
        let size = 0;
        const chunks = [];
        req.on('data', (chunk) => {
            size += chunk.length;
            if (size > MAX_BODY) {
                reject(new Error('body too large'));
                req.destroy();
                return;
            }
            chunks.push(chunk);
        });
        req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
        req.on('error', reject);
    });
}

function send(res, code, payload) {
    const body = JSON.stringify(payload);
    res.writeHead(code, {
        'content-type': 'application/json',
        'content-length': Buffer.byteLength(body),
    });
    res.end(body);
}

function createServer(client, onShutdown) {
    return http.createServer(async (req, res) => {
        if (TOKEN && req.headers['x-bridge-token'] !== TOKEN) {
            return send(res, 403, { error: 'bad bridge token' });
        }
        const url = new URL(req.url, 'http://127.0.0.1');

        if (req.method === 'GET' && url.pathname === '/status') {
            return send(res, 200, {
                state: state.state,
                qr: state.qr,
                qrImage: state.qrImage,
                me: state.me,
                detail: state.detail,
                seq: state.seq,
            });
        }

        if (req.method === 'GET' && url.pathname === '/acks') {
            const since = Number(url.searchParams.get('since') || 0);
            return send(res, 200, {
                seq: state.seq,
                events: state.events
                    .filter((e) => e.seq > since)
                    .map((e) => ({ id: e.id, status: e.status })),
            });
        }

        if (req.method === 'POST' && url.pathname === '/send') {
            if (state.state !== 'ready') {
                return send(res, 409, { error: `client not ready (${state.state})`, retryable: true });
            }
            let payload;
            try {
                payload = JSON.parse((await readBody(req)) || '{}');
            } catch (err) {
                return send(res, 400, { error: `bad JSON: ${err.message}`, retryable: false });
            }
            const to = String(payload.to || '').replace(/\D/g, '');
            const message = String(payload.message == null ? '' : payload.message);
            if (!to || !message) {
                return send(res, 400, { error: 'to and message are required', retryable: false });
            }
            let numberId;
            try {
                numberId = await client.getNumberId(to);
            } catch (err) {
                return send(res, 502, { error: String((err && err.message) || err), retryable: true });
            }
            if (!numberId) {
                return send(res, 400, { error: `${to} is not on WhatsApp`, retryable: false });
            }

            const chatId = numberId._serialized;
            const startedAt = Date.now();
            let id = null;
            let sendError = null;
            try {
                id = serializedId(await client.sendMessage(chatId, message));
            } catch (err) {
                sendError = String((err && err.message) || err);
            }
            if (!id) {
                // No id from the call: ask WhatsApp Web itself whether the
                // message went out.  Retrying a message that was in fact sent
                // is what delivers it twice.
                id = await confirmOutgoing(chatId, message, startedAt);
            }
            if (id) {
                if (sendError) console.error(`[bridge] send reported "${sendError}" but the message went out as ${id}`);
                return send(res, 200, { id });
            }
            if (sendError) {
                return send(res, 502, { error: sendError, retryable: true });
            }
            // sendMessage resolved without an id and nothing confirmed it.  It
            // was dispatched, so this is NOT retried: a synthetic id keeps the
            // history row, at the price of no ACK tracking for this message.
            const localId = `local.${startedAt}.${Math.random().toString(36).slice(2, 8)}`;
            console.error(`[bridge] no id for the message to ${to}; reporting ${localId} without ACK tracking`);
            return send(res, 200, { id: localId, ackTracking: false });
        }

        if (req.method === 'POST' && url.pathname === '/logout') {
            try {
                await client.logout();
            } catch (err) {
                return send(res, 502, { error: String((err && err.message) || err) });
            }
            state.state = 'disconnected';
            state.me = '';
            return send(res, 200, { ok: true });
        }

        if (req.method === 'POST' && url.pathname === '/shutdown') {
            send(res, 200, { ok: true });
            if (onShutdown) setImmediate(onShutdown);
            return undefined;
        }

        return send(res, 404, { error: 'no such endpoint' });
    });
}

// ---------------------------------------------------------------- real client
function buildClient() {
    const { Client, LocalAuth } = require('whatsapp-web.js');
    const qrcodeTerminal = require('qrcode-terminal');
    const qrcode = require('qrcode');

    const client = new Client({
        authStrategy: new LocalAuth({ dataPath: DATA_PATH }),
        puppeteer: {
            args: ['--no-sandbox', '--disable-setuid-sandbox'],
            ...(CHROME_PATH ? { executablePath: CHROME_PATH } : {}),
        },
    });

    client.on('qr', (qr) => {
        state.state = 'qr';
        state.qr = qr;
        state.qrImage = null;
        state.detail = 'scan the QR code with WhatsApp > Linked devices';
        console.log('[bridge] scan this QR code in WhatsApp > Linked devices:');
        qrcodeTerminal.generate(qr, { small: true });
        // The GUI is launched with pythonw and has no console, so also drop a
        // PNG the Python side can display.  The path is published only once the
        // file is written, and never reused, so a reported image always matches
        // the reported payload.
        const previous = lastQrFile;
        const file = path.join(DATA_PATH, `qr-${(qrCount += 1)}.png`);
        lastQrFile = file;
        qrcode.toFile(file, qr, { width: 320, margin: 2 })
            .then(() => {
                if (state.qr !== qr) return; // a newer QR already replaced this one
                state.qrImage = file;
                if (previous) fs.promises.unlink(previous).catch(() => undefined);
            })
            .catch((err) => console.error(`[bridge] could not write ${file}: ${err}`));
    });
    client.on('authenticated', () => {
        state.detail = 'authenticated, loading';
    });
    client.on('loading_screen', (percent) => {
        state.detail = `loading ${percent}%`;
    });
    client.on('ready', () => {
        state.state = 'ready';
        state.qr = null;
        state.qrImage = null;
        state.me = (client.info && client.info.wid && client.info.wid.user) || '';
        state.detail = 'session cached, no access token in use';
        console.log(`[bridge] ready as ${state.me}`);
    });
    client.on('auth_failure', (msg) => {
        state.state = 'auth_failure';
        state.detail = String(msg);
        console.error(`[bridge] auth failure: ${msg}`);
    });
    client.on('disconnected', (reason) => {
        state.state = 'disconnected';
        state.detail = String(reason);
        console.error(`[bridge] disconnected: ${reason}`);
    });
    client.on('message_create', (msg) => {
        if (msg && msg.fromMe) recordOutgoing(msg.to, msg.body, serializedId(msg));
    });
    client.on('message_ack', (msg, ack) => {
        pushAck(serializedId(msg), ack);
    });
    return client;
}

function main() {
    const client = buildClient();
    const server = createServer(client, async () => {
        try {
            await client.destroy();
        } catch (err) {
            /* shutting down anyway */
        }
        server.close(() => process.exit(0));
        setTimeout(() => process.exit(0), 5000).unref();
    });
    server.listen(PORT, HOST, () => console.log(`[bridge] listening on ${HOST}:${PORT}`));
    // WhatsApp Web reloads itself while the login page is being injected, which
    // shows up as a puppeteer "Execution context was destroyed" ProtocolError.
    // It is transient, so give initialize a few attempts before giving up.
    initializeWithRetries(client, 3);
}

async function initializeWithRetries(client, attempts) {
    for (let attempt = 1; attempt <= attempts; attempt += 1) {
        try {
            await client.initialize();
            return;
        } catch (err) {
            const message = String((err && err.message) || err);
            console.error(`[bridge] initialize attempt ${attempt}/${attempts} failed: ${message}`);
            if (state.state === 'qr' || state.state === 'ready') return; // already usable
            if (attempt === attempts) {
                state.state = 'auth_failure';
                state.detail = message;
                return;
            }
            state.detail = `retrying after: ${message}`;
            try { await client.destroy(); } catch (ignored) { /* already dead */ }
            await new Promise((resolve) => setTimeout(resolve, 3000));
        }
    }
}

// ------------------------------------------------------------------ selftest
// node bridge.js --selftest : exercises the HTTP contract and the ack mapping
// against a stub client, so it can be checked without WhatsApp.
async function selftest() {
    const stub = {
        getNumberId: async (n) => (n === '919876543210' ? { _serialized: `${n}@c.us` } : null),
        sendMessage: async () => ({ id: { _serialized: 'true_9@c.us_ABC' } }),
        logout: async () => undefined,
    };
    const server = createServer(stub, null);
    await new Promise((resolve) => server.listen(0, HOST, resolve));
    const base = `http://${HOST}:${server.address().port}`;
    const call = async (method, path, body) => {
        const res = await fetch(base + path, {
            method,
            headers: { 'x-bridge-token': TOKEN, 'content-type': 'application/json' },
            body: body === undefined ? undefined : JSON.stringify(body),
        });
        return { code: res.status, json: await res.json() };
    };

    assert.equal(ackStatus(-1), 'FAILED');
    assert.equal(ackStatus(0), null, 'pending must report nothing');
    assert.equal(ackStatus(2), 'DELIVERED');
    assert.equal(ackStatus(3), 'READ');

    assert.equal(
        (await call('POST', '/send', { to: '919876543210', message: 'hi' })).code,
        409,
        'must refuse to send before ready',
    );

    state.state = 'ready';
    const sent = await call('POST', '/send', { to: '+91 98765 43210', message: 'hi' });
    assert.equal(sent.code, 200);
    assert.equal(sent.json.id, 'true_9@c.us_ABC');

    const unknown = await call('POST', '/send', { to: '10000000000', message: 'hi' });
    assert.equal(unknown.code, 400);
    assert.equal(unknown.json.retryable, false, 'not-on-WhatsApp must not be retried');

    // A send that WAS dispatched but returned no id must never come back as a
    // retryable error: the retry is what delivers the message twice.
    stub.sendMessage = async () => undefined;
    setTimeout(() => recordOutgoing('919876543210@c.us', 'hi', 'true_9@c.us_CONFIRMED'), 150);
    const confirmed = await call('POST', '/send', { to: '919876543210', message: 'hi' });
    assert.equal(confirmed.code, 200, 'a confirmed send must not be an error');
    assert.equal(confirmed.json.id, 'true_9@c.us_CONFIRMED');

    // Stale entries (recorded before this send started) must not be matched.
    recordOutgoing('919876543210@c.us', 'stale', 'true_9@c.us_OLD');
    recentOutgoing.get('919876543210@c.us|stale').at = Date.now() - 60000;
    const unconfirmed = await call('POST', '/send', { to: '919876543210', message: 'stale' });
    assert.equal(unconfirmed.code, 200, 'an unconfirmed send is still not retried');
    assert.ok(unconfirmed.json.id.startsWith('local.'), unconfirmed.json.id);
    assert.equal(unconfirmed.json.ackTracking, false);

    // A throw with nothing dispatched stays a retryable failure.
    stub.sendMessage = async () => { throw new Error('page crashed'); };
    const crashed = await call('POST', '/send', { to: '919876543210', message: 'boom' });
    assert.equal(crashed.code, 502);
    assert.equal(crashed.json.retryable, true);

    // ...but a throw AFTER the message went out is a success, not a duplicate.
    setTimeout(() => recordOutgoing('919876543210@c.us', 'late', 'true_9@c.us_LATE'), 150);
    const late = await call('POST', '/send', { to: '919876543210', message: 'late' });
    assert.equal(late.code, 200);
    assert.equal(late.json.id, 'true_9@c.us_LATE');
    stub.sendMessage = async () => ({ id: { _serialized: 'true_9@c.us_ABC' } });

    assert.equal((await call('POST', '/send', { to: '', message: 'hi' })).code, 400);

    pushAck('true_9@c.us_ABC', 1);
    pushAck('true_9@c.us_ABC', 0);
    pushAck('true_9@c.us_ABC', 3);
    const acks = await call('GET', '/acks?since=0');
    assert.deepEqual(acks.json.events, [
        { id: 'true_9@c.us_ABC', status: 'SENT' },
        { id: 'true_9@c.us_ABC', status: 'READ' },
    ]);
    assert.deepEqual((await call('GET', `/acks?since=${acks.json.seq}`)).json.events, []);

    assert.equal((await call('GET', '/status')).json.state, 'ready');
    assert.equal((await call('GET', '/nope')).code, 404);

    if (TOKEN) {
        const res = await fetch(`${base}/status`, { headers: { 'x-bridge-token': 'wrong' } });
        assert.equal(res.status, 403, 'bad token must be rejected');
        await res.json();
    }

    await new Promise((resolve) => server.close(resolve));
    console.log('selftest ok');
}

if (process.argv.includes('--selftest')) {
    selftest().catch((err) => {
        console.error(err);
        process.exit(1);
    });
} else {
    main();
}
