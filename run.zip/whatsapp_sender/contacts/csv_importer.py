"""CSV contact importer.

Expected header (case-insensitive, extra columns become personalisation
variables)::

    name,phone
    Rahul,+919876543210
"""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
from pathlib import Path

from ..logger import get_logger
from ..protocol import Contact, PhoneError, normalize_phone

log = get_logger("contacts.csv")

NAME_KEYS = ("name", "full_name", "fullname", "contact", "first_name")
PHONE_KEYS = ("phone", "number", "phone_number", "mobile", "msisdn", "whatsapp")


@dataclass
class ImportResult:
    contacts: list[Contact] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    duplicates: int = 0

    @property
    def count(self) -> int:
        return len(self.contacts)


def _pick(row: dict, keys: tuple[str, ...]) -> str:
    for key in keys:
        value = row.get(key)
        if value:
            return str(value).strip()
    return ""


def rows_to_contacts(rows, default_country_code: str = "") -> ImportResult:
    """Shared by the CSV and XLSX importers: normalise, validate, de-duplicate."""
    result = ImportResult()
    seen: set[str] = set()
    for index, raw_row in enumerate(rows, start=2):  # row 1 is the header
        row = {
            str(k).strip().lower(): ("" if v is None else str(v).strip())
            for k, v in raw_row.items()
            if k is not None
        }
        if not any(row.values()):
            continue

        phone_raw = _pick(row, PHONE_KEYS)
        if not phone_raw:
            result.errors.append(f"Row {index}: missing phone number")
            continue
        try:
            phone = normalize_phone(phone_raw, default_country_code)
        except PhoneError as exc:
            result.errors.append(f"Row {index}: {exc}")
            continue

        if phone in seen:
            result.duplicates += 1
            continue
        seen.add(phone)

        name = _pick(row, NAME_KEYS)
        extra = {
            k: v for k, v in row.items() if k not in NAME_KEYS and k not in PHONE_KEYS
        }
        result.contacts.append(Contact(name=name, phone=phone, extra=extra))

    log.info(
        "Imported %s contact(s), %s duplicate(s), %s error(s)",
        result.count, result.duplicates, len(result.errors),
    )
    return result


def import_csv(path: str | Path, default_country_code: str = "") -> ImportResult:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"CSV not found: {path}")
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            return ImportResult(errors=[f"{path.name}: file is empty or has no header row"])
        return rows_to_contacts(reader, default_country_code)
