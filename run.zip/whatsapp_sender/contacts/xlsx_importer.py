"""XLSX contact importer (openpyxl). Same column rules as the CSV importer."""

from __future__ import annotations

from pathlib import Path

from ..logger import get_logger
from .csv_importer import ImportResult, rows_to_contacts

log = get_logger("contacts.xlsx")


def import_xlsx(
    path: str | Path,
    default_country_code: str = "",
    sheet_name: str | None = None,
) -> ImportResult:
    try:
        from openpyxl import load_workbook
    except ImportError as exc:  # pragma: no cover - dependency is in requirements
        raise RuntimeError("openpyxl is required for XLSX import (pip install openpyxl)") from exc

    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"XLSX not found: {path}")

    workbook = load_workbook(filename=str(path), read_only=True, data_only=True)
    try:
        sheet = workbook[sheet_name] if sheet_name else workbook.active
        rows = sheet.iter_rows(values_only=True)
        try:
            header = next(rows)
        except StopIteration:
            return ImportResult(errors=[f"{path.name}: sheet is empty"])

        columns = [str(c).strip() if c is not None else "" for c in header]
        if not any(columns):
            return ImportResult(errors=[f"{path.name}: missing header row"])

        def as_dicts():
            for row in rows:
                yield {
                    columns[i]: row[i]
                    for i in range(min(len(columns), len(row)))
                    if columns[i]
                }

        return rows_to_contacts(as_dicts(), default_country_code)
    finally:
        workbook.close()
