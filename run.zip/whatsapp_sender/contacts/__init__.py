"""Contact importers."""

from __future__ import annotations

from pathlib import Path

from .csv_importer import ImportResult, import_csv, rows_to_contacts
from .xlsx_importer import import_xlsx

__all__ = ["ImportResult", "import_csv", "import_xlsx", "import_any", "rows_to_contacts"]


def import_any(path: str | Path, default_country_code: str = "") -> ImportResult:
    """Dispatch on the file extension."""
    suffix = Path(path).suffix.lower()
    if suffix in {".xlsx", ".xlsm"}:
        return import_xlsx(path, default_country_code)
    return import_csv(path, default_country_code)
