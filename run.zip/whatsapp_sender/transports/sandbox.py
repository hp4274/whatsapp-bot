"""Local sandbox transport -- for testing the app, never for real delivery.

Nothing leaves the machine.  Every message it handles is written to the
database with the dedicated :data:`Status.SANDBOX` state, which is deliberately
*not* SENT: the history view, the counters and the logs all keep saying
"SANDBOX" so a local test run can never be read as a real WhatsApp delivery.
"""

from __future__ import annotations

import threading
import uuid
from pathlib import Path

from ..config import APP_DIR, Config
from ..logger import get_logger
from ..protocol import Status, utc_now
from .base import ConnectionInfo, SendResult, Transport, TransportConnectionError, TransportSendError

log = get_logger("transport.sandbox")


class SandboxTransport(Transport):
    name = "Local sandbox (NO real delivery)"
    real_delivery = False
    supports_receipts = False

    def __init__(self, config: Config, outbox_path: Path | None = None) -> None:
        self.config = config
        self.outbox_path = outbox_path or (APP_DIR / "sandbox_outbox.log")
        self._connected = False
        self._lock = threading.RLock()
        self._sent: dict[str, Status] = {}
        #: set to a phone number prefix to force failures while testing retry.
        self.fail_prefix: str | None = None

    def connect(self) -> ConnectionInfo:
        with self._lock:
            self._connected = True
        log.warning("Sandbox transport connected - messages will NOT reach WhatsApp")
        return ConnectionInfo(
            connected=True,
            account="local sandbox",
            detail="no real delivery",
            real_delivery=False,
        )

    def disconnect(self) -> None:
        with self._lock:
            self._connected = False

    def is_connected(self) -> bool:
        with self._lock:
            return self._connected

    def send_message(self, recipient: str, message: str) -> SendResult:
        if not self.is_connected():
            raise TransportConnectionError("Sandbox transport is not connected", retryable=False)
        if self.fail_prefix and recipient.startswith(self.fail_prefix):
            raise TransportSendError("Simulated sandbox failure", retryable=True, code="sandbox")

        provider_id = f"sandbox.{uuid.uuid4().hex[:16]}"
        try:
            self.outbox_path.parent.mkdir(parents=True, exist_ok=True)
            with self.outbox_path.open("a", encoding="utf-8") as handle:
                handle.write(f"{utc_now()}\t{provider_id}\t{recipient}\t{message!r}\n")
        except OSError as exc:
            raise TransportSendError(f"Could not write sandbox outbox: {exc}") from exc

        with self._lock:
            self._sent[provider_id] = Status.SANDBOX
        log.info("SANDBOX (not delivered): %s -> %s", recipient, provider_id)
        return SendResult(
            provider_id=provider_id,
            status=Status.SANDBOX,
            detail="written to local outbox, not sent to WhatsApp",
        )

    def get_status(self, message_id: str) -> Status | None:
        with self._lock:
            return self._sent.get(message_id)
