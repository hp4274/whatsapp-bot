"""Token-free WhatsApp delivery through whatsapp-web.js (QR login).

What this is
------------
A Node sidecar (``whatsapp_sender/bridge/bridge.js``) runs whatsapp-web.js,
which drives a real WhatsApp Web session for a *personal* WhatsApp account.
You scan a QR code once; the session is cached on disk by LocalAuth and reused
on every later start.  No Meta app, no WhatsApp Business account, no access
token, no webhook: delivery receipts arrive as WhatsApp Web ACKs, which the
bridge exposes and this transport polls.

What it costs you
-----------------
whatsapp-web.js is *not* an official API -- it automates the WhatsApp Web
client.  Using it is against the WhatsApp Terms of Service, and numbers used
for bulk sending this way do get banned.  ``CloudAPITransport`` remains the
supported path; this one exists because it removes the token requirement, and
the UI and the logs say so out loud rather than pretending otherwise.

Status mapping (from whatsapp-web.js MessageAck)
------------------------------------------------
* send accepted by WhatsApp Web -> SENT
* ACK_SERVER(1) -> SENT, ACK_DEVICE(2) -> DELIVERED,
  ACK_READ(3)/ACK_PLAYED(4) -> READ, ACK_ERROR(-1) -> FAILED
* ACK_PENDING(0) reports nothing -- a guess is never written.
"""

from __future__ import annotations

import os
import secrets
import shutil
import subprocess
import threading
import time
from collections import deque
from pathlib import Path

import httpx

from ..config import APP_DIR, Config
from ..logger import get_logger
from ..protocol import Status
from .base import (
    ConnectionInfo,
    SendResult,
    Transport,
    TransportConnectionError,
    TransportSendError,
)

log = get_logger("transport.whatsapp_web")

BRIDGE_DIR = Path(__file__).resolve().parent.parent / "bridge"
BRIDGE_SCRIPT = BRIDGE_DIR / "bridge.js"

_ACK_STATUS = {
    "SENT": Status.SENT,
    "DELIVERED": Status.DELIVERED,
    "READ": Status.READ,
    "FAILED": Status.FAILED,
}

TOS_WARNING = (
    "whatsapp-web.js automates WhatsApp Web. It is not an official API, it "
    "violates the WhatsApp Terms of Service, and bulk sending from a personal "
    "number can get that number banned."
)


class WhatsAppWebTransport(Transport):
    name = "WhatsApp Web via whatsapp-web.js (QR login, no access token)"
    real_delivery = True
    supports_receipts = True

    def __init__(
        self,
        config: Config,
        client: httpx.Client | None = None,
        *,
        spawn: bool = True,
    ) -> None:
        self.config = config
        self._client = client
        self._owns_client = client is None
        self._spawn = spawn
        self._proc: subprocess.Popen | None = None
        self._output: deque[str] = deque(maxlen=50)
        self._token = config.bridge_token or (secrets.token_urlsafe(24) if spawn else "")
        self._connected = False
        self._account = ""
        self._lock = threading.RLock()
        self._receipts: dict[str, Status] = {}
        self._seq = 0
        self._stop = threading.Event()
        self._poller: threading.Thread | None = None
        #: called with the QR payload string while waiting for the scan.
        self.qr_callback = None
        #: PNG of the current QR written by the bridge, for the GUI.
        self.qr_image_path: str | None = None
        #: called as (provider_id, Status, error) for every ACK the bridge reports.
        self.receipt_callback = None

    # ------------------------------------------------------------ plumbing --
    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.config.bridge_port}"

    @property
    def data_path(self) -> Path:
        return Path(self.config.bridge_data_dir or (APP_DIR / "wwebjs_auth"))

    def _ensure_client(self) -> httpx.Client:
        if self._client is None:
            self._client = httpx.Client(timeout=self.config.request_timeout)
            self._owns_client = True
        return self._client

    def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        return self._ensure_client().request(
            method, self.base_url + path, headers={"x-bridge-token": self._token}, **kwargs
        )

    def set_receipt_callback(self, callback) -> None:
        self.receipt_callback = callback

    # ----------------------------------------------------------- lifecycle --
    def _start_bridge(self) -> None:
        node = shutil.which(self.config.bridge_node) or shutil.which("node")
        if not node:
            raise TransportConnectionError(
                f"Node.js not found (looked for {self.config.bridge_node!r}). Install Node 18+ "
                "and re-run install.bat.",
                retryable=False,
            )
        if not BRIDGE_SCRIPT.exists():
            raise TransportConnectionError(f"Bridge script missing: {BRIDGE_SCRIPT}", retryable=False)
        if not (BRIDGE_DIR / "node_modules" / "whatsapp-web.js").exists():
            raise TransportConnectionError(
                f"whatsapp-web.js is not installed. Run 'npm install' in {BRIDGE_DIR} "
                "(install.bat does this for you).",
                retryable=False,
            )

        self.data_path.mkdir(parents=True, exist_ok=True)
        env = dict(os.environ)
        env.update(
            BRIDGE_PORT=str(self.config.bridge_port),
            BRIDGE_TOKEN=self._token,
            BRIDGE_DATA=str(self.data_path),
        )
        if self.config.bridge_chrome_path:
            env["BRIDGE_CHROME"] = self.config.bridge_chrome_path
        log.warning("Starting whatsapp-web.js bridge. %s", TOS_WARNING)
        self._proc = subprocess.Popen(  # noqa: S603 - fixed argv, no shell
            [node, str(BRIDGE_SCRIPT)],
            cwd=str(BRIDGE_DIR),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
        )
        threading.Thread(target=self._drain_output, daemon=True).start()

    def _drain_output(self) -> None:
        proc = self._proc
        if proc is None or proc.stdout is None:
            return
        for line in proc.stdout:
            line = line.rstrip()
            if line:
                self._output.append(line)
                log.info("bridge: %s", line)

    def _bridge_output(self) -> str:
        return " | ".join(self._output) or "no output"

    def connect(self) -> ConnectionInfo:
        problems = self.config.validate()
        if problems:
            raise TransportConnectionError("; ".join(problems), retryable=False)

        if self._spawn and (self._proc is None or self._proc.poll() is not None):
            self._start_bridge()

        deadline = time.monotonic() + self.config.bridge_ready_timeout
        qr_shown = ""
        last_error = "bridge did not answer"
        while time.monotonic() < deadline:
            if self._proc is not None and self._proc.poll() is not None:
                raise TransportConnectionError(
                    f"Bridge exited with code {self._proc.returncode}: {self._bridge_output()}",
                    retryable=False,
                )
            try:
                response = self._request("GET", "/status")
            except httpx.HTTPError as exc:
                last_error = f"bridge not reachable: {exc}"
                time.sleep(1.0)
                continue

            if response.status_code == 403:
                raise TransportConnectionError(
                    "Bridge rejected the token. Another bridge is already running on port "
                    f"{self.config.bridge_port}; stop it or change bridge_port.",
                    retryable=False,
                )
            if response.status_code != 200:
                last_error = f"bridge returned HTTP {response.status_code}"
                time.sleep(1.0)
                continue

            data = response.json()
            state = data.get("state")
            if state == "ready":
                self.qr_image_path = None
                self._account = data.get("me", "")
                self._seq = int(data.get("seq", 0))
                with self._lock:
                    self._connected = True
                self._start_poller()
                log.warning("Connected as %s via WhatsApp Web. %s", self._account, TOS_WARNING)
                return ConnectionInfo(
                    connected=True,
                    account=self._account,
                    detail=f"QR session, no access token. {TOS_WARNING}",
                    real_delivery=True,
                )
            if state == "qr":
                qr = data.get("qr") or ""
                image = data.get("qrImage") or None
                # Re-announce once the bridge has finished writing the PNG: the
                # first /status after a new QR usually arrives without it.
                if qr and (qr != qr_shown or (image and not self.qr_image_path)):
                    qr_shown = qr
                    self.qr_image_path = image
                    log.warning("Scan the QR code printed by the bridge (WhatsApp > Linked devices)")
                    if self.qr_callback is not None:
                        try:
                            self.qr_callback(qr)
                        except Exception:  # noqa: BLE001 - a UI hiccup must not kill connect
                            log.exception("qr_callback failed")
                last_error = "waiting for the QR code to be scanned"
            elif state == "auth_failure":
                raise TransportConnectionError(
                    f"WhatsApp Web authentication failed: {data.get('detail', '')}",
                    retryable=False,
                )
            else:
                last_error = f"bridge state: {state} ({data.get('detail', '')})"
            time.sleep(1.0)

        self.disconnect()
        raise TransportConnectionError(
            f"Timed out after {self.config.bridge_ready_timeout:.0f}s - {last_error}"
        )

    def disconnect(self) -> None:
        with self._lock:
            self._connected = False
        self._stop.set()
        if self._poller is not None:
            self._poller.join(timeout=3.0)
            self._poller = None
        if self._proc is not None:
            try:
                self._request("POST", "/shutdown", timeout=5.0)
            except httpx.HTTPError:
                pass
            try:
                self._proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                log.warning("Bridge did not exit, killing it")
                self._proc.kill()
            self._proc = None
        if self._owns_client and self._client is not None:
            self._client.close()
            self._client = None
        log.info("WhatsApp Web transport disconnected")

    def is_connected(self) -> bool:
        with self._lock:
            return self._connected

    def logout(self) -> None:
        """Drop the cached session so the next connect asks for a new QR scan."""
        try:
            self._request("POST", "/logout", timeout=30.0)
        except httpx.HTTPError as exc:
            log.warning("Logout failed: %s", exc)
        self.disconnect()

    # ---------------------------------------------------------------- send --
    def send_message(self, recipient: str, message: str) -> SendResult:
        if not self.is_connected():
            raise TransportConnectionError("Transport is not connected", retryable=False)
        try:
            response = self._request("POST", "/send", json={"to": recipient, "message": message})
        except httpx.TimeoutException as exc:
            raise TransportSendError(f"Bridge timed out: {exc}", retryable=True) from exc
        except httpx.HTTPError as exc:
            raise TransportSendError(f"Bridge unreachable: {exc}", retryable=True) from exc

        if response.status_code >= 400:
            try:
                body = response.json()
            except ValueError:
                body = {}
            detail = body.get("error") or response.text[:300]
            retryable = bool(body.get("retryable", response.status_code >= 500))
            if response.status_code == 403:
                with self._lock:
                    self._connected = False
                raise TransportConnectionError(f"Bridge rejected the token: {detail}",
                                               retryable=False)
            if response.status_code == 409:  # client lost its session
                with self._lock:
                    self._connected = False
                raise TransportConnectionError(f"WhatsApp Web session not ready: {detail}")
            raise TransportSendError(
                f"WhatsApp Web error {response.status_code}: {detail}",
                retryable=retryable,
                code=response.status_code,
            )

        try:
            body = response.json()
            provider_id = body["id"]
        except (ValueError, KeyError) as exc:
            raise TransportSendError(
                f"Unexpected bridge response: {response.text[:300]}", retryable=False
            ) from exc

        # WhatsApp Web sometimes dispatches a message without handing back its
        # id.  The bridge reports that as a send (retrying it would deliver the
        # message twice); the price is that this one gets no DELIVERED/READ.
        tracked = body.get("ackTracking", True)
        detail = "accepted by WhatsApp Web" if tracked else (
            "sent, but WhatsApp Web returned no message id - no DELIVERED/READ for this one"
        )
        if not tracked:
            log.warning("Sent to %s without an id: status will stay SENT", recipient)

        with self._lock:
            self._receipts[provider_id] = Status.SENT
        log.info("Sent via WhatsApp Web: %s -> %s", recipient, provider_id)
        return SendResult(provider_id=provider_id, status=Status.SENT, detail=detail)

    # -------------------------------------------------------------- status --
    def get_status(self, message_id: str) -> Status | None:
        with self._lock:
            return self._receipts.get(message_id)

    def record_receipt(self, provider_id: str, status: Status) -> None:
        with self._lock:
            self._receipts[provider_id] = status

    # --------------------------------------------------------- ack polling --
    def _start_poller(self) -> None:
        if self._poller is not None and self._poller.is_alive():
            return
        self._stop.clear()
        self._poller = threading.Thread(target=self._poll_acks, name="wwebjs-acks", daemon=True)
        self._poller.start()

    def poll_once(self) -> int:
        """Fetch pending ACKs once. Returns how many receipts were applied."""
        response = self._request("GET", "/acks", params={"since": self._seq})
        if response.status_code != 200:
            raise httpx.HTTPError(f"bridge returned HTTP {response.status_code}")
        data = response.json()
        applied = 0
        for event in data.get("events", []):
            status = _ACK_STATUS.get(str(event.get("status")))
            provider_id = event.get("id")
            if not provider_id or status is None:
                continue
            self.record_receipt(provider_id, status)
            applied += 1
            if self.receipt_callback is not None:
                error = "WhatsApp Web reported a send failure" if status is Status.FAILED else None
                try:
                    self.receipt_callback(provider_id, status, error)
                except Exception:  # noqa: BLE001 - one bad callback must not stop polling
                    log.exception("receipt_callback failed")
        self._seq = int(data.get("seq", self._seq))
        return applied

    def _poll_acks(self) -> None:
        interval = max(0.5, self.config.bridge_poll_interval)
        while not self._stop.wait(interval):
            if not self.is_connected():
                continue
            try:
                self.poll_once()
            except httpx.HTTPError as exc:
                log.warning("ACK poll failed: %s", exc)
            except Exception:  # noqa: BLE001 - keep the thread alive
                log.exception("ACK poll crashed")
