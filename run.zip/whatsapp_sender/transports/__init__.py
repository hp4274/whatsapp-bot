"""Transport package: one interface, three implementations."""

from __future__ import annotations

from ..config import TRANSPORT_CLOUD_API, TRANSPORT_SANDBOX, TRANSPORT_WEB_JS, Config
from .base import (
    ConnectionInfo,
    SendResult,
    Transport,
    TransportConnectionError,
    TransportError,
    TransportSendError,
)
from .sandbox import SandboxTransport
from .whatsapp_transport import CloudAPITransport, WebhookReceiver
from .whatsapp_web import WhatsAppWebTransport

__all__ = [
    "ConnectionInfo",
    "SendResult",
    "Transport",
    "TransportConnectionError",
    "TransportError",
    "TransportSendError",
    "SandboxTransport",
    "CloudAPITransport",
    "WebhookReceiver",
    "WhatsAppWebTransport",
    "create_transport",
]


def create_transport(config: Config) -> Transport:
    if config.transport == TRANSPORT_SANDBOX:
        return SandboxTransport(config)
    if config.transport == TRANSPORT_CLOUD_API:
        return CloudAPITransport(config)
    if config.transport == TRANSPORT_WEB_JS:
        return WhatsAppWebTransport(config)
    raise ValueError(f"Unknown transport: {config.transport!r}")
