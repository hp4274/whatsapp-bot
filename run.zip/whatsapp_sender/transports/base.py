"""Transport interface.

The GUI and the campaign engine talk to this interface only -- they never know
whether the bytes go to Meta's Graph API or to the local sandbox.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from ..protocol import Status


class TransportError(Exception):
    """Base class for every transport failure."""

    def __init__(self, message: str, *, retryable: bool = True, code: str | int | None = None):
        super().__init__(message)
        self.retryable = retryable
        self.code = code


class TransportConnectionError(TransportError):
    """connect() failed, or send() was called while disconnected."""


class TransportSendError(TransportError):
    """The transport refused or failed a specific message."""


@dataclass(frozen=True)
class SendResult:
    """What the transport actually reported back for one message."""

    provider_id: str
    status: Status
    detail: str = ""


@dataclass(frozen=True)
class ConnectionInfo:
    connected: bool
    account: str = ""
    detail: str = ""
    real_delivery: bool = False


class Transport(ABC):
    #: Human readable name shown in the UI.
    name: str = "transport"
    #: True only when messages reach real WhatsApp users.
    real_delivery: bool = False
    #: True when the transport can report DELIVERED/READ receipts.
    supports_receipts: bool = False

    @abstractmethod
    def connect(self) -> ConnectionInfo:
        """Authenticate / open the session. Raise TransportConnectionError."""

    @abstractmethod
    def disconnect(self) -> None:
        """Close the session. Must be safe to call when already closed."""

    @abstractmethod
    def send_message(self, recipient: str, message: str) -> SendResult:
        """Send one message. Raise TransportSendError on failure."""

    @abstractmethod
    def get_status(self, message_id: str) -> Status | None:
        """Latest status the transport knows for a provider message id.

        Returns None when the transport has no information -- never a guess.
        """

    @abstractmethod
    def is_connected(self) -> bool: ...

    def reconnect(self) -> ConnectionInfo:
        try:
            self.disconnect()
        except Exception:  # noqa: BLE001 - reconnect must not die on cleanup
            pass
        return self.connect()
