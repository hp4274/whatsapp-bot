"""Real WhatsApp delivery via the WhatsApp Business Cloud API (Meta Graph API).

Why this mechanism
------------------
WhatsApp has exactly one publicly documented, officially supported programmatic
send path: the **WhatsApp Business Cloud API**, hosted by Meta and reached over
HTTPS on graph.facebook.com.  It is the mechanism used here.

There is *no* official API for a normal/personal WhatsApp account.  Personal
accounts are served only by the official clients (phone app, desktop app,
WhatsApp Web).  Libraries that drive a personal account do so by
re-implementing the unpublished multi-device protocol or by automating
WhatsApp Web; both are outside the WhatsApp Terms of Service and routinely get
the number banned.  This application therefore does not ship such a path, and
does not pretend the Cloud API is a personal account.  See README.md
("WhatsApp transport") for the full explanation and what to do about it.

Authentication requirements
---------------------------
* A Meta app with the WhatsApp product added.
* A WhatsApp Business Account (WABA) and a business phone number, which gives
  you a ``phone_number_id``.
* An access token: the 24-hour test token from the App Dashboard, or a
  permanent System User token with the ``whatsapp_business_messaging``
  permission for production.

Limitations you will hit
------------------------
* **24-hour customer service window** - free-form text can only be sent to a
  user who messaged you in the last 24 hours.  Outside it you must send an
  approved **template** (``use_template = True``).  Violations come back as
  error 131047 and are NOT retried here, because retrying cannot fix them.
* Test numbers may only message a small list of verified recipients.
* Throughput and daily unique-recipient limits are set by Meta per number.
* The send call only reports ``accepted`` -> mapped to SENT.  DELIVERED and
  READ exist *only* as webhook receipts, so they are written by
  :class:`WebhookReceiver` and never inferred locally.
"""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable
from urllib.parse import parse_qs, urlparse

import httpx

from ..config import Config
from ..logger import get_logger
from ..protocol import Status
from .base import (
    ConnectionInfo,
    SendResult,
    Transport,
    TransportConnectionError,
    TransportSendError,
)

log = get_logger("transport.cloud_api")

#: Meta error codes that are worth another attempt.  Everything else is a
#: permanent rejection -- retrying an unregistered number or a 24h-window
#: violation just burns quota.
RETRYABLE_ERROR_CODES = {
    130429,  # rate limit hit
    131048,  # spam rate limit hit
    131056,  # pair rate limit hit
    133016,  # too many requests / temporary block
    131000,  # generic something went wrong
    1,       # API unknown / transient
    2,       # API service temporarily unavailable
    4,       # API too many calls
    80007,   # rate limit issues
}

#: Codes that mean "your credentials are wrong", i.e. a connection problem
#: rather than a per-message problem.
AUTH_ERROR_CODES = {190, 102, 10, 200, 3}


class CloudAPITransport(Transport):
    name = "WhatsApp Business Cloud API"
    real_delivery = True
    supports_receipts = True

    def __init__(self, config: Config, client: httpx.Client | None = None) -> None:
        self.config = config
        self._client = client
        self._owns_client = client is None
        self._connected = False
        self._account = ""
        self._lock = threading.RLock()
        #: provider_id -> Status, populated exclusively by webhook receipts.
        self._receipts: dict[str, Status] = {}

    # ------------------------------------------------------------ plumbing --
    @property
    def _messages_url(self) -> str:
        return f"{self.config.graph_base_url}/{self.config.phone_number_id}/messages"

    def _ensure_client(self) -> httpx.Client:
        if self._client is None:
            self._client = httpx.Client(timeout=self.config.request_timeout)
            self._owns_client = True
        return self._client

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.config.access_token}",
            "Content-Type": "application/json",
        }

    # ----------------------------------------------------------- lifecycle --
    def connect(self) -> ConnectionInfo:
        problems = self.config.validate()
        if problems:
            raise TransportConnectionError("; ".join(problems), retryable=False)

        url = f"{self.config.graph_base_url}/{self.config.phone_number_id}"
        try:
            response = self._ensure_client().get(
                url,
                headers=self._headers(),
                params={"fields": "display_phone_number,verified_name,quality_rating"},
            )
        except httpx.HTTPError as exc:
            raise TransportConnectionError(f"Network error reaching Graph API: {exc}") from exc

        if response.status_code != 200:
            code, message = _parse_error(response)
            raise TransportConnectionError(
                f"Graph API rejected the credentials ({response.status_code}/{code}): {message}",
                retryable=code not in AUTH_ERROR_CODES,
                code=code,
            )

        data = response.json()
        self._account = (
            f"{data.get('verified_name', '')} "
            f"({data.get('display_phone_number', self.config.phone_number_id)})"
        ).strip()
        with self._lock:
            self._connected = True
        log.info("Connected to Cloud API as %s", self._account)
        return ConnectionInfo(
            connected=True,
            account=self._account,
            detail=f"quality: {data.get('quality_rating', 'UNKNOWN')}",
            real_delivery=True,
        )

    def disconnect(self) -> None:
        with self._lock:
            self._connected = False
        if self._owns_client and self._client is not None:
            self._client.close()
            self._client = None
        log.info("Disconnected from Cloud API")

    def is_connected(self) -> bool:
        with self._lock:
            return self._connected

    # ---------------------------------------------------------------- send --
    def _payload(self, recipient: str, message: str) -> dict:
        if self.config.use_template:
            return {
                "messaging_product": "whatsapp",
                "recipient_type": "individual",
                "to": recipient,
                "type": "template",
                "template": {
                    "name": self.config.template_name,
                    "language": {"code": self.config.template_language},
                    "components": [
                        {
                            "type": "body",
                            "parameters": [{"type": "text", "text": message}],
                        }
                    ],
                },
            }
        return {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": recipient,
            "type": "text",
            "text": {"preview_url": self.config.preview_url, "body": message},
        }

    def send_message(self, recipient: str, message: str) -> SendResult:
        if not self.is_connected():
            raise TransportConnectionError("Transport is not connected", retryable=False)

        try:
            response = self._ensure_client().post(
                self._messages_url,
                headers=self._headers(),
                json=self._payload(recipient, message),
            )
        except httpx.TimeoutException as exc:
            raise TransportSendError(f"Request timed out: {exc}", retryable=True) from exc
        except httpx.HTTPError as exc:
            raise TransportSendError(f"Network error: {exc}", retryable=True) from exc

        if response.status_code >= 400:
            code, message_text = _parse_error(response)
            retryable = response.status_code >= 500 or code in RETRYABLE_ERROR_CODES
            if code in AUTH_ERROR_CODES:
                with self._lock:
                    self._connected = False
                raise TransportConnectionError(
                    f"Authentication failed ({code}): {message_text}", retryable=False, code=code
                )
            raise TransportSendError(
                f"Cloud API error {response.status_code}/{code}: {message_text}",
                retryable=retryable,
                code=code,
            )

        try:
            body = response.json()
            provider_id = body["messages"][0]["id"]
        except (ValueError, KeyError, IndexError) as exc:
            raise TransportSendError(
                f"Unexpected Cloud API response: {response.text[:300]}", retryable=False
            ) from exc

        # The API only confirms it accepted the message for delivery.  That is
        # SENT.  DELIVERED / READ arrive later, on the webhook, or not at all.
        log.info("Accepted by Cloud API: %s -> %s", recipient, provider_id)
        return SendResult(provider_id=provider_id, status=Status.SENT, detail="accepted")

    # -------------------------------------------------------------- status --
    def get_status(self, message_id: str) -> Status | None:
        """The Cloud API has no status-polling endpoint.

        Anything beyond SENT is only knowable from a webhook receipt, so this
        returns what the webhook delivered, or None.
        """
        with self._lock:
            return self._receipts.get(message_id)

    def record_receipt(self, provider_id: str, status: Status) -> None:
        with self._lock:
            self._receipts[provider_id] = status


# --------------------------------------------------------------------------
# Webhook receiver: the only source of DELIVERED / READ
# --------------------------------------------------------------------------

ReceiptCallback = Callable[[str, Status, str | None], None]

_WEBHOOK_STATUS_MAP = {
    "sent": Status.SENT,
    "delivered": Status.DELIVERED,
    "read": Status.READ,
    "failed": Status.FAILED,
}


class WebhookReceiver:
    """Small HTTP server that consumes WhatsApp ``messages`` status webhooks.

    Meta must be able to reach it over public HTTPS, so in practice you point a
    tunnel (ngrok, Cloudflare Tunnel) or a reverse proxy at it and register that
    URL as the callback URL of your Meta app.  Without this, the application
    legitimately stops at SENT -- it will not invent DELIVERED or READ.
    """

    def __init__(self, config: Config, on_receipt: ReceiptCallback) -> None:
        self.config = config
        self.on_receipt = on_receipt
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    def start(self) -> int:
        if self._server is not None:
            return self._server.server_address[1]
        receiver = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, fmt: str, *args) -> None:  # silence stderr spam
                log.debug("webhook %s", fmt % args)

            def do_GET(self) -> None:  # noqa: N802 - http.server API
                parsed = urlparse(self.path)
                query = parse_qs(parsed.query)
                mode = query.get("hub.mode", [""])[0]
                token = query.get("hub.verify_token", [""])[0]
                challenge = query.get("hub.challenge", [""])[0]
                if mode == "subscribe" and token == receiver.config.webhook_verify_token:
                    self._respond(200, challenge.encode())
                    log.info("Webhook verification succeeded")
                else:
                    self._respond(403, b"forbidden")
                    log.warning("Webhook verification rejected (bad verify token)")

            def do_POST(self) -> None:  # noqa: N802 - http.server API
                length = int(self.headers.get("Content-Length") or 0)
                raw = self.rfile.read(length) if length else b"{}"
                # Always 200 quickly: Meta retries anything else.
                self._respond(200, b"ok")
                try:
                    payload = json.loads(raw.decode("utf-8"))
                except ValueError:
                    log.warning("Webhook body was not JSON")
                    return
                for provider_id, status, error in parse_status_payload(payload):
                    try:
                        receiver.on_receipt(provider_id, status, error)
                    except Exception:  # noqa: BLE001 - never kill the server
                        log.exception("Receipt handler failed for %s", provider_id)

            def _respond(self, code: int, body: bytes) -> None:
                self.send_response(code)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        self._server = ThreadingHTTPServer(
            (self.config.webhook_host, self.config.webhook_port), Handler
        )
        self._thread = threading.Thread(
            target=self._server.serve_forever, name="webhook", daemon=True
        )
        self._thread.start()
        port = self._server.server_address[1]
        log.info("Webhook receiver listening on %s:%s", self.config.webhook_host, port)
        return port

    def stop(self) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
            self._server = None
        if self._thread is not None:
            self._thread.join(timeout=5)
            self._thread = None
        log.info("Webhook receiver stopped")


def parse_status_payload(payload: dict) -> list[tuple[str, Status, str | None]]:
    """Extract ``(provider_id, status, error)`` triples from a webhook body."""
    results: list[tuple[str, Status, str | None]] = []
    for entry in payload.get("entry") or []:
        for change in entry.get("changes") or []:
            value = change.get("value") or {}
            for status_obj in value.get("statuses") or []:
                provider_id = status_obj.get("id")
                status = _WEBHOOK_STATUS_MAP.get(str(status_obj.get("status", "")).lower())
                if not provider_id or status is None:
                    continue
                error = None
                errors = status_obj.get("errors") or []
                if errors:
                    first = errors[0]
                    detail = (first.get("error_data") or {}).get("details", "")
                    error = f"{first.get('code')}: {first.get('title', '')} {detail}".strip()
                results.append((provider_id, status, error))
    return results


def _parse_error(response: httpx.Response) -> tuple[int | None, str]:
    try:
        error = response.json().get("error", {})
    except ValueError:
        return None, response.text[:300]
    code = error.get("code")
    message = error.get("message", "unknown error")
    details = (error.get("error_data") or {}).get("details")
    if details:
        message = f"{message} ({details})"
    return code, message
