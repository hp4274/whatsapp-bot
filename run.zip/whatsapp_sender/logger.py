"""Logging setup: rotating file in the app directory plus console output."""

from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

from .config import LOG_PATH, ensure_app_dir

_CONFIGURED = False
_FORMAT = "%(asctime)s %(levelname)-8s %(name)-28s %(message)s"


def setup_logging(level: str = "INFO", log_path: Path | None = None) -> logging.Logger:
    global _CONFIGURED
    root = logging.getLogger("whatsapp_sender")
    if _CONFIGURED:
        root.setLevel(level.upper())
        return root

    ensure_app_dir()
    path = log_path or LOG_PATH
    root.setLevel(level.upper())
    root.propagate = False

    file_handler = logging.handlers.RotatingFileHandler(
        path, maxBytes=2_000_000, backupCount=3, encoding="utf-8"
    )
    file_handler.setFormatter(logging.Formatter(_FORMAT))
    root.addHandler(file_handler)

    console = logging.StreamHandler()
    console.setFormatter(logging.Formatter(_FORMAT))
    root.addHandler(console)

    # httpx logs a line per request at INFO; keep the app log readable.
    logging.getLogger("httpx").setLevel(logging.WARNING)

    _CONFIGURED = True
    root.info("Logging initialised -> %s", path)
    return root


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"whatsapp_sender.{name}")
