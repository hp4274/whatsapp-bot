@echo off
REM Launches the GUI using the virtual environment created by install.bat.
setlocal

if exist ".venv\Scripts\pythonw.exe" (
    start "" ".venv\Scripts\pythonw.exe" -m whatsapp_sender.main %*
) else (
    echo .venv not found - run install.bat first, falling back to system Python.
    python -m whatsapp_sender.main %*
)
