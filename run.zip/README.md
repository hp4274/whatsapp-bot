# WhatsApp Sender — Python Desktop Application

A Windows desktop application, written entirely in Python 3.12+, that sends real
WhatsApp messages from a GUI: configure the connection, type a number, type a
message, press **SEND TEST**, and the recipient receives it. Bulk campaigns,
personalisation, a rate-limited queue, retries and a full message history are
included.

```
CustomTkinter GUI
      ↓
Connection (WhatsApp Business Cloud API)
      ↓
Recipient + message  ──►  Queue ──► Rate limiter ──► Transport ──► Status
      ↓                                                              ↓
   SQLite history  ◄──────────── webhook receipts (DELIVERED / READ) ┘
```

---

## 1. The WhatsApp transport actually used — read this first

**Mechanism: the WhatsApp Business Cloud API (Meta Graph API over HTTPS).**
This is the only publicly documented, officially supported way for software to
send a WhatsApp message. The application posts to:

```
POST https://graph.facebook.com/<GRAPH_VERSION>/<PHONE_NUMBER_ID>/messages
Authorization: Bearer <ACCESS_TOKEN>
{"messaging_product":"whatsapp","recipient_type":"individual",
 "to":"919876543210","type":"text","text":{"preview_url":true,"body":"..."}}
```

Implementation: [`whatsapp_sender/transports/whatsapp_transport.py`](whatsapp_sender/transports/whatsapp_transport.py).

### About "normal / personal WhatsApp account"

The brief asks for a personal account. That has to be answered honestly:

* **There is no official API for a personal WhatsApp account.** Personal
  accounts are only served by the official clients (phone app, desktop app,
  WhatsApp Web). Meta publishes no credentials, no endpoint and no SDK for them.
* Libraries that do drive a personal account (Baileys, whatsapp-web.js,
  `pywhatkit`, Selenium drivers) either re-implement the unpublished multi-device
  protocol or puppet WhatsApp Web. Both are **against the WhatsApp Terms of
  Service**, both break whenever Meta changes the protocol, and both routinely
  get the number banned — especially with bulk sending, which is exactly what
  this application does.
* `pywhatkit`-style solutions also fail the brief's own requirement: they open a
  browser tab per message and report "sent" the moment they press a key, with no
  idea whether WhatsApp accepted anything.

So this application ships the Cloud API and **does not pretend it is a personal
account**. The Cloud API number is a WhatsApp *Business* number: it can message
any normal WhatsApp user, and the recipient sees an ordinary WhatsApp message.
If you must use your personal number, the honest options are: migrate that
number to the WhatsApp Business Platform (it stops working in the consumer app),
or use an official Business Solution Provider. If you decide to accept the ToS
risk of an unofficial library, that is a deliberate decision to make with your
eyes open — this project will not make it silently on your behalf.

### 1b. Token-free path: the WhatsApp Web transport

If you do not want a Meta app, a WhatsApp Business account or an access token,
select **WhatsApp Web / whatsapp-web.js** on the Connection tab. It links your
existing WhatsApp account the same way WhatsApp Web does: you scan a QR code
once, and the session is cached on disk and reused on every later start.

How it is wired:

* `whatsapp_sender/bridge/bridge.js` is a small Node sidecar running
  [whatsapp-web.js](https://wwebjs.dev/). It exposes a loopback-only HTTP API
  (`/status`, `/send`, `/acks`, `/logout`, `/shutdown`) guarded by a
  per-launch random token.
* [`whatsapp_sender/transports/whatsapp_web.py`](whatsapp_sender/transports/whatsapp_web.py)
  starts that sidecar, waits for the QR scan, sends through it and polls
  `/acks`. It implements the same `Transport` interface as the Cloud API
  transport, so the queue, rate limiter, retries, history and CSV/XLSX
  campaigns work unchanged.
* Status mapping from WhatsApp Web ACKs: `ACK_SERVER` -> `SENT`,
  `ACK_DEVICE` -> `DELIVERED`, `ACK_READ`/`ACK_PLAYED` -> `READ`,
  `ACK_ERROR` -> `FAILED`. `ACK_PENDING` reports nothing, so no status is ever
  guessed. **No webhook and no public URL are needed** for DELIVERED/READ here.
* Numbers are checked with `getNumberId` before sending; "not on WhatsApp" is a
  permanent failure and is not retried.
* `client.sendMessage()` sometimes dispatches a message and still returns no id
  (WhatsApp Web changes shape under whatsapp-web.js). The bridge therefore
  confirms every idless send against its own `message_create` stream before
  deciding anything, and if it still has no id it reports the send with a
  `local.*` id and `ackTracking: false` rather than an error. A retry there
  would deliver the message a second time, which is never worth an id.

**The cost, stated plainly:** whatsapp-web.js is not an official API. It
automates the WhatsApp Web client, which violates the WhatsApp Terms of
Service, breaks whenever Meta changes the web client, and gets numbers banned
for bulk sending. The GUI shows an amber warning whenever this transport is
selected, and the log repeats it on every connect. Use the Cloud API for
anything you care about; use this one when removing the token requirement
matters more than the risk, with your eyes open.

Extra requirements: **Node.js 18+**, and one `npm install` in
`whatsapp_sender/bridge` (`install.bat` does it). whatsapp-web.js drives a real
Chromium through puppeteer, so the first install downloads one (~190 MB). If
the download is blocked by npm's install-script policy, run
`npx puppeteer browsers install chrome` in `whatsapp_sender/bridge`; if that
leaves a folder without `chrome.exe`, unzip
`%USERPROFILE%\.cache\puppeteer\chrome\*.zip` over it by hand, or point
`bridge_chrome_path` in `config.json` at an installed Chrome/Edge binary.

Relevant `config.json` keys: `bridge_port` (8765), `bridge_ready_timeout`
(180 s allowed for the QR scan), `bridge_poll_interval` (2 s ACK polling),
`bridge_data_dir` (session cache, default `<app dir>\wwebjs_auth`),
`bridge_chrome_path`, `bridge_node` (default `node`).

### Authentication requirements

| What | Where to get it |
|---|---|
| Meta app with the **WhatsApp** product | <https://developers.facebook.com/apps> |
| **WhatsApp Business Account (WABA)** + business phone number | WhatsApp → API Setup in the app dashboard |
| **Phone Number ID** | WhatsApp → API Setup (it is *not* the phone number) |
| **Access token** | Temporary 24 h token on the same page, or a permanent **System User** token with `whatsapp_business_messaging` for production |
| **Verified recipients** (test numbers only) | Add up to 5 recipient numbers on the API Setup page |

### Limitations you will actually hit

* **24-hour customer service window.** Free-form text can only be sent to a user
  who messaged your business number within the last 24 hours. Outside it, Meta
  rejects the send with **error 131047** and you must send an **approved
  template** — tick *"Send as approved template"* on the Connection tab. The
  application does **not** retry 131047, because retrying cannot fix it.
* The temporary token expires after 24 hours.
* Test numbers may only message the verified recipient list.
* Meta enforces per-number throughput and daily unique-recipient limits; the
  rate limiter exists to stay under them (errors 130429 / 131048 / 131056 *are*
  retried, with exponential backoff).
* Sending unsolicited bulk messages gets numbers blocked. Message people who
  opted in.

### Why status stops at SENT unless you run the webhook

The send call only tells you Meta **accepted** the message → `SENT`.
**DELIVERED and READ exist only as webhook callbacks.** This application
therefore never invents them: it writes `DELIVERED`/`READ` only when a real
webhook receipt arrives (see §6). No fake ticks, ever.

### Local testing vs. real delivery

Three transports, selectable on the Connection tab:

| Transport | Access token? | Delivers to WhatsApp? | Status written |
|---|---|---|---|
| **WhatsApp Business Cloud API** | required | **Yes, really** | `SENT`, then `DELIVERED`/`READ` from webhooks |
| **WhatsApp Web (whatsapp-web.js)** | **none - QR scan** | **Yes, really** | `SENT`, then `DELIVERED`/`READ` from WhatsApp Web ACKs |
| **Local sandbox** | none | **No** - appends to `sandbox_outbox.log` | `SANDBOX` (a distinct state, never `SENT`) |

The sandbox exists so you can exercise the queue, retries and UI without a
token. It is deliberately impossible to mistake for a real send: a separate
status value, an amber banner in the GUI, a warning in the log, and a note on
the CLI.

---

## 2. Install (Windows)

Requires Python 3.12 or newer with the **tcl/tk** option ticked in the installer.

```bat
install.bat      :: creates .venv, installs requirements, and (if npm is on PATH)
                 :: installs the whatsapp-web.js bridge
run.bat          :: launches the GUI
```

The WhatsApp Web transport additionally needs Node.js 18+; without it the other
two transports still work.

Manually, if you prefer:

```bat
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m whatsapp_sender.main
```

> If Tk fails to start inside the venv with `Can't find a usable init.tcl`, set
> `TCL_LIBRARY` and `TK_LIBRARY` to the `tcl\tcl8.6` and `tcl\tk8.6` folders of
> your base Python installation (a known venv quirk on some Windows installs).

Application data lives in `%USERPROFILE%\.whatsapp_sender\`
(`config.json`, `messages.db`, `app.log`). Override with the
`WHATSAPP_SENDER_HOME` environment variable.

---

## 3. Using the application

### Look and feel

A navigation rail (Connection / Messaging & Campaign / History), an app header
with the brand mark and an **Auto / Light / Dark** switch, and a content area
of cards. Deep navy surfaces in dark, white in light; WhatsApp green for
anything live, blue for configuration, amber for advisories, red for
destructive actions.

* Every colour, spacing step, font size and icon is a token in
  [`whatsapp_sender/ui/theme.py`](whatsapp_sender/ui/theme.py) - no view
  hard-codes a hex. Widget defaults live in
  `whatsapp_sender/ui/assets/azure.json`, regenerated by
  `python -m whatsapp_sender.ui.build_theme` after any token change.
* Icons come from **Segoe Fluent Icons** (Segoe MDL2 Assets on Windows 10),
  which ships with the OS: real monochrome icons that tint with the palette,
  no image files, no icon package and no emoji. Without either font the labels
  simply render without a glyph.
* The app mark is `whatsapp_sender/ui/assets/logo_*.png` (32-256 px), shown in
  the header and used as the window icon. Tk reads PNG natively, so no imaging
  library is involved.
* Motion lives in [`whatsapp_sender/ui/anim.py`](whatsapp_sender/ui/anim.py):
  a spinner while a connection is being established, a breathing dot while a
  session is live, and an eased progress bar so a campaign advances instead of
  jumping. Nothing animates layout. Set `animations: false` in `config.json`
  for reduced motion - every animation then jumps straight to its end state.
* The appearance choice is saved as `appearance_mode` in `config.json`. The
  history table is plain ttk, which CustomTkinter does not theme, so it is
  repainted from the same tokens whenever the mode changes.

### Connection tab
Transport, Phone Number ID, Access Token, Graph version, template settings, and
every delivery knob: rate limit, max retries, retry base delay and backoff
factor, request timeout, default country code. **Save settings**, then
**Connect** / **Disconnect** / **Reconnect**. The status line turns green for a
live Cloud API connection and amber for the sandbox.

The token is stored in `config.json` in your user profile. It is **not**
encrypted — prefer the environment variables `WHATSAPP_ACCESS_TOKEN` and
`WHATSAPP_PHONE_NUMBER_ID`, which override the file.

### Messaging & Campaign tab
* **Recipient number + message + SEND TEST** — a single send that goes through
  the same queue, rate limiter, retry policy and history as a campaign.
* **Recipient name** fills `{name}` in that single message; leave it blank and
  `{name}` resolves to an empty string.
* **Import CSV / Import XLSX**, contact count, **Start Campaign**, **Pause**,
  **Resume**, **Stop**, progress bar, successful/failed/pending counters.
* **One message per number** (ticked by default) sends exactly one personalised
  message to each number: rows repeating a number are dropped whatever name
  they carry (the first one wins), and numbers that already received a real
  message in an earlier run are skipped, since the database remembers them.
  Untick it to allow a number to be messaged again - duplicate protection then
  falls back to rejecting only an identical number+message pair.
  `SANDBOX` sends do not count as "already messaged", so a local test run never
  blocks the real one.

### History tab
`Message ID · Recipient · Message · Status · Attempt · Created · Updated · Error`,
colour-coded by status, filterable by status and recipient.

### Headless send (useful for smoke tests)

```bat
.venv\Scripts\python.exe -m whatsapp_sender.main --send +919876543210 --message "Hi"
.venv\Scripts\python.exe -m whatsapp_sender.main --transport sandbox --send +91... --message "Hi"
```

---

## 4. Contacts and personalisation

`sample_contacts.csv`:

```csv
name,phone,order_id
Rahul,+919876543210,ORD-1001
Priya,+919812345678,ORD-1002
Amit,+919999888777,ORD-1003
```

Headers are case-insensitive; `name`/`full_name`/`contact` and
`phone`/`mobile`/`number`/`whatsapp` are all accepted. **Every extra column
becomes a personalisation variable.**

```
Hello {name}, your order {order_id} has been confirmed.
→ Hello Rahul, your order ORD-1001 has been confirmed.
```

Unknown placeholders are left intact instead of failing the campaign. Numbers
are normalised to E.164 (`+91 98765-43210` → `919876543210`); invalid rows are
reported and skipped, duplicates are dropped at import *and* at queue time.

---

## 5. Engine: queue, rate control, retries, status

```
Contact → personalise → FIFO queue → rate limiter → transport → status → SQLite
```

* **Queue** (`campaign/queue.py`) — FIFO, thread-safe, `pause` / `resume` /
  `stop` (stop cancels everything still queued and marks it FAILED), duplicate
  protection on `recipient + body`, blocking `get` with timeout.
* **Rate limiter** (`campaign/rate_limiter.py`) — token bucket. The rate comes
  from `rate_limit_per_second` in the config; no delay is hard-coded. Waiting is
  sliced so **Stop** is honoured immediately.
* **Retries** (`campaign/retry.py`) — `MAX_RETRIES = 3`, `RETRY_DELAY = 2` by
  default, exponential backoff (`delay × backoff^(attempt-1)`), capped, with
  jitter. Only errors the transport marks **retryable** are retried: rate limits
  and 5xx yes, "not a WhatsApp user" or a 24-hour-window violation no.
* **Timeout** — `request_timeout` is applied to every HTTP call.
* **Statuses** — `QUEUED → SENDING → SENT → DELIVERED → READ`, or `FAILED`;
  `SANDBOX` for local testing. A late `DELIVERED` receipt can never overwrite
  `READ`.

## 6. Delivery receipts (optional, needed for DELIVERED / READ)

1. Tick **Run local webhook receiver**, set a port and a verify token, Save,
   Connect.
2. Expose the port over public HTTPS, e.g. `ngrok http 8080`.
3. In the Meta app dashboard → WhatsApp → Configuration → Webhooks, set the
   callback URL to `https://<your-tunnel>/webhook`, the verify token to the same
   string, and **subscribe to the `messages` field**.

Receipts then flow in and the History tab advances to DELIVERED / READ. Without
this, history legitimately stops at SENT.

## 7. Database

SQLite, created automatically at `%USERPROFILE%\.whatsapp_sender\messages.db`
(WAL mode):

```
messages(message_id PK, recipient, name, message, status, attempt,
         provider_id, error, campaign_id, created_at, updated_at)
indexes: recipient, status, created_at, provider_id, campaign_id
```

`provider_id` holds the WhatsApp `wamid.*` returned by Meta, which is what
webhook receipts are matched against.

## 8. Tests

```bat
.venv\Scripts\python.exe -m pytest -q
```

96 tests covering CSV import, XLSX import, contact validation, duplicate
detection, personalisation, queue processing, pause/resume/stop, retry logic and
backoff, the rate limiter, database operations and receipt ordering, transport
error classification, webhook parsing and connection failures. The Cloud API is
tested against an `httpx.MockTransport` — no network, no tokens, and no test
ever asserts a fake delivery.

## 9. Standalone .exe (PyInstaller)

```bat
.venv\Scripts\python.exe -m pip install pyinstaller
.venv\Scripts\pyinstaller.exe --onefile --windowed ^
    --name WhatsAppSender ^
    --collect-all customtkinter ^
    main.py
```

The result is `dist\WhatsAppSender.exe`. `--collect-all customtkinter` is
required: CustomTkinter ships theme JSON and fonts that PyInstaller does not
pick up automatically. `--windowed` hides the console; drop it while debugging.
The database, config and log still live in `%USERPROFILE%\.whatsapp_sender\`,
so the exe is portable.

## 10. Project layout

```
main.py                     PyInstaller entry point
requirements.txt  install.bat  run.bat  sample_contacts.csv
whatsapp_sender/
├── main.py                 GUI + CLI entry point
├── config.py               settings, persisted as JSON
├── database.py             SQLite schema, queries, receipt ordering
├── protocol.py             Status, Contact, phone rules, personalisation
├── logger.py               rotating file + console logging
├── ui/                     main_window, connection_view, campaign_view, history_view
├── contacts/               csv_importer, xlsx_importer
├── campaign/               manager, queue, retry, rate_limiter
├── transports/             base (interface), whatsapp_transport (Cloud API),
│                           whatsapp_web (whatsapp-web.js), sandbox
└── bridge/                 bridge.js + package.json: the Node whatsapp-web.js sidecar
tests/                      pytest suite
```

The GUI and the campaign engine talk **only** to the `Transport` interface
(`connect` / `disconnect` / `send_message` / `get_status`), so swapping the
transport changes nothing else.

## 11. Acceptance test

### Token-free (WhatsApp Web)

1. `run.bat`
2. Connection tab -> **WhatsApp Web / whatsapp-web.js** -> Save -> **Connect**.
3. A window shows a QR code: WhatsApp on your phone -> Settings -> Linked
   devices -> Link a device -> scan it. Status turns green with your number.
   (The bridge writes the QR as a PNG and Tk displays it directly, so no
   Pillow is needed; the window briefly shows the raw payload as a fallback
   while that PNG is being written, and swaps in the image a moment later.)
4. Messaging tab -> any WhatsApp number -> **SEND TEST** -> history goes
   `SENT` -> `DELIVERED` -> `READ` as the recipient's phone reports back.
5. `node bridge.js --selftest` in `whatsapp_sender/bridge` checks the sidecar's
   HTTP contract and ACK mapping without touching WhatsApp.

### Cloud API

1. `run.bat`
2. Connection tab → Cloud API → Phone Number ID + Access Token → Save → **Connect**
   → status turns green with the verified business name.
3. Messaging tab → a real WhatsApp number that has messaged your business number
   in the last 24 h (or tick *Send as approved template*).
4. Type the message → **SEND TEST**.
5. The recipient's phone receives the message.
6. History shows `SENT` with the real `wamid.*` provider id — and `DELIVERED` /
   `READ` once the webhook is configured. Any rejection appears verbatim in the
   Error column with Meta's error code.
